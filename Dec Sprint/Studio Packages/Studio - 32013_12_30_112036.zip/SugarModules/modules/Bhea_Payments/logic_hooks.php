<?php

$hook_version = 1;
$hook_array = Array();

$hook_array['after_save'] = Array();
$hook_array['after_save'][] = Array(1,' Edited Records Payment Module','custom/modules/Bhea_Payments/payMem_save.php','payMem_save','payMem_save');

?>
