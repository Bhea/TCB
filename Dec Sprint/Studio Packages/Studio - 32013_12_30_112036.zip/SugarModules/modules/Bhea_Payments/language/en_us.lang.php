<?php 
 // created: 2013-12-30 11:20:33
$mod_strings['LNK_NEW_RECORD'] = 'Create Payment';
$mod_strings['LNK_LIST'] = 'View Payments';
$mod_strings['LBL_MODULE_NAME'] = 'Payments';
$mod_strings['LBL_MODULE_NAME_SINGULAR'] = 'Payments';
$mod_strings['LBL_NEW_FORM_TITLE'] = 'New Payments';
$mod_strings['LNK_IMPORT_VCARD'] = 'Import Payments vCard';
$mod_strings['LNK_IMPORT_BHEA_PAYMENTS'] = 'Import Payment';
$mod_strings['LBL_LIST_FORM_TITLE'] = 'Paymentss List';
$mod_strings['LBL_SEARCH_FORM_TITLE'] = 'Search Payments';
$mod_strings['LBL_HOMEPAGE_TITLE'] = 'My Paymentss';
$mod_strings['LBL_PAYMENT_DATE'] = 'Payment Date';
$mod_strings['LBL_PAYMENT_STATUS'] = 'Payment Status';
$mod_strings['LBL_PAYMENT_MODE'] = 'Payment Mode';
$mod_strings['LBL_CHECK_DD_TRANSACTION_NONO'] = 'Check/DD/Transaction No';
$mod_strings['LBL_CHECK_DD_TRANSACTION_DATE'] = 'Check/DD/Transaction Date';
$mod_strings['LBL_BANK_NAME'] = 'Bank Name';
$mod_strings['LBL_BRANCH_NAME'] = 'Branch Name';
$mod_strings['LBL_REMARKS'] = 'Remarks';

?>
