<?php
 // created: 2013-12-03 09:48:33
$dictionary['Bhea_Registrants']['fields']['company_address_street_c']['group']='company_address_c';

 ?>