<?php
 // created: 2013-12-25 16:32:08
$dictionary['Bhea_Payments']['fields']['remarks_c']['labelValue']='Remarks';
$dictionary['Bhea_Payments']['fields']['remarks_c']['enforced']='';
$dictionary['Bhea_Payments']['fields']['remarks_c']['dependency']='';

 ?>