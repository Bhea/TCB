<?php
 // created: 2013-12-25 16:48:28
$dictionary['Bhea_Payments']['fields']['payment_status']['default']='';

 ?>