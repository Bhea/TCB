<?php
 // created: 2013-12-25 16:30:12
$dictionary['Bhea_Payments']['fields']['check_dd_transaction_date_c']['labelValue']='Check/DD/Transaction Date';
$dictionary['Bhea_Payments']['fields']['check_dd_transaction_date_c']['enforced']='';
$dictionary['Bhea_Payments']['fields']['check_dd_transaction_date_c']['dependency']='';

 ?>