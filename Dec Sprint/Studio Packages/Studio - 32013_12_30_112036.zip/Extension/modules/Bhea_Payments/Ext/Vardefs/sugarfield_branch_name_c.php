<?php
 // created: 2013-12-25 16:30:54
$dictionary['Bhea_Payments']['fields']['branch_name_c']['labelValue']='Branch Name';
$dictionary['Bhea_Payments']['fields']['branch_name_c']['enforced']='';
$dictionary['Bhea_Payments']['fields']['branch_name_c']['dependency']='';

 ?>