<?php
 // created: 2013-12-25 16:30:31
$dictionary['Bhea_Payments']['fields']['bank_name_c']['labelValue']='Bank Name';
$dictionary['Bhea_Payments']['fields']['bank_name_c']['enforced']='';
$dictionary['Bhea_Payments']['fields']['bank_name_c']['dependency']='';

 ?>