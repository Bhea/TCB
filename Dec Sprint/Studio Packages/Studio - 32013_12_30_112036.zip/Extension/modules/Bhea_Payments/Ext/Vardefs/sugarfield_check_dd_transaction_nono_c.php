<?php
 // created: 2013-12-25 16:29:32
$dictionary['Bhea_Payments']['fields']['check_dd_transaction_nono_c']['labelValue']='Check/DD/Transaction No';
$dictionary['Bhea_Payments']['fields']['check_dd_transaction_nono_c']['enforced']='';
$dictionary['Bhea_Payments']['fields']['check_dd_transaction_nono_c']['dependency']='';

 ?>