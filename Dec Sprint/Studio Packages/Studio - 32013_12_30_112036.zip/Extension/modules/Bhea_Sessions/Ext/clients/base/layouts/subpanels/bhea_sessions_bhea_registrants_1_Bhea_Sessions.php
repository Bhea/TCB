<?php
// created: 2013-12-03 09:42:33
$viewdefs['Bhea_Sessions']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_BHEA_SESSIONS_BHEA_REGISTRANTS_1_FROM_BHEA_REGISTRANTS_TITLE',
  'context' => 
  array (
    'link' => 'bhea_sessions_bhea_registrants_1',
  ),
);