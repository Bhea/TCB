<?php
// created: 2013-12-17 10:30:20
$dictionary["Bhea_Councils"]["fields"]["bhea_councils_bhea_council_members_2"] = array (
  'name' => 'bhea_councils_bhea_council_members_2',
  'type' => 'link',
  'relationship' => 'bhea_councils_bhea_council_members_2',
  'source' => 'non-db',
  'module' => 'Bhea_Council_Members',
  'bean_name' => 'Bhea_Council_Members',
  'vname' => 'LBL_BHEA_COUNCILS_BHEA_COUNCIL_MEMBERS_2_FROM_BHEA_COUNCILS_TITLE',
  'id_name' => 'bhea_councils_bhea_council_members_2bhea_councils_ida',
  'link-type' => 'many',
  'side' => 'left',
);
