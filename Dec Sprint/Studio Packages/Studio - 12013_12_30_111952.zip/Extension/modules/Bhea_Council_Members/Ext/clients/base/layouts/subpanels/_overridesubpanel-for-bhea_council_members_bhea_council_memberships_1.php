<?php
//auto-generated file DO NOT EDIT
$viewdefs['Bhea_Council_Members']['base']['layout']['subpanels']['components'][]['override_subpanel_list_view'] = array (
  'link' => 'bhea_council_members_bhea_council_memberships_1',
  'view' => 'subpanel-for-bhea_council_members',
);
?>