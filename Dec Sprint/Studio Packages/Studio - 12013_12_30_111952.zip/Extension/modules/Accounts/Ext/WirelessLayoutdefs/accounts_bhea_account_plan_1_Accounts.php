<?php
 // created: 2013-12-04 09:27:55
$layout_defs["Accounts"]["subpanel_setup"]['accounts_bhea_account_plan_1'] = array (
  'order' => 100,
  'module' => 'Bhea_Account_Plan',
  'subpanel_name' => 'default',
  'title_key' => 'LBL_ACCOUNTS_BHEA_ACCOUNT_PLAN_1_FROM_BHEA_ACCOUNT_PLAN_TITLE',
  'get_subpanel_data' => 'accounts_bhea_account_plan_1',
);
