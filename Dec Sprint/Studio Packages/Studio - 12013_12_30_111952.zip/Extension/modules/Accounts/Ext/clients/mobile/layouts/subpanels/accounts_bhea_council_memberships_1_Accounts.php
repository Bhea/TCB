<?php
// created: 2013-12-03 12:24:34
$viewdefs['Accounts']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_ACCOUNTS_BHEA_COUNCIL_MEMBERSHIPS_1_FROM_BHEA_COUNCIL_MEMBERSHIPS_TITLE',
  'context' => 
  array (
    'link' => 'accounts_bhea_council_memberships_1',
  ),
);