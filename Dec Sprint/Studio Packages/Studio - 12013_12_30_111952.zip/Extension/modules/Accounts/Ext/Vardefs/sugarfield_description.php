<?php
 // created: 2013-12-03 12:49:48
$dictionary['Account']['fields']['description']['comments']='Full text of the note';
$dictionary['Account']['fields']['description']['merge_filter']='disabled';
$dictionary['Account']['fields']['description']['full_text_search']=array (
  'boost' => '0',
);
$dictionary['Account']['fields']['description']['calculated']=false;

 ?>