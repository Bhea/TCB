<?php
// WARNING: The contents of this file are auto-generated.


// created: 2013-12-04 16:15:42
$viewdefs['Bhea_Memberships']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_BHEA_MEMBERSHIPS_BHEA_PAYMENTS_1_FROM_BHEA_PAYMENTS_TITLE',
  'context' => 
  array (
    'link' => 'bhea_memberships_bhea_payments_1',
  ),
);

// created: 2013-12-17 09:47:24
$viewdefs['Bhea_Memberships']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_BHEA_MEMBERSHIPS_BHEA_ORDERS_1_FROM_BHEA_ORDERS_TITLE',
  'context' => 
  array (
    'link' => 'bhea_memberships_bhea_orders_1',
  ),
);