<?php
// WARNING: The contents of this file are auto-generated.


//auto-generated file DO NOT EDIT
$viewdefs['Products']['base']['layout']['subpanels']['components'][]['override_subpanel_list_view'] = array (
  'link' => 'documents',
  'view' => 'subpanel-for-products',
);
