<?php
// WARNING: The contents of this file are auto-generated.


// created: 2013-12-13 10:35:05
$viewdefs['Bhea_Council_Memberships']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_BHEA_COUNCIL_MEMBERSHIPS_BHEA_ORDERS_1_FROM_BHEA_ORDERS_TITLE',
  'context' => 
  array (
    'link' => 'bhea_council_memberships_bhea_orders_1',
  ),
);

// created: 2013-12-04 16:16:06
$viewdefs['Bhea_Council_Memberships']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_BHEA_COUNCIL_MEMBERSHIPS_BHEA_PAYMENTS_1_FROM_BHEA_PAYMENTS_TITLE',
  'context' => 
  array (
    'link' => 'bhea_council_memberships_bhea_payments_1',
  ),
);

//auto-generated file DO NOT EDIT
$viewdefs['Bhea_Council_Memberships']['base']['layout']['subpanels']['components'][]['override_subpanel_list_view'] = array (
  'link' => 'bhea_council_memberships_bhea_payments_1',
  'view' => 'subpanel-for-bhea_council_memberships',
);


//auto-generated file DO NOT EDIT
$viewdefs['Bhea_Council_Memberships']['base']['layout']['subpanels']['components'][]['override_subpanel_list_view'] = array (
  'link' => 'bhea_council_memberships_bhea_orders_1',
  'view' => 'subpanel-for-bhea_council_memberships',
);
