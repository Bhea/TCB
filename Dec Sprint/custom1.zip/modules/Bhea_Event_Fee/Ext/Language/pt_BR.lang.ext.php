<?php
// WARNING: The contents of this file are auto-generated.


//THIS FILE IS AUTO GENERATED, DO NOT MODIFY
$mod_strings['LBL_BHEA_EVENTS_BHEA_EVENT_FEE_1_FROM_BHEA_EVENTS_TITLE'] = 'Events';
