<?php
// WARNING: The contents of this file are auto-generated.


// created: 2013-12-03 14:54:02
$viewdefs['Leads']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_LEADS_CONTACTS_1_FROM_CONTACTS_TITLE',
  'context' => 
  array (
    'link' => 'leads_contacts_1',
  ),
);

// created: 2013-12-03 15:33:08
$viewdefs['Leads']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_LEADS_BHEA_EVENTS_1_FROM_BHEA_EVENTS_TITLE',
  'context' => 
  array (
    'link' => 'leads_bhea_events_1',
  ),
);

// created: 2013-12-03 10:55:16
$viewdefs['Leads']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_LEADS_BHEA_FINANCE_PERFORMANCE_1_FROM_BHEA_FINANCE_PERFORMANCE_TITLE',
  'context' => 
  array (
    'link' => 'leads_bhea_finance_performance_1',
  ),
);