<?php
// WARNING: The contents of this file are auto-generated.


// created: 2013-12-18 17:49:15
$viewdefs['bhea_Sponsorship_Types']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_BHEA_SPONSORSHIP_TYPES_BHEA_SPONSORSHIP_1_FROM_BHEA_SPONSORSHIP_TITLE',
  'context' => 
  array (
    'link' => 'bhea_sponsorship_types_bhea_sponsorship_1',
  ),
);

// created: 2013-12-19 18:30:00
$viewdefs['bhea_Sponsorship_Types']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_BHEA_SPONSORSHIP_TYPES_OPPORTUNITIES_1_FROM_OPPORTUNITIES_TITLE',
  'context' => 
  array (
    'link' => 'bhea_sponsorship_types_opportunities_1',
  ),
);

// created: 2013-12-18 19:54:10
$viewdefs['bhea_Sponsorship_Types']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_BHEA_SESSIONS_BHEA_SPONSORSHIP_TYPES_1_FROM_BHEA_SESSIONS_TITLE',
  'context' => 
  array (
    'link' => 'bhea_sessions_bhea_sponsorship_types_1',
  ),
);

// created: 2013-12-18 19:46:27
$viewdefs['bhea_Sponsorship_Types']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_BHEA_EVENTS_BHEA_SPONSORSHIP_TYPES_1_FROM_BHEA_EVENTS_TITLE',
  'context' => 
  array (
    'link' => 'bhea_events_bhea_sponsorship_types_1',
  ),
);

//auto-generated file DO NOT EDIT
$viewdefs['bhea_Sponsorship_Types']['base']['layout']['subpanels']['components'][]['override_subpanel_list_view'] = array (
  'link' => 'bhea_events_bhea_sponsorship_types_1',
  'view' => 'subpanel-for-bhea_sponsorship_types',
);


//auto-generated file DO NOT EDIT
$viewdefs['bhea_Sponsorship_Types']['base']['layout']['subpanels']['components'][]['override_subpanel_list_view'] = array (
  'link' => 'bhea_sponsorship_types_opportunities_1',
  'view' => 'subpanel-for-bhea_sponsorship_types',
);


//auto-generated file DO NOT EDIT
$viewdefs['bhea_Sponsorship_Types']['base']['layout']['subpanels']['components'][]['override_subpanel_list_view'] = array (
  'link' => 'bhea_sponsorship_types_bhea_sponsorship_1',
  'view' => 'subpanel-for-bhea_sponsorship_types',
);


//auto-generated file DO NOT EDIT
$viewdefs['bhea_Sponsorship_Types']['base']['layout']['subpanels']['components'][]['override_subpanel_list_view'] = array (
  'link' => 'bhea_sessions_bhea_sponsorship_types_1',
  'view' => 'subpanel-for-bhea_sponsorship_types',
);
