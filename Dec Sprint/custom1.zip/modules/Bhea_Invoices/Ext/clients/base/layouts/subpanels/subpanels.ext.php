<?php
// WARNING: The contents of this file are auto-generated.


// created: 2013-12-03 15:38:48
$viewdefs['Bhea_Invoices']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_BHEA_INVOICES_BHEA_PAYMENTS_1_FROM_BHEA_PAYMENTS_TITLE',
  'context' => 
  array (
    'link' => 'bhea_invoices_bhea_payments_1',
  ),
);

//auto-generated file DO NOT EDIT
$viewdefs['Bhea_Invoices']['base']['layout']['subpanels']['components'][]['override_subpanel_list_view'] = array (
  'link' => 'bhea_invoices_bhea_payments_1',
  'view' => 'subpanel-for-bhea_invoices',
);
