<?php
// WARNING: The contents of this file are auto-generated.


//THIS FILE IS AUTO GENERATED, DO NOT MODIFY
$mod_strings['LBL_BHEA_PROGRAM_BHEA_PROGRAM_CATALOGUE_1_FROM_BHEA_PROGRAM_TITLE'] = 'Program';
