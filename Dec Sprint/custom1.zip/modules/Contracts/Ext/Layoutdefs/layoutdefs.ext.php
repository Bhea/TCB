<?php
// WARNING: The contents of this file are auto-generated.


//auto-generated file DO NOT EDIT
$layout_defs['Contracts']['subpanel_setup']['contacts']['override_subpanel_name'] = 'Contract_subpanel_contacts';


//auto-generated file DO NOT EDIT
$layout_defs['Contracts']['subpanel_setup']['contracts_documents']['override_subpanel_name'] = 'Contract_subpanel_contracts_documents';
