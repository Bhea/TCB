<?php
// WARNING: The contents of this file are auto-generated.


//THIS FILE IS AUTO GENERATED, DO NOT MODIFY
$mod_strings['LBL_BHEA_CONTRACTORS_CONTRACTS_1_FROM_BHEA_CONTRACTORS_TITLE'] = 'Contractors';
