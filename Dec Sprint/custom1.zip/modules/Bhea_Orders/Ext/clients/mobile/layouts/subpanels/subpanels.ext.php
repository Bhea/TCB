<?php
// WARNING: The contents of this file are auto-generated.


// created: 2013-12-24 09:35:41
$viewdefs['Bhea_Orders']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_BHEA_ORDERS_BHEA_INVOICES_1_FROM_BHEA_INVOICES_TITLE',
  'context' => 
  array (
    'link' => 'bhea_orders_bhea_invoices_1',
  ),
);

// created: 2013-12-09 10:02:24
$viewdefs['Bhea_Orders']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_BHEA_ORDERS_BHEA_PAYMENTS_1_FROM_BHEA_PAYMENTS_TITLE',
  'context' => 
  array (
    'link' => 'bhea_orders_bhea_payments_1',
  ),
);