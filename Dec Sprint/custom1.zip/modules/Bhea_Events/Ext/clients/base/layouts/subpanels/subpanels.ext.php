<?php
// WARNING: The contents of this file are auto-generated.


// created: 2013-12-03 09:43:13
$viewdefs['Bhea_Events']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_BHEA_EVENTS_BHEA_REGISTRANTS_1_FROM_BHEA_REGISTRANTS_TITLE',
  'context' => 
  array (
    'link' => 'bhea_events_bhea_registrants_1',
  ),
);

// created: 2013-12-03 15:33:08
$viewdefs['Bhea_Events']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_LEADS_BHEA_EVENTS_1_FROM_LEADS_TITLE',
  'context' => 
  array (
    'link' => 'leads_bhea_events_1',
  ),
);

// created: 2013-12-03 09:28:39
$viewdefs['Bhea_Events']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_BHEA_EVENTS_BHEA_SPONSORSHIP_1_FROM_BHEA_SPONSORSHIP_TITLE',
  'context' => 
  array (
    'link' => 'bhea_events_bhea_sponsorship_1',
  ),
);

// created: 2013-12-03 16:00:53
$viewdefs['Bhea_Events']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_BHEA_EVENTS_BHEA_SPONSOR_1_FROM_BHEA_SPONSOR_TITLE',
  'context' => 
  array (
    'link' => 'bhea_events_bhea_sponsor_1',
  ),
);

// created: 2013-12-03 12:00:39
$viewdefs['Bhea_Events']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_BHEA_EVENTS_CAMPAIGNS_1_FROM_CAMPAIGNS_TITLE',
  'context' => 
  array (
    'link' => 'bhea_events_campaigns_1',
  ),
);

// created: 2013-12-04 12:54:45
$viewdefs['Bhea_Events']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_BHEA_CONTRACTORS_BHEA_EVENTS_1_FROM_BHEA_CONTRACTORS_TITLE',
  'context' => 
  array (
    'link' => 'bhea_contractors_bhea_events_1',
  ),
);

// created: 2013-12-16 15:30:32
$viewdefs['Bhea_Events']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_BHEA_EVENTS_BHEA_EVENT_FEE_1_FROM_BHEA_EVENT_FEE_TITLE',
  'context' => 
  array (
    'link' => 'bhea_events_bhea_event_fee_1',
  ),
);

// created: 2013-12-03 09:12:01
$viewdefs['Bhea_Events']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_BHEA_EVENTS_BHEA_SPEAKERS_1_FROM_BHEA_SPEAKERS_TITLE',
  'context' => 
  array (
    'link' => 'bhea_events_bhea_speakers_1',
  ),
);

// created: 2013-12-03 12:02:10
$viewdefs['Bhea_Events']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_BHEA_EVENTS_OPPORTUNITIES_1_FROM_OPPORTUNITIES_TITLE',
  'context' => 
  array (
    'link' => 'bhea_events_opportunities_1',
  ),
);

// created: 2013-12-18 19:46:27
$viewdefs['Bhea_Events']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_BHEA_EVENTS_BHEA_SPONSORSHIP_TYPES_1_FROM_BHEA_SPONSORSHIP_TYPES_TITLE',
  'context' => 
  array (
    'link' => 'bhea_events_bhea_sponsorship_types_1',
  ),
);

// created: 2013-12-03 12:23:01
$viewdefs['Bhea_Events']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_BHEA_EVENTS_BHEA_EVENTS_1_FROM_BHEA_EVENTS_R_TITLE',
  'context' => 
  array (
    'link' => 'bhea_events_bhea_events_1',
  ),
);

// created: 2013-12-03 12:04:19
$viewdefs['Bhea_Events']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_BHEA_EVENTS_BHEA_SESSIONS_1_FROM_BHEA_SESSIONS_TITLE',
  'context' => 
  array (
    'link' => 'bhea_events_bhea_sessions_1',
  ),
);

//auto-generated file DO NOT EDIT
$viewdefs['Bhea_Events']['base']['layout']['subpanels']['components'][]['override_subpanel_list_view'] = array (
  'link' => 'bhea_events_campaigns_1',
  'view' => 'subpanel-for-bhea_events',
);


//auto-generated file DO NOT EDIT
$viewdefs['Bhea_Events']['base']['layout']['subpanels']['components'][]['override_subpanel_list_view'] = array (
  'link' => 'bhea_events_bhea_registrants_1',
  'view' => 'subpanel-for-bhea_events',
);


//auto-generated file DO NOT EDIT
$viewdefs['Bhea_Events']['base']['layout']['subpanels']['components'][]['override_subpanel_list_view'] = array (
  'link' => 'bhea_events_bhea_sponsorship_types_1',
  'view' => 'subpanel-for-bhea_events',
);


//auto-generated file DO NOT EDIT
$viewdefs['Bhea_Events']['base']['layout']['subpanels']['components'][]['override_subpanel_list_view'] = array (
  'link' => 'bhea_events_bhea_speakers_1',
  'view' => 'subpanel-for-bhea_events',
);


//auto-generated file DO NOT EDIT
$viewdefs['Bhea_Events']['base']['layout']['subpanels']['components'][]['override_subpanel_list_view'] = array (
  'link' => 'bhea_events_bhea_sessions_1',
  'view' => 'subpanel-for-bhea_events',
);


//auto-generated file DO NOT EDIT
$viewdefs['Bhea_Events']['base']['layout']['subpanels']['components'][]['override_subpanel_list_view'] = array (
  'link' => 'bhea_events_bhea_sponsor_1',
  'view' => 'subpanel-for-bhea_events',
);


//auto-generated file DO NOT EDIT
$viewdefs['Bhea_Events']['base']['layout']['subpanels']['components'][]['override_subpanel_list_view'] = array (
  'link' => 'bhea_events_opportunities_1',
  'view' => 'subpanel-for-bhea_events',
);


//auto-generated file DO NOT EDIT
$viewdefs['Bhea_Events']['base']['layout']['subpanels']['components'][]['override_subpanel_list_view'] = array (
  'link' => 'bhea_events_bhea_events_1',
  'view' => 'subpanel-for-bhea_events',
);


//auto-generated file DO NOT EDIT
$viewdefs['Bhea_Events']['base']['layout']['subpanels']['components'][]['override_subpanel_list_view'] = array (
  'link' => 'bhea_events_bhea_sponsorship_1',
  'view' => 'subpanel-for-bhea_events',
);


//auto-generated file DO NOT EDIT
$viewdefs['Bhea_Events']['base']['layout']['subpanels']['components'][]['override_subpanel_list_view'] = array (
  'link' => 'bhea_events_bhea_event_fee_1',
  'view' => 'subpanel-for-bhea_events',
);


//auto-generated file DO NOT EDIT
$viewdefs['Bhea_Events']['base']['layout']['subpanels']['components'][]['override_subpanel_list_view'] = array (
  'link' => 'bhea_contractors_bhea_events_1',
  'view' => 'subpanel-for-bhea_events',
);
