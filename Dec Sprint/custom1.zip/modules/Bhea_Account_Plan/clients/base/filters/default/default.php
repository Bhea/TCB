<?php
// created: 2013-12-01 11:51:59
$viewdefs['Bhea_Account_Plan']['base']['filter']['default'] = array (
  'default_filter' => 'all_records',
  'fields' => 
  array (
    'name' => 
    array (
    ),
    'plan_id' => 
    array (
    ),
    'activity_name' => 
    array (
    ),
  ),
);