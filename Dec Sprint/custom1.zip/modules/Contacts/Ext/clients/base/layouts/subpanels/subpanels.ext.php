<?php
// WARNING: The contents of this file are auto-generated.


// created: 2013-12-04 09:46:31
$viewdefs['Contacts']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_CONTACTS_BHEA_SESSIONS_1_FROM_BHEA_SESSIONS_TITLE',
  'context' => 
  array (
    'link' => 'contacts_bhea_sessions_1',
  ),
);

//auto-generated file DO NOT EDIT
$viewdefs['Contacts']['base']['layout']['subpanels']['components'][]['override_subpanel_list_view'] = array (
  'link' => 'opportunities',
  'view' => 'subpanel-for-contacts',
);


//auto-generated file DO NOT EDIT
$viewdefs['Contacts']['base']['layout']['subpanels']['components'][]['override_subpanel_list_view'] = array (
  'link' => 'contacts_bhea_sessions_1',
  'view' => 'subpanel-for-contacts',
);


//auto-generated file DO NOT EDIT
$viewdefs['Contacts']['base']['layout']['subpanels']['components'][]['override_subpanel_list_view'] = array (
  'link' => 'campaigns',
  'view' => 'subpanel-for-contacts',
);


//auto-generated file DO NOT EDIT
$viewdefs['Contacts']['base']['layout']['subpanels']['components'][]['override_subpanel_list_view'] = array (
  'link' => 'direct_reports',
  'view' => 'subpanel-for-contacts',
);


//auto-generated file DO NOT EDIT
$viewdefs['Contacts']['base']['layout']['subpanels']['components'][]['override_subpanel_list_view'] = array (
  'link' => 'documents',
  'view' => 'subpanel-for-contacts',
);


//auto-generated file DO NOT EDIT
$viewdefs['Contacts']['base']['layout']['subpanels']['components'][]['override_subpanel_list_view'] = array (
  'link' => 'leads',
  'view' => 'subpanel-for-contacts',
);


//auto-generated file DO NOT EDIT
$viewdefs['Contacts']['base']['layout']['subpanels']['components'][]['override_subpanel_list_view'] = array (
  'link' => 'cases',
  'view' => 'subpanel-for-contacts',
);


//auto-generated file DO NOT EDIT
$viewdefs['Contacts']['base']['layout']['subpanels']['components'][]['override_subpanel_list_view'] = array (
  'link' => 'quotes',
  'view' => 'subpanel-for-contacts',
);
