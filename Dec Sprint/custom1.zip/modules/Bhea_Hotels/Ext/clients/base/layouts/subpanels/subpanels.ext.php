<?php
// WARNING: The contents of this file are auto-generated.


// created: 2013-12-04 09:54:49
$viewdefs['Bhea_Hotels']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_BHEA_HOTELS_BHEA_EVENTS_1_FROM_BHEA_EVENTS_TITLE',
  'context' => 
  array (
    'link' => 'bhea_hotels_bhea_events_1',
  ),
);

//auto-generated file DO NOT EDIT
$viewdefs['Bhea_Hotels']['base']['layout']['subpanels']['components'][]['override_subpanel_list_view'] = array (
  'link' => 'bhea_hotels_bhea_events_1',
  'view' => 'subpanel-for-bhea_hotels',
);
