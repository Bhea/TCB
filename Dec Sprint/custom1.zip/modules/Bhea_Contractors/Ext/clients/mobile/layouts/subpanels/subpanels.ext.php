<?php
// WARNING: The contents of this file are auto-generated.


// created: 2013-12-09 19:01:27
$viewdefs['Bhea_Contractors']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_BHEA_CONTRACTORS_CONTRACTS_1_FROM_CONTRACTS_TITLE',
  'context' => 
  array (
    'link' => 'bhea_contractors_contracts_1',
  ),
);

// created: 2013-12-04 12:54:45
$viewdefs['Bhea_Contractors']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_BHEA_CONTRACTORS_BHEA_EVENTS_1_FROM_BHEA_EVENTS_TITLE',
  'context' => 
  array (
    'link' => 'bhea_contractors_bhea_events_1',
  ),
);

// created: 2013-12-20 11:10:57
$viewdefs['Bhea_Contractors']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_BHEA_SESSIONS_BHEA_CONTRACTORS_1_FROM_BHEA_SESSIONS_TITLE',
  'context' => 
  array (
    'link' => 'bhea_sessions_bhea_contractors_1',
  ),
);