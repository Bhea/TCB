<?php
// WARNING: The contents of this file are auto-generated.


// created: 2013-12-18 14:29:55
$viewdefs['Bhea_finance_performance']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_BHEA_FINANCE_PERFORMANCE_DOCUMENTS_1_FROM_DOCUMENTS_TITLE',
  'context' => 
  array (
    'link' => 'bhea_finance_performance_documents_1',
  ),
);