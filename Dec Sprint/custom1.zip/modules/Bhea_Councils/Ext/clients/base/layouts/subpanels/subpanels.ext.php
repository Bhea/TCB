<?php
// WARNING: The contents of this file are auto-generated.


// created: 2013-12-03 09:12:57
$viewdefs['Bhea_Councils']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_BHEA_COUNCILS_BHEA_COUNCIL_MEMBERS_1_FROM_BHEA_COUNCIL_MEMBERS_TITLE',
  'context' => 
  array (
    'link' => 'bhea_councils_bhea_council_members_1',
  ),
);

// created: 2013-12-03 09:19:31
$viewdefs['Bhea_Councils']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_BHEA_COUNCILS_BHEA_COUNCIL_MEMBERSHIPS_1_FROM_BHEA_COUNCIL_MEMBERSHIPS_TITLE',
  'context' => 
  array (
    'link' => 'bhea_councils_bhea_council_memberships_1',
  ),
);

// created: 2013-12-17 10:30:19
$viewdefs['Bhea_Councils']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_BHEA_COUNCILS_BHEA_COUNCIL_MEMBERS_2_FROM_BHEA_COUNCIL_MEMBERS_TITLE',
  'context' => 
  array (
    'link' => 'bhea_councils_bhea_council_members_2',
  ),
);

// created: 2013-12-09 10:28:51
$viewdefs['Bhea_Councils']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_BHEA_COUNCILS_OPPORTUNITIES_1_FROM_OPPORTUNITIES_TITLE',
  'context' => 
  array (
    'link' => 'bhea_councils_opportunities_1',
  ),
);

//auto-generated file DO NOT EDIT
$viewdefs['Bhea_Councils']['base']['layout']['subpanels']['components'][]['override_subpanel_list_view'] = array (
  'link' => 'bhea_councils_bhea_council_memberships_1',
  'view' => 'subpanel-for-bhea_councils',
);


//auto-generated file DO NOT EDIT
$viewdefs['Bhea_Councils']['base']['layout']['subpanels']['components'][]['override_subpanel_list_view'] = array (
  'link' => 'bhea_councils_bhea_council_members_1',
  'view' => 'subpanel-for-bhea_councils',
);
