<?php
// WARNING: The contents of this file are auto-generated.


// created: 2013-12-09 18:32:18
$viewdefs['Bhea_Council_Members']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_BHEA_COUNCIL_MEMBERS_BHEA_COUNCIL_MEMBERSHIPS_1_FROM_BHEA_COUNCIL_MEMBERSHIPS_TITLE',
  'context' => 
  array (
    'link' => 'bhea_council_members_bhea_council_memberships_1',
  ),
);

// created: 2013-12-13 10:34:26
$viewdefs['Bhea_Council_Members']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_BHEA_COUNCIL_MEMBERS_BHEA_ORDERS_1_FROM_BHEA_ORDERS_TITLE',
  'context' => 
  array (
    'link' => 'bhea_council_members_bhea_orders_1',
  ),
);