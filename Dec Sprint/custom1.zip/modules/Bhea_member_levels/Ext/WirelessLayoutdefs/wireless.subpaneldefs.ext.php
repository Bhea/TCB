<?php
// WARNING: The contents of this file are auto-generated.


 // created: 2013-12-03 12:10:50
$layout_defs["Bhea_member_levels"]["subpanel_setup"]['bhea_member_levels_bhea_memberships_1'] = array (
  'order' => 100,
  'module' => 'Bhea_Memberships',
  'subpanel_name' => 'default',
  'title_key' => 'LBL_BHEA_MEMBER_LEVELS_BHEA_MEMBERSHIPS_1_FROM_BHEA_MEMBERSHIPS_TITLE',
  'get_subpanel_data' => 'bhea_member_levels_bhea_memberships_1',
);


 // created: 2013-12-09 16:42:05
$layout_defs["Bhea_member_levels"]["subpanel_setup"]['bhea_member_levels_opportunities_1'] = array (
  'order' => 100,
  'module' => 'Opportunities',
  'subpanel_name' => 'default',
  'title_key' => 'LBL_BHEA_MEMBER_LEVELS_OPPORTUNITIES_1_FROM_OPPORTUNITIES_TITLE',
  'get_subpanel_data' => 'bhea_member_levels_opportunities_1',
);


 // created: 2013-12-04 16:32:17
$layout_defs["Bhea_member_levels"]["subpanel_setup"]['bhea_member_levels_bhea_councils_1'] = array (
  'order' => 100,
  'module' => 'Bhea_Councils',
  'subpanel_name' => 'default',
  'title_key' => 'LBL_BHEA_MEMBER_LEVELS_BHEA_COUNCILS_1_FROM_BHEA_COUNCILS_TITLE',
  'get_subpanel_data' => 'bhea_member_levels_bhea_councils_1',
);


 // created: 2013-12-03 10:35:58
$layout_defs["Bhea_member_levels"]["subpanel_setup"]['bhea_member_levels_bhea_council_memberships_1'] = array (
  'order' => 100,
  'module' => 'Bhea_Council_Memberships',
  'subpanel_name' => 'default',
  'title_key' => 'LBL_BHEA_MEMBER_LEVELS_BHEA_COUNCIL_MEMBERSHIPS_1_FROM_BHEA_COUNCIL_MEMBERSHIPS_TITLE',
  'get_subpanel_data' => 'bhea_member_levels_bhea_council_memberships_1',
);


 // created: 2013-12-16 10:10:55
$layout_defs["Bhea_member_levels"]["subpanel_setup"]['bhea_member_levels_bhea_pricing_line_item_1'] = array (
  'order' => 100,
  'module' => 'Bhea_Pricing_Line_Item',
  'subpanel_name' => 'default',
  'title_key' => 'LBL_BHEA_MEMBER_LEVELS_BHEA_PRICING_LINE_ITEM_1_FROM_BHEA_PRICING_LINE_ITEM_TITLE',
  'get_subpanel_data' => 'bhea_member_levels_bhea_pricing_line_item_1',
);
