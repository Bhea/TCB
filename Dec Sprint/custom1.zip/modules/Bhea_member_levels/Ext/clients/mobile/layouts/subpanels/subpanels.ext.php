<?php
// WARNING: The contents of this file are auto-generated.


// created: 2013-12-03 12:10:50
$viewdefs['Bhea_member_levels']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_BHEA_MEMBER_LEVELS_BHEA_MEMBERSHIPS_1_FROM_BHEA_MEMBERSHIPS_TITLE',
  'context' => 
  array (
    'link' => 'bhea_member_levels_bhea_memberships_1',
  ),
);

// created: 2013-12-09 16:42:05
$viewdefs['Bhea_member_levels']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_BHEA_MEMBER_LEVELS_OPPORTUNITIES_1_FROM_OPPORTUNITIES_TITLE',
  'context' => 
  array (
    'link' => 'bhea_member_levels_opportunities_1',
  ),
);

// created: 2013-12-16 10:10:55
$viewdefs['Bhea_member_levels']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_BHEA_MEMBER_LEVELS_BHEA_PRICING_LINE_ITEM_1_FROM_BHEA_PRICING_LINE_ITEM_TITLE',
  'context' => 
  array (
    'link' => 'bhea_member_levels_bhea_pricing_line_item_1',
  ),
);