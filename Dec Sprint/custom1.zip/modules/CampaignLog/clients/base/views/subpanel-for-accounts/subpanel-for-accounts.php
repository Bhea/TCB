<?php
// created: 2013-12-03 12:01:42
$viewdefs['CampaignLog']['base']['view']['subpanel-for-accounts'] = array (
  'favorite' => false,
  'selection' => 
  array (
  ),
  'rowactions' => 
  array (
  ),
  'panels' => 
  array (
    0 => 
    array (
      'name' => 'panel_header',
      'label' => 'LBL_PANEL_1',
      'fields' => 
      array (
        0 => 
        array (
          'label' => 'LBL_LIST_CAMPAIGN_NAME',
          'enabled' => true,
          'default' => true,
          'name' => 'campaign_name1',
        ),
        1 => 
        array (
          'name' => 'target_id',
          'label' => 'LBL_TARGET_ID',
          'enabled' => true,
          'default' => true,
        ),
        2 => 
        array (
          'name' => 'related_id',
          'label' => 'LBL_RELATED_ID',
          'enabled' => true,
          'default' => true,
        ),
        3 => 
        array (
          'name' => 'campaign_name',
          'label' => '',
          'enabled' => true,
          'default' => true,
        ),
        4 => 
        array (
          'name' => 'marketing_name',
          'label' => '',
          'enabled' => true,
          'default' => true,
        ),
        5 => 
        array (
          'name' => 'recipient_name',
          'label' => '',
          'enabled' => true,
          'default' => true,
        ),
        6 => 
        array (
          'label' => 'LBL_ACTIVITY_TYPE',
          'enabled' => true,
          'default' => true,
          'name' => 'activity_type',
        ),
        7 => 
        array (
          'label' => 'LBL_ACTIVITY_DATE',
          'enabled' => true,
          'default' => true,
          'name' => 'activity_date',
        ),
        8 => 
        array (
          'label' => 'LBL_RELATED',
          'enabled' => true,
          'default' => true,
          'name' => 'related_name',
          'type' => 'parent',
          'related_fields' => 
          array (
            0 => 'parent_id',
            1 => 'parent_type',
          ),
        ),
      ),
    ),
  ),
  'type' => 'subpanel-list',
);