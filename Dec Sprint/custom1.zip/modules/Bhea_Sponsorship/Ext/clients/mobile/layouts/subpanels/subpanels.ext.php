<?php
// WARNING: The contents of this file are auto-generated.


// created: 2013-12-20 10:48:26
$viewdefs['Bhea_Sponsorship']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_BHEA_SESSIONS_BHEA_SPONSORSHIP_1_FROM_BHEA_SESSIONS_TITLE',
  'context' => 
  array (
    'link' => 'bhea_sessions_bhea_sponsorship_1',
  ),
);