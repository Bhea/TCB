<?php
// WARNING: The contents of this file are auto-generated.


// created: 2013-12-20 10:48:26
$viewdefs['Bhea_Sponsorship']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_BHEA_SESSIONS_BHEA_SPONSORSHIP_1_FROM_BHEA_SESSIONS_TITLE',
  'context' => 
  array (
    'link' => 'bhea_sessions_bhea_sponsorship_1',
  ),
);

//auto-generated file DO NOT EDIT
$viewdefs['Bhea_Sponsorship']['base']['layout']['subpanels']['components'][]['override_subpanel_list_view'] = array (
  'link' => 'bhea_sessions_bhea_sponsorship_1',
  'view' => 'subpanel-for-bhea_sponsorship',
);
