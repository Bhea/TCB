<?php
// WARNING: The contents of this file are auto-generated.


// created: 2013-12-04 09:46:31
$viewdefs['Bhea_Sessions']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_CONTACTS_BHEA_SESSIONS_1_FROM_CONTACTS_TITLE',
  'context' => 
  array (
    'link' => 'contacts_bhea_sessions_1',
  ),
);

// created: 2013-12-03 09:42:33
$viewdefs['Bhea_Sessions']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_BHEA_SESSIONS_BHEA_REGISTRANTS_1_FROM_BHEA_REGISTRANTS_TITLE',
  'context' => 
  array (
    'link' => 'bhea_sessions_bhea_registrants_1',
  ),
);

// created: 2013-12-26 09:17:42
$viewdefs['Bhea_Sessions']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_BHEA_SPEAKERS_BHEA_SESSIONS_1_FROM_BHEA_SPEAKERS_TITLE',
  'context' => 
  array (
    'link' => 'bhea_speakers_bhea_sessions_1',
  ),
);

// created: 2013-12-20 10:46:46
$viewdefs['Bhea_Sessions']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_BHEA_SESSIONS_BHEA_SPONSOR_1_FROM_BHEA_SPONSOR_TITLE',
  'context' => 
  array (
    'link' => 'bhea_sessions_bhea_sponsor_1',
  ),
);

// created: 2013-12-20 10:48:26
$viewdefs['Bhea_Sessions']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_BHEA_SESSIONS_BHEA_SPONSORSHIP_1_FROM_BHEA_SPONSORSHIP_TITLE',
  'context' => 
  array (
    'link' => 'bhea_sessions_bhea_sponsorship_1',
  ),
);

// created: 2013-12-19 18:57:27
$viewdefs['Bhea_Sessions']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_OPPORTUNITIES_BHEA_SESSIONS_1_FROM_OPPORTUNITIES_TITLE',
  'context' => 
  array (
    'link' => 'opportunities_bhea_sessions_1',
  ),
);

// created: 2013-12-18 19:54:10
$viewdefs['Bhea_Sessions']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_BHEA_SESSIONS_BHEA_SPONSORSHIP_TYPES_1_FROM_BHEA_SPONSORSHIP_TYPES_TITLE',
  'context' => 
  array (
    'link' => 'bhea_sessions_bhea_sponsorship_types_1',
  ),
);

// created: 2013-12-20 11:10:57
$viewdefs['Bhea_Sessions']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_BHEA_SESSIONS_BHEA_CONTRACTORS_1_FROM_BHEA_CONTRACTORS_TITLE',
  'context' => 
  array (
    'link' => 'bhea_sessions_bhea_contractors_1',
  ),
);

//auto-generated file DO NOT EDIT
$viewdefs['Bhea_Sessions']['base']['layout']['subpanels']['components'][]['override_subpanel_list_view'] = array (
  'link' => 'contacts_bhea_sessions_1',
  'view' => 'subpanel-for-bhea_sessions',
);


//auto-generated file DO NOT EDIT
$viewdefs['Bhea_Sessions']['base']['layout']['subpanels']['components'][]['override_subpanel_list_view'] = array (
  'link' => 'bhea_sessions_bhea_sponsorship_types_1',
  'view' => 'subpanel-for-bhea_sessions',
);


//auto-generated file DO NOT EDIT
$viewdefs['Bhea_Sessions']['base']['layout']['subpanels']['components'][]['override_subpanel_list_view'] = array (
  'link' => 'bhea_sessions_bhea_registrants_1',
  'view' => 'subpanel-for-bhea_sessions',
);
