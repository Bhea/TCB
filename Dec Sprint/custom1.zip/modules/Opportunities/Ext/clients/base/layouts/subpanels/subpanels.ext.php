<?php
// WARNING: The contents of this file are auto-generated.


// created: 2013-12-03 10:39:15
$viewdefs['Opportunities']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_OPPORTUNITIES_BHEA_PROGRAM_1_FROM_BHEA_PROGRAM_TITLE',
  'context' => 
  array (
    'link' => 'opportunities_bhea_program_1',
  ),
);

// created: 2013-12-19 18:57:27
$viewdefs['Opportunities']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_OPPORTUNITIES_BHEA_SESSIONS_1_FROM_BHEA_SESSIONS_TITLE',
  'context' => 
  array (
    'link' => 'opportunities_bhea_sessions_1',
  ),
);

//auto-generated file DO NOT EDIT
$viewdefs['Opportunities']['base']['layout']['subpanels']['components'][]['override_subpanel_list_view'] = array (
  'link' => 'contacts',
  'view' => 'subpanel-for-opportunities',
);


//auto-generated file DO NOT EDIT
$viewdefs['Opportunities']['base']['layout']['subpanels']['components'][]['override_subpanel_list_view'] = array (
  'link' => 'opportunities_bhea_program_1',
  'view' => 'subpanel-for-opportunities',
);


//auto-generated file DO NOT EDIT
$viewdefs['Opportunities']['base']['layout']['subpanels']['components'][]['override_subpanel_list_view'] = array (
  'link' => 'documents',
  'view' => 'subpanel-for-opportunities',
);


//auto-generated file DO NOT EDIT
$viewdefs['Opportunities']['base']['layout']['subpanels']['components'][]['override_subpanel_list_view'] = array (
  'link' => 'leads',
  'view' => 'subpanel-for-opportunities',
);


//auto-generated file DO NOT EDIT
$viewdefs['Opportunities']['base']['layout']['subpanels']['components'][]['override_subpanel_list_view'] = array (
  'link' => 'opportunities_bhea_sessions_1',
  'view' => 'subpanel-for-opportunities',
);


//auto-generated file DO NOT EDIT
$viewdefs['Opportunities']['base']['layout']['subpanels']['components'][]['override_subpanel_list_view'] = array (
  'link' => 'quotes',
  'view' => 'subpanel-for-opportunities',
);
