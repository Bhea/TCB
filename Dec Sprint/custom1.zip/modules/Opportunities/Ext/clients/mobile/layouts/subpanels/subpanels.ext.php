<?php
// WARNING: The contents of this file are auto-generated.


// created: 2013-12-03 10:39:15
$viewdefs['Opportunities']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_OPPORTUNITIES_BHEA_PROGRAM_1_FROM_BHEA_PROGRAM_TITLE',
  'context' => 
  array (
    'link' => 'opportunities_bhea_program_1',
  ),
);

// created: 2013-12-19 18:57:27
$viewdefs['Opportunities']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_OPPORTUNITIES_BHEA_SESSIONS_1_FROM_BHEA_SESSIONS_TITLE',
  'context' => 
  array (
    'link' => 'opportunities_bhea_sessions_1',
  ),
);