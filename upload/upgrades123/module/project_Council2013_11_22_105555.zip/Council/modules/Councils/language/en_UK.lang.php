<?php
/*********************************************************************************
 * By installing or using this file, you are confirming on behalf of the entity
 * subscribed to the SugarCRM Inc. product ("Company") that Company is bound by
 * the SugarCRM Inc. Master Subscription Agreement (“MSA”), which is viewable at:
 * http://www.sugarcrm.com/master-subscription-agreement
 *
 * If Company is not bound by the MSA, then by installing or using this file
 * you are agreeing unconditionally that Company will be bound by the MSA and
 * certifying that you have authority to bind Company accordingly.
 *
 * Copyright (C) 2004-2013 SugarCRM Inc.  All rights reserved.
 ********************************************************************************/

$mod_strings = array (
  'LBL_TEAM' => 'Teams',
  'LBL_TEAMS' => 'Teams',
  'LBL_TEAM_ID' => 'Team Id',
  'LBL_ASSIGNED_TO_ID' => 'Assigned User Id',
  'LBL_ASSIGNED_TO_NAME' => 'Assigned to',
  'LBL_CREATED' => 'Created By',
  'LBL_CREATED_ID' => 'Created By Id',
  'LBL_CREATED_USER' => 'Created by User',
  'LBL_DATE_ENTERED' => 'Date Created',
  'LBL_DATE_MODIFIED' => 'Date Modified',
  'LBL_DELETED' => 'Deleted',
  'LBL_DESCRIPTION' => 'Description',
  'LBL_EDIT_BUTTON' => 'Edit',
  'LBL_ID' => 'ID',
  'LBL_LIST_NAME' => 'Name',
  'LBL_MODIFIED' => 'Modified By',
  'LBL_MODIFIED_ID' => 'Modified By Id',
  'LBL_MODIFIED_NAME' => 'Modified By Name',
  'LBL_MODIFIED_USER' => 'Modified by User',
  'LBL_NAME' => 'Name',
  'LBL_REMOVE' => 'Remove',
  'LBL_LIST_FORM_TITLE' => 'Councils List',
  'LBL_MODULE_NAME' => 'Councils',
  'LBL_MODULE_TITLE' => 'Councils',
  'LBL_HOMEPAGE_TITLE' => 'My Councils',
  'LNK_NEW_RECORD' => 'Create Councils',
  'LNK_LIST' => 'View Councils',
  'LNK_IMPORT_BHEA_COUNCIL' => 'Import Councils',
  'LBL_SEARCH_FORM_TITLE' => 'Search Councils',
  'LBL_HISTORY_SUBPANEL_TITLE' => 'View History',
  'LBL_ACTIVITIES_SUBPANEL_TITLE' => 'Activities',
  'LBL_BHEA_COUNCIL_SUBPANEL_TITLE' => 'Councils',
  'LBL_NEW_FORM_TITLE' => 'New Councils',
  'LBL_STATUS' => 'Status',
  'LBL_KNOWLEDGE_AREA ' => 'Knowledge Area ',
  'LBL_PLAN_MEMBER_CNT ' => 'Planned Member Count ',
  'LBL_CUR_MEMBER_CNT' => 'Current Member  Count ',
  'LBL_START_DATE ' => 'Start Date ',
  'LBL_TYPE ' => 'Type',
  'LBL_MEMBER_RENEWAL_FEE ' => 'Member Renewal  Fee ',
  'LBL_MEMBERSHIP_FEE ' => 'Membership Fee ',
  'LBL_ELECTION_DATE' => 'Election Date',
  'LBL_END_DATE ' => 'End Date',
  'LBL_MEETINGS_PER_YEAR ' => 'Meetings Per Year',
  'LBL_GROUP_CATEGORY ' => 'Group Category ',
  'LBL_COUNCIL_DIRECTORY ' => 'Council Directory',
  'LBL_COUNCIL_URL' => 'Council URL',
  'LBL_COUNCIL_SUB_REGION ' => 'Council Sub Region',
  'LNK_IMPORT_BHEA_COUNCILS' => 'Import Councils',
  'LBL_BHEA_COUNCILS_SUBPANEL_TITLE' => 'Councils',
);