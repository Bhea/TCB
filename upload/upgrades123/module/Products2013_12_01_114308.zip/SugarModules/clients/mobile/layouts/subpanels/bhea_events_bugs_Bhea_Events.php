<?php
// created: 2013-12-01 11:06:18
$viewdefs['Bhea_Events']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_BHEA_EVENTS_BUGS_FROM_BUGS_TITLE',
  'context' => 
  array (
    'link' => 'bhea_events_bugs',
  ),
);