<?php
// created: 2013-12-01 11:06:18
$dictionary["Bhea_Events"]["fields"]["bhea_events_bugs"] = array (
  'name' => 'bhea_events_bugs',
  'type' => 'link',
  'relationship' => 'bhea_events_bugs',
  'source' => 'non-db',
  'module' => 'Bugs',
  'bean_name' => 'Bug',
  'vname' => 'LBL_BHEA_EVENTS_BUGS_FROM_BHEA_EVENTS_TITLE',
  'id_name' => 'bhea_events_bugsbhea_events_ida',
  'link-type' => 'many',
  'side' => 'left',
);
