<?php
 // created: 2013-12-01 11:06:18
$layout_defs["Bhea_Events"]["subpanel_setup"]['bhea_events_bugs'] = array (
  'order' => 100,
  'module' => 'Bugs',
  'subpanel_name' => 'default',
  'title_key' => 'LBL_BHEA_EVENTS_BUGS_FROM_BUGS_TITLE',
  'get_subpanel_data' => 'bhea_events_bugs',
);
