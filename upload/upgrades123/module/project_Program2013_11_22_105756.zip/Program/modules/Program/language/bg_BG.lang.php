<?php
/*********************************************************************************
 * By installing or using this file, you are confirming on behalf of the entity
 * subscribed to the SugarCRM Inc. product ("Company") that Company is bound by
 * the SugarCRM Inc. Master Subscription Agreement (“MSA”), which is viewable at:
 * http://www.sugarcrm.com/master-subscription-agreement
 *
 * If Company is not bound by the MSA, then by installing or using this file
 * you are agreeing unconditionally that Company will be bound by the MSA and
 * certifying that you have authority to bind Company accordingly.
 *
 * Copyright (C) 2004-2013 SugarCRM Inc.  All rights reserved.
 ********************************************************************************/

$mod_strings = array (
  'LBL_TEAM' => 'Екип',
  'LBL_TEAMS' => 'Екип',
  'LBL_TEAM_ID' => 'Екип',
  'LBL_ASSIGNED_TO_ID' => 'Отговорник',
  'LBL_ASSIGNED_TO_NAME' => 'Потребител',
  'LBL_CREATED' => 'Създадено от',
  'LBL_CREATED_ID' => 'Създадено от',
  'LBL_CREATED_USER' => 'Създадено от потребител',
  'LBL_DATE_ENTERED' => 'Създадено на',
  'LBL_DATE_MODIFIED' => 'Модифицирано на',
  'LBL_DELETED' => 'Изтрити',
  'LBL_DESCRIPTION' => 'Описание',
  'LBL_EDIT_BUTTON' => 'Редактирай',
  'LBL_ID' => 'Идентификатор',
  'LBL_LIST_NAME' => 'Име',
  'LBL_MODIFIED' => 'Модифицирано от',
  'LBL_MODIFIED_ID' => 'Модифицирано от',
  'LBL_MODIFIED_NAME' => 'Модифицирано от',
  'LBL_MODIFIED_USER' => 'Модифицирано от потребител',
  'LBL_NAME' => 'Име',
  'LBL_REMOVE' => 'Премахни',
  'LBL_LIST_FORM_TITLE' => 'Program Списък',
  'LBL_MODULE_NAME' => 'Program',
  'LBL_MODULE_TITLE' => 'Program',
  'LBL_HOMEPAGE_TITLE' => 'Мои Program',
  'LNK_NEW_RECORD' => 'Създай Program',
  'LNK_LIST' => 'Разгледай Program',
  'LNK_IMPORT_BHEA_PROGRAM' => 'Import Program',
  'LBL_SEARCH_FORM_TITLE' => 'Търси Program',
  'LBL_HISTORY_SUBPANEL_TITLE' => 'История',
  'LBL_ACTIVITIES_SUBPANEL_TITLE' => 'Дейности',
  'LBL_BHEA_PROGRAM_SUBPANEL_TITLE' => 'Program',
  'LBL_NEW_FORM_TITLE' => 'Нов Program',
  'LBL_PROG_ID' => 'ID',
  'LBL_TYPE' => 'Type',
  'LBL_NO_OF_DAYS' => 'No of Days',
  'LBL_NO_CANDIDATES' => 'No of Candidates',
  'LBL_START_DATE' => 'Start Date',
  'LBL_END_DATE' => 'End Date',
  'LBL_MEM_PRICE' => 'Member Price',
  'LBL_NON_MEM_PRICE' => 'Non Member Price',
  'LBL_GROUP_DISCOUNT' => 'Group Discount',
  'LBL_DAY1_AGENDA' => 'Day 1 Agenda',
  'LBL_DAY2_AGENDA' => 'Day 2 Agenda',
  'LBL_DAY3_AGENDA' => 'Day 3 Agenda',
  'LBL_LOCATION' => 'Location',
);