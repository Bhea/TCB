<?php
/*
*@File:payMem.php.
*@Author:Meghana.A @ Bhea Technologies.
*@Purpose:This file will fetch the values from
* the payment and populate in
* the members module record
*/
class payMem
{
	function payMem($bean,$event,$arguments)
	{
		global $db;
		$query = "SELECT bhea_memberships_bhea_payments_1bhea_payments_idb as pid
				  FROM bhea_memberships_bhea_payments_1_c";
				
		$res = $db->query($query);
		while($row = $db->fetchByAssoc($res))
		{
			 if($bean->id == $row['pid'])
			 {
				$GLOBALS['log']->fatal("inside");
				$qry = "SELECT a.payment_status,a.payment_mode,a.name,a.description,a.payment_status,a.payment_date,a.id,b.bhea_memberships_bhea_payments_1bhea_payments_idb FROM bhea_payments a, bhea_memberships_bhea_payments_1_c b
				WHERE a.id = b.bhea_memberships_bhea_payments_1bhea_payments_idb
				ORDER BY a.date_entered DESC limit 1";
				$result = $db->query($qry);
				$row = $db->fetchByAssoc($result);

				$r = $_SERVER['REQUEST_URI']; 
				$r = explode('/', $r);
				$r = array_filter($r);
				$r = array_merge($r, array()); 
				$r = preg_replace('/\?.*/', '', $r);
				$id = $r[5];
				
				$mem = BeanFactory::getBean("Bhea_Memberships",$id);
				$mem->payment_id  = $row['name'];;
				$mem->payment_mode  = $row['payment_mode'];
				//$mem->payment_date  = $row['payment_date'];
				$mem->payment_status  = $row['payment_status'];

				if(empty($row['description']))
				{
					$mem->payment_details  = " ";
				}
				else
				{
					$mem->payment_details = $row['description'];
				}
				
				if(empty($row['payment_date']))
				{
					$mem->payment_date  = " ";
				}
				else
				{
					$mem->payment_date  = $row['payment_date'];
				}
				
				//$mem->save();
			 }
			 
		} 
		
	}
}
