<?php 
$app_list_strings['salutation_dom'] = array (
  '' => '',
  'Mr.' => '先生',
  'Ms.' => '小姐',
  'Mrs.' => '夫人',
  'Dr.' => '博士',
  'Prof.' => '教授',
  'Honourable' => 'Honourable',
);$app_list_strings['sessions_status'] = array (
  '' => '',
  'Planned' => 'Planned',
  'Held' => 'Held',
  'Cancelled' => 'Cancelled',
  'Preponed' => 'Preponed',
  'Postponed' => 'Postponed',
);