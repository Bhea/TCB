<?php 
$app_list_strings['salutation_dom'] = array (
  '' => '',
  'Mr.' => 'Sz. Pan',
  'Ms.' => 'Sz. Pani',
  'Mrs.' => 'Sz. Pani',
  'Dr.' => 'Dr',
  'Prof.' => 'Prof.',
  'Honourable' => 'Honourable',
);$app_list_strings['sessions_status'] = array (
  '' => '',
  'Planned' => 'Planned',
  'Held' => 'Held',
  'Cancelled' => 'Cancelled',
  'Preponed' => 'Preponed',
  'Postponed' => 'Postponed',
);