<?php
 // created: 2013-12-12 15:13:24
$dictionary['Bhea_Sponsor']['fields']['company_address_city_c']['group']='company_address_c';

 ?>