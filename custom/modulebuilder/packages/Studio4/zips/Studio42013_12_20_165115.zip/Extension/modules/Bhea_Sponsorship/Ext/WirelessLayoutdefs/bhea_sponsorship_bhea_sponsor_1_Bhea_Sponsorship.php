<?php
 // created: 2013-12-03 16:15:05
$layout_defs["Bhea_Sponsorship"]["subpanel_setup"]['bhea_sponsorship_bhea_sponsor_1'] = array (
  'order' => 100,
  'module' => 'Bhea_Sponsor',
  'subpanel_name' => 'default',
  'title_key' => 'LBL_BHEA_SPONSORSHIP_BHEA_SPONSOR_1_FROM_BHEA_SPONSOR_TITLE',
  'get_subpanel_data' => 'bhea_sponsorship_bhea_sponsor_1',
);
