<?php
 // created: 2013-12-12 15:13:25
$dictionary['Bhea_Sponsor']['fields']['company_address_country_c']['group']='company_address_c';

 ?>