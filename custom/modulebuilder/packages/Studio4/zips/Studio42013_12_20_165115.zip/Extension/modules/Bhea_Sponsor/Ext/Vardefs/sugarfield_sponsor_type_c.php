<?php
 // created: 2013-12-18 18:13:12
$dictionary['Bhea_Sponsor']['fields']['sponsor_type_c']['labelValue']='Sponsor Type';
$dictionary['Bhea_Sponsor']['fields']['sponsor_type_c']['dependency']='';
$dictionary['Bhea_Sponsor']['fields']['sponsor_type_c']['visibility_grid']='';

 ?>