<?php
 // created: 2013-12-04 12:42:53
$layout_defs["Bhea_Sponsor"]["subpanel_setup"]['bhea_sponsor_bhea_sponsorship_1'] = array (
  'order' => 100,
  'module' => 'Bhea_Sponsorship',
  'subpanel_name' => 'default',
  'title_key' => 'LBL_BHEA_SPONSOR_BHEA_SPONSORSHIP_1_FROM_BHEA_SPONSORSHIP_TITLE',
  'get_subpanel_data' => 'bhea_sponsor_bhea_sponsorship_1',
);
