<?php
/*
*@File:financial.php.
*@Author:Meghana.A @ Bhea Technologies.
*@Purpose:This file will fetch the values from
* the financial performance and populate in
* the company module record
*/
class financial
{
	function financialRevenue($bean,$event,$arguments)
	{
		
		global $db;
		$qry = "SELECT a.revenue,a.date_entered,a.id,b.accounts_bhea_finance_performance_1bhea_finance_performance_idb FROM bhea_finance_performance a, accounts_bhea_finance_performance_1_c b
		WHERE a.id = b.accounts_bhea_finance_performance_1bhea_finance_performance_idb
		ORDER BY a.date_entered DESC limit 1";
		$result = $db->query($qry);
		$row = $db->fetchByAssoc($result);
		$revenue = $row['revenue'];
		
		
		$r = $_SERVER['REQUEST_URI']; 
		$r = explode('/', $r);
		$r = array_filter($r);
		$r = array_merge($r, array()); 
		$r = preg_replace('/\?.*/', '', $r);
		$id = $r[5];
		
		$acc = BeanFactory::getBean("Accounts",$id);
		$acc->annual_revenue = $revenue;
		$acc->forbes_rating_c = $bean->forbes_rating_c;
		$acc->global_rating_c = $bean->	fortune_global_rating_c;
		$acc->employees = $bean->no_of_emp;
		//$acc->save();
	}
}
