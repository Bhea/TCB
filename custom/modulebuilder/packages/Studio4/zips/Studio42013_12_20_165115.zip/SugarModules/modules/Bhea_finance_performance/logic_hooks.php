<?php

$hook_version = 1;
$hook_array = Array();

$hook_array['after_save'] = Array();
$hook_array['after_save'][] = Array(1,'Latest revenue population in financial performance','custom/modules/Bhea_finance_performance/financial.php','financial','financialRevenue');
//$hook_array['process_record'][] = Array(1,'Record creation in Membership Module','custom/modules/Accounts/save.php','save','save');
//$hook_array['after_save'][] = Array(1,'Record creation in Sponsors Module','custom/modules/Opportunities/sponsors.php','sponsors_record','sponsors_record_method');
//$hook_array['after_save'][] = Array(1,'Record creation in Membership Module','custom/modules/Opportunities/logic_hooks_classes.php','logic_hooks_classes','after_save_method');
//$hook_array['after_save'][] = Array(1,'Change contact type or related Contact record','custom/modules/Opportunities/after_save_logic_hook.php','AfterSaveOpportunities','salesStageChange');

?>
