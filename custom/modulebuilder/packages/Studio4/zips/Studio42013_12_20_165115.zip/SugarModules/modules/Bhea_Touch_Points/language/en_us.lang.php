<?php 
 // created: 2013-12-20 16:51:13
$mod_strings['LNK_NEW_RECORD'] = 'Create Engagement Metrics';
$mod_strings['LNK_LIST'] = 'View Engagement Metrics';
$mod_strings['LBL_MODULE_NAME'] = 'Engagement Metrics';
$mod_strings['LBL_MODULE_NAME_SINGULAR'] = 'Engagement Metrics';
$mod_strings['LBL_NEW_FORM_TITLE'] = 'New Engagement Metrics';
$mod_strings['LNK_IMPORT_VCARD'] = 'Import Engagement Metrics vCard';
$mod_strings['LNK_IMPORT_BHEA_TOUCH_POINTS'] = 'Import Engagement Metrics';
$mod_strings['LBL_LIST_FORM_TITLE'] = 'Engagement Metrics List';
$mod_strings['LBL_SEARCH_FORM_TITLE'] = 'Search Engagement Metrics';
$mod_strings['LBL_HOMEPAGE_TITLE'] = 'My Engagement Metricss';
$mod_strings['LBL_AVG_REG'] = 'Average Registrations';
$mod_strings['LBL_REGISTERED_EMP'] = 'No of Employees Registered';

?>
