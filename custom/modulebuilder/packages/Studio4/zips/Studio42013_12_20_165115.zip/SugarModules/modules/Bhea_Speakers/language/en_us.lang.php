<?php 
 // created: 2013-12-20 16:51:13
$mod_strings['LBL_CONTACT'] = 'Contacts';
$mod_strings['LBL_ACCOUNT '] = 'Account not';
$mod_strings['LBL_FAMILIAR_NAME'] = 'Familiar Name';

?>
