<?php 
 // created: 2013-12-20 16:51:13
$mod_strings['LBL_YEAR'] = 'Year';
$mod_strings['LBL_BHEA_FINANCE_PERFORMANCE_ACCOUNTS_1_FROM_ACCOUNTS_TITLE'] = 'Accountss';
$mod_strings['LBL_LEADS_BHEA_FINANCE_PERFORMANCE_1_FROM_LEADS_TITLE'] = 'Lead';
$mod_strings['LBL_ACCOUNTS_BHEA_FINANCE_PERFORMANCE_1_FROM_ACCOUNTS_TITLE'] = 'Company';
$mod_strings['LBL_ASSETS'] = 'Assets';
$mod_strings['LBL_FORTUNE_GLOBAL_RATING'] = 'Fortune Global Rating';
$mod_strings['LBL_FORBES_RATING'] = 'Forbes Rating';

?>
