<?php
// created: 2013-12-03 15:33:08
$viewdefs['Bhea_Events']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_LEADS_BHEA_EVENTS_1_FROM_LEADS_TITLE',
  'context' => 
  array (
    'link' => 'leads_bhea_events_1',
  ),
);