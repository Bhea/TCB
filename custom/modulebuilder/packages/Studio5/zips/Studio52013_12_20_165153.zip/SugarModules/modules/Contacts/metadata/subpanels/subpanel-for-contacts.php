<?php
// created: 2013-12-12 18:43:56
$subpanel_layout['list_fields'] = array (
  'full_name' => 
  array (
    'type' => 'fullname',
    'link' => true,
    'studio' => 
    array (
      'listview' => false,
    ),
    'vname' => 'LBL_NAME',
    'width' => '10%',
    'default' => true,
  ),
  'type_c' => 
  array (
    'type' => 'enum',
    'default' => true,
    'studio' => 'visible',
    'vname' => 'LBL_TYPE',
    'width' => '10%',
  ),
  'status_c' => 
  array (
    'type' => 'enum',
    'default' => true,
    'studio' => 'visible',
    'vname' => 'LBL_STATUS',
    'width' => '10%',
  ),
  'contacts_id_c' => 
  array (
    'type' => 'varchar',
    'default' => true,
    'vname' => 'LBL_CONTACTS_ID',
    'width' => '10%',
  ),
  'username_c' => 
  array (
    'type' => 'varchar',
    'default' => true,
    'vname' => 'LBL_USERNAME',
    'width' => '10%',
  ),
  'opportunity_role' => 
  array (
    'name' => 'opportunity_role',
    'vname' => 'LBL_LIST_CONTACT_ROLE',
    'width' => '10%',
    'sortable' => false,
    'default' => true,
  ),
  'phone_work' => 
  array (
    'name' => 'phone_work',
    'vname' => 'LBL_LIST_PHONE',
    'width' => '10%',
    'default' => true,
  ),
  'first_name' => 
  array (
    'name' => 'first_name',
    'usage' => 'query_only',
  ),
  'last_name' => 
  array (
    'name' => 'last_name',
    'usage' => 'query_only',
  ),
  'salutation' => 
  array (
    'name' => 'salutation',
    'usage' => 'query_only',
  ),
  'account_id' => 
  array (
    'usage' => 'query_only',
  ),
  'opportunity_role_fields' => 
  array (
    'usage' => 'query_only',
  ),
  'opportunity_role_id' => 
  array (
    'usage' => 'query_only',
  ),
);