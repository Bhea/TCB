<?php
 // created: 2013-12-19 18:04:47
$dictionary['bhea_Sponsorship_Types']['fields']['sponsor_type_c']['labelValue']='Sponsor type';
$dictionary['bhea_Sponsorship_Types']['fields']['sponsor_type_c']['dependency']='';
$dictionary['bhea_Sponsorship_Types']['fields']['sponsor_type_c']['visibility_grid']=array (
  'trigger' => 'sponsorship_region_c',
  'values' => 
  array (
    'USA' => 
    array (
      0 => 'Lead_Sponsor',
      1 => 'Supporting_Sponsor',
      2 => 'Reception_Sponsor',
      3 => 'Custom_Sponsor',
      4 => 'Break_Sponsor',
      5 => 'Breakfast_Sponsor',
      6 => 'Associated_Sponsor',
      7 => 'Workshop_Sponsor',
      8 => 'Luncheon_Sponsor',
      9 => 'Exhibitor_Sponsor',
    ),
    'Europe' => 
    array (
      0 => 'Participating_Sponsor',
      1 => 'Comprehensive_Sponsor',
      2 => 'Associated_Sponsor',
    ),
  ),
);

 ?>