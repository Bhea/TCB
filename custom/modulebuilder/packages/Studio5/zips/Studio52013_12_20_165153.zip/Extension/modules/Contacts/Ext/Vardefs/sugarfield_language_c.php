<?php
 // created: 2013-12-03 09:57:57
$dictionary['Contact']['fields']['language_c']['labelValue']='Language';
$dictionary['Contact']['fields']['language_c']['dependency']='';
$dictionary['Contact']['fields']['language_c']['visibility_grid']='';

 ?>