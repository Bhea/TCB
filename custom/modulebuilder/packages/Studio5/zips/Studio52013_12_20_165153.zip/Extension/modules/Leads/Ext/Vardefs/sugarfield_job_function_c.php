<?php
 // created: 2013-12-06 17:46:09
$dictionary['Lead']['fields']['job_function_c']['labelValue']='Job Function';
$dictionary['Lead']['fields']['job_function_c']['dependency']='';
$dictionary['Lead']['fields']['job_function_c']['visibility_grid']='';

 ?>