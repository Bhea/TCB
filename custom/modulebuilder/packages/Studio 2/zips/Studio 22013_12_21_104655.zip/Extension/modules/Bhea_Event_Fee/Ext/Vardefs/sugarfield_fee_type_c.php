<?php
 // created: 2013-12-16 16:51:43
$dictionary['Bhea_Event_Fee']['fields']['fee_type_c']['labelValue']='Fee Type';
$dictionary['Bhea_Event_Fee']['fields']['fee_type_c']['dependency']='';
$dictionary['Bhea_Event_Fee']['fields']['fee_type_c']['visibility_grid']=array (
  'trigger' => 'type_c',
  'values' => 
  array (
    'Members' => 
    array (
      0 => 'Academic_Fee',
      1 => 'Educational_Fee',
      2 => 'Enterprise_Fee',
      3 => 'Government_Fee',
      4 => 'Mid_Market_Fee',
      5 => 'Non_Profit_Fee',
    ),
    'Non_Members' => 
    array (
      0 => 'Government_Fee',
      1 => 'Non_Profit_Fee',
      2 => 'Academic_Fee',
      3 => 'Educational_Fee',
    ),
  ),
);

 ?>