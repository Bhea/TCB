<?php 
 // created: 2013-12-21 10:46:53
$mod_strings['LBL_BHEA_HOTELS_BHEA_EVENTS_1_FROM_BHEA_EVENTS_TITLE'] = 'Events';

?>
