<?php 
$app_list_strings['fee_type_list'] = array (
  'Enterprise_Fee' => 'Enterprise Fee',
  'Educational_Fee' => 'Educational Fee',
  'Mid_Market_Fee' => 'Mid Market Fee',
  'Government_Fee' => 'Government Fee',
  'Academic_Fee' => 'Academic Fee',
  'Non_Profit_Fee' => 'Non Profit Fee',
);$app_list_strings['event_fee_type_2'] = array (
  'Members' => 'Members',
  'Non_Members' => 'Non Members',
);$app_list_strings['event_status_3'] = array (
  'Tentative' => 'Tentative',
  'Date_Confirmed' => 'Date Confirmed',
  'Ready_for_Registration' => 'Ready for Registration',
  'Early_Bird_Time' => 'Early Bird Time',
  'Registration_Closure' => 'Registration Closure',
  'In_Session' => 'In Session',
  'Completed' => 'Completed',
  'Cancelled' => 'Cancelled',
  'Postponed' => 'Postponed',
);$app_list_strings['mem_type_0'] = array (
  'new' => 'New',
  '' => '',
  'Upgrade' => 'Upgrade',
  'Renewal' => 'Renewal',
);