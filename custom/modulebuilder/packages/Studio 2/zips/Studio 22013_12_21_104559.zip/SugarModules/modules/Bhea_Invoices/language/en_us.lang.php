<?php 
 // created: 2013-12-21 10:45:57
$mod_strings['LBL_BHEA_INVOICES_BHEA_PAYMENTS_1_FROM_BHEA_PAYMENTS_TITLE'] = 'Payments';

?>
