<?php

$hook_version = 1;
$hook_array = Array();

$hook_array['after_save'] = Array();
//$hook_array['after_save'][] = Array(1,'Autogeneratiopn of Event id in Bhea_Events Module based on the event type selected','custom/modules/Bhea_Events/eventid_generation.php','eventid','eventid_method');
?>
