<?php 
 // created: 2013-12-21 10:45:58
$mod_strings['LBL_ACCOUNTS_BHEA_MEMBERSHIPS_1_FROM_ACCOUNTS_TITLE'] = 'Company';
$mod_strings['LBL_FINAL_MEM_FEE'] = 'Final Membership Fee';
$mod_strings['LBL_DISCOUNT'] = 'Discount';
$mod_strings['LBL_MEM_TYPE'] = 'Membership Type';
$mod_strings['LBL_LOST_REASON'] = 'Lost Reason';
$mod_strings['LBL_STATUS'] = 'Status';
$mod_strings['LBL_DAYS'] = 'days';
$mod_strings['LBL_EXPIRY_DATE'] = 'Expiry Date';
$mod_strings['LBL_BHEA_MEMBERSHIPS_BHEA_PAYMENTS_1_FROM_BHEA_PAYMENTS_TITLE'] = 'Payments';

?>
