<?php 
 // created: 2013-12-21 10:45:57
$mod_strings['LBL_BHEA_HOTELS_BHEA_EVENTS_1_FROM_BHEA_EVENTS_TITLE'] = 'Events';

?>
