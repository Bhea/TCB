<?php
 // created: 2013-12-16 16:38:17
$dictionary['Bhea_Event_Fee']['fields']['fees_c']['labelValue']='Fees';
$dictionary['Bhea_Event_Fee']['fields']['fees_c']['enforced']='';
$dictionary['Bhea_Event_Fee']['fields']['fees_c']['dependency']='';

 ?>