<?php
 // created: 2013-12-16 16:40:16
$dictionary['Bhea_Event_Fee']['fields']['early_bird_discount_date_c']['labelValue']='Early Bird Discount Date';
$dictionary['Bhea_Event_Fee']['fields']['early_bird_discount_date_c']['enforced']='';

 ?>