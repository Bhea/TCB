<?php
 // created: 2013-12-16 15:28:30
$dictionary['Bhea_Event_Fee']['fields']['type_c']['labelValue']='Type';
$dictionary['Bhea_Event_Fee']['fields']['type_c']['dependency']='';
$dictionary['Bhea_Event_Fee']['fields']['type_c']['visibility_grid']='';

 ?>