<?php
 // created: 2013-12-17 15:25:00
$dictionary['Bhea_Councils']['fields']['knowledge_area']['default']='';
$dictionary['Bhea_Councils']['fields']['knowledge_area']['options']='practice_area_list';

 ?>