<?php
 // created: 2013-12-16 11:58:54
$dictionary['Bhea_Events']['fields']['event_id_c']['labelValue']='Event ID';
$dictionary['Bhea_Events']['fields']['event_id_c']['full_text_search']=array (
  'boost' => '0',
);
$dictionary['Bhea_Events']['fields']['event_id_c']['enforced']='';
$dictionary['Bhea_Events']['fields']['event_id_c']['dependency']='';

 ?>