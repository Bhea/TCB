<?php
 // created: 2013-12-04 16:21:51
$dictionary['Bhea_Councils']['fields']['end_date']['dependency']='';

 ?>