<?php
 // created: 2013-12-17 15:29:06
$dictionary['Bhea_Councils']['fields']['pricing_type_c']['labelValue']='Pricing Type';
$dictionary['Bhea_Councils']['fields']['pricing_type_c']['dependency']='';
$dictionary['Bhea_Councils']['fields']['pricing_type_c']['visibility_grid']='';

 ?>