<?php
 // created: 2013-12-17 15:28:24
$dictionary['Bhea_Councils']['fields']['access_level_c']['labelValue']='Access Level';
$dictionary['Bhea_Councils']['fields']['access_level_c']['dependency']='';
$dictionary['Bhea_Councils']['fields']['access_level_c']['visibility_grid']='';

 ?>