<?php
// created: 2013-12-16 15:30:32
$viewdefs['Bhea_Events']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_BHEA_EVENTS_BHEA_EVENT_FEE_1_FROM_BHEA_EVENT_FEE_TITLE',
  'context' => 
  array (
    'link' => 'bhea_events_bhea_event_fee_1',
  ),
);