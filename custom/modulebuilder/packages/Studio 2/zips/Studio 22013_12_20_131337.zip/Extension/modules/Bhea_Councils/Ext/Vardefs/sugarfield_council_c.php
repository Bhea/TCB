<?php
 // created: 2013-12-18 14:32:25
$dictionary['Bhea_Councils']['fields']['council_c']['labelValue']='Council #';
$dictionary['Bhea_Councils']['fields']['council_c']['enforced']='';
$dictionary['Bhea_Councils']['fields']['council_c']['dependency']='';

 ?>