<?php
 // created: 2013-12-03 10:46:28
$dictionary['Bhea_Councils']['fields']['council_directory']['default']='';
$dictionary['Bhea_Councils']['fields']['council_directory']['options']='council_directory_list';

 ?>