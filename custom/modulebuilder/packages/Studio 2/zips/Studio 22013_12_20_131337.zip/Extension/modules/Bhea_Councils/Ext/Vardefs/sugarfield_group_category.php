<?php
 // created: 2013-12-18 08:48:26
$dictionary['Bhea_Councils']['fields']['group_category']['default']='';
$dictionary['Bhea_Councils']['fields']['group_category']['options']='group_category_list';

 ?>