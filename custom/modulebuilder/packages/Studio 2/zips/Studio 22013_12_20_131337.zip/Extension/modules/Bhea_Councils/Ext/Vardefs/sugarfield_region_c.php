<?php
 // created: 2013-12-17 15:27:25
$dictionary['Bhea_Councils']['fields']['region_c']['labelValue']='Region';
$dictionary['Bhea_Councils']['fields']['region_c']['dependency']='';
$dictionary['Bhea_Councils']['fields']['region_c']['visibility_grid']='';

 ?>