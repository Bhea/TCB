<?php 
 // created: 2013-12-20 13:13:34
$mod_strings['LBL_BHEA_COUNCILS_BHEA_COUNCIL_MEMBERS_1_FROM_BHEA_COUNCIL_MEMBERS_TITLE'] = 'Council Members';
$mod_strings['LBL_BHEA_COUNCILS_BHEA_COUNCIL_MEMBERSHIPS_1_FROM_BHEA_COUNCIL_MEMBERSHIPS_TITLE'] = 'Council Memberships';
$mod_strings['LBL_BHEA_COUNCILS_OPPORTUNITIES_1_FROM_OPPORTUNITIES_TITLE'] = 'Opportunities';
$mod_strings['LBL_GROUP_CATEGORY '] = 'Group Category ';
$mod_strings['LBL_COUNCIL_DIRECTORY '] = 'Council Directory';
$mod_strings['LBL_OPPORTUNITIES_BHEA_COUNCILS_1_FROM_OPPORTUNITIES_TITLE'] = 'Opportunities';
$mod_strings['LBL_END_DATE '] = 'End Date';
$mod_strings['LNK_NEW_RECORD'] = 'Create Groups';
$mod_strings['LNK_LIST'] = 'View Groups';
$mod_strings['LBL_MODULE_NAME'] = 'Groups';
$mod_strings['LBL_MODULE_NAME_SINGULAR'] = 'Group';
$mod_strings['LBL_NEW_FORM_TITLE'] = 'New Group';
$mod_strings['LNK_IMPORT_VCARD'] = 'Import Group vCard';
$mod_strings['LNK_IMPORT_BHEA_COUNCILS'] = 'Import Groups';
$mod_strings['LBL_LIST_FORM_TITLE'] = 'Group List';
$mod_strings['LBL_SEARCH_FORM_TITLE'] = 'Search Group';
$mod_strings['LBL_HOMEPAGE_TITLE'] = 'My Groups';
$mod_strings['LBL_KNOWLEDGE_AREA '] = 'Practice Area';
$mod_strings['LBL_REGION'] = 'Region';
$mod_strings['LBL_ACCESS_LEVEL'] = 'Access Level';
$mod_strings['LBL_PRICING_TYPE'] = 'Pricing Type';
$mod_strings['LBL_COUNCIL'] = 'Council #';

?>
