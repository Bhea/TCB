<?php 
 // created: 2013-12-20 13:13:34
$mod_strings['LBL_BHEA_EVENTS_BHEA_SESSIONS_1_FROM_BHEA_SESSIONS_TITLE'] = 'Sessions';
$mod_strings['LBL_BHEA_EVENTS_BHEA_REGISTRANTS_1_FROM_BHEA_REGISTRANTS_TITLE'] = 'Participants';
$mod_strings['LBL_BHEA_EVENTS_LEADS_1_FROM_LEADS_TITLE'] = 'Leadss';
$mod_strings['LBL_BHEA_EVENTS_BHEA_CONTRACTORS_1_FROM_BHEA_CONTRACTORS_TITLE'] = 'Contractors';
$mod_strings['LBL_BHEA_EVENTS_BHEA_SPONSORSHIP_1_FROM_BHEA_SPONSORSHIP_TITLE'] = 'Sponsorship';
$mod_strings['LBL_BHEA_EVENTS_BHEA_SPONSOR_1_FROM_BHEA_SPONSOR_TITLE'] = 'Sponsor';
$mod_strings['LBL_BHEA_EVENTS_CAMPAIGNS_1_FROM_CAMPAIGNS_TITLE'] = 'Campaigns';
$mod_strings['LBL_BHEA_EVENTS_BHEA_SPEAKERS_1_FROM_BHEA_SPEAKERS_TITLE'] = 'Speakers';
$mod_strings['LBL_BHEA_EVENTS_OPPORTUNITIES_1_FROM_OPPORTUNITIES_TITLE'] = 'Opportunities';
$mod_strings['LBL_BHEA_EVENTS_BHEA_SPONSORSHIP_TYPES_1_FROM_BHEA_SPONSORSHIP_TYPES_TITLE'] = 'Sponsorship Types';
$mod_strings['LBL_BHEA_EVENTS_BHEA_EVENTS_1_FROM_BHEA_EVENTS_R_TITLE'] = 'Events';
$mod_strings['LBL_EVENT_COORDINATOR '] = 'Event Coordinator not';
$mod_strings['LBL_HOTEL '] = 'Hotel not';
$mod_strings['LBL_CONFERENCE_FEES_'] = 'Event Fees';
$mod_strings['LBL_BHEA_EVENTS_BHEA_EVENTS_1_FROM_BHEA_EVENTS_L_TITLE'] = 'Member Of';
$mod_strings['LBL_LEADS_BHEA_EVENTS_1_FROM_LEADS_TITLE'] = 'Lead';
$mod_strings['LBL_CONFERENCE_FEES '] = 'Non Member Event Fees';
$mod_strings['LBL_ATTENDEE_FEE_TARGET '] = 'Attendee Fee Target';
$mod_strings['LBL_STATUS'] = 'Event Status';
$mod_strings['LBL_BHEA_CONTRACTORS_BHEA_EVENTS_1_FROM_BHEA_CONTRACTORS_TITLE'] = 'Contractors';
$mod_strings['LBL_KNOWLEDGE_AREA'] = 'Practice Area';
$mod_strings['LBL_EVENT_ID'] = 'Event ID';
$mod_strings['LBL_BHEA_EVENTS_BHEA_EVENT_FEE_1_FROM_BHEA_EVENT_FEE_TITLE'] = 'Event Fees';

?>
