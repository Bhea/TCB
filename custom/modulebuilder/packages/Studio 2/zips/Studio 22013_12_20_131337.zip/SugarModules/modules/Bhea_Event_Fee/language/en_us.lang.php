<?php 
 // created: 2013-12-20 13:13:34
$mod_strings['LBL_TYPE'] = 'Type';
$mod_strings['LBL_ENTERPRISE_FEE'] = 'Enterprise Fee';
$mod_strings['LBL_EDUCATIONAL_FEE'] = 'Educational Fee';
$mod_strings['LBL_MID_MARKET_FEE'] = 'Mid Market Fee';
$mod_strings['LNK_NEW_RECORD'] = 'Create Event Fees';
$mod_strings['LNK_LIST'] = 'View Event Fees';
$mod_strings['LBL_MODULE_NAME'] = 'Event Fees';
$mod_strings['LBL_MODULE_NAME_SINGULAR'] = 'Event Fee';
$mod_strings['LBL_NEW_FORM_TITLE'] = 'New Event Fee';
$mod_strings['LNK_IMPORT_VCARD'] = 'Import Event Fee vCard';
$mod_strings['LNK_IMPORT_BHEA_EVENT_FEE'] = 'Import Event Fees';
$mod_strings['LBL_LIST_FORM_TITLE'] = 'Event Fee List';
$mod_strings['LBL_SEARCH_FORM_TITLE'] = 'Search Event Fee';
$mod_strings['LBL_HOMEPAGE_TITLE'] = 'My Event Fees';
$mod_strings['LBL_GOVERNMENT_FEE'] = 'Government Fee';
$mod_strings['LBL_ACADEMIC_FEE'] = 'Academic Fee';
$mod_strings['LBL_NON_PROFIT_FEE'] = 'Non Profit Fee';
$mod_strings['LBL_EARLY_BIRD_DISCOUNT'] = 'Early Bird Discount';
$mod_strings['LBL_EARLY_BIRD_DISCOUNT_DATE'] = 'Early Bird Discount Date';
$mod_strings['LBL_FEE_TYPE'] = 'Fee Type';
$mod_strings['LBL_FEES'] = 'Fees';
$mod_strings['LBL_DISCOUNT'] = 'Discount in %';
$mod_strings['LBL_FEE_TO_BE_CHARGED'] = 'Fee To Be Charged';

?>
