<?php
// created: 2013-12-04 09:46:31
$dictionary["Bhea_Sessions"]["fields"]["contacts_bhea_sessions_1"] = array (
  'name' => 'contacts_bhea_sessions_1',
  'type' => 'link',
  'relationship' => 'contacts_bhea_sessions_1',
  'source' => 'non-db',
  'module' => 'Contacts',
  'bean_name' => 'Contact',
  'vname' => 'LBL_CONTACTS_BHEA_SESSIONS_1_FROM_CONTACTS_TITLE',
  'id_name' => 'contacts_bhea_sessions_1contacts_ida',
);
