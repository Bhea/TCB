<?php
 // created: 2013-12-03 09:11:15
$dictionary['Account']['fields']['other_phone_c']['labelValue']='Other Phone';
$dictionary['Account']['fields']['other_phone_c']['full_text_search']=array (
  'boost' => '0',
);
$dictionary['Account']['fields']['other_phone_c']['enforced']='';
$dictionary['Account']['fields']['other_phone_c']['dependency']='';

 ?>