<?php
 // created: 2013-12-03 09:16:00
$dictionary['Account']['fields']['last_fiscal_c']['labelValue']='Last Revenue Fiscal Year';
$dictionary['Account']['fields']['last_fiscal_c']['enforced']='';
$dictionary['Account']['fields']['last_fiscal_c']['dependency']='';

 ?>