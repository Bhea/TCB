<?php
// created: 2013-12-04 09:27:55
$dictionary["Account"]["fields"]["accounts_bhea_account_plan_1"] = array (
  'name' => 'accounts_bhea_account_plan_1',
  'type' => 'link',
  'relationship' => 'accounts_bhea_account_plan_1',
  'source' => 'non-db',
  'module' => 'Bhea_Account_Plan',
  'bean_name' => 'Bhea_Account_Plan',
  'vname' => 'LBL_ACCOUNTS_BHEA_ACCOUNT_PLAN_1_FROM_ACCOUNTS_TITLE',
  'id_name' => 'accounts_bhea_account_plan_1accounts_ida',
  'link-type' => 'many',
  'side' => 'left',
);
