<?php
 // created: 2013-12-04 16:13:36
$dictionary['Bhea_Council_Memberships']['fields']['amount_paid_c']['labelValue']='Amount Paid';
$dictionary['Bhea_Council_Memberships']['fields']['amount_paid_c']['enforced']='';
$dictionary['Bhea_Council_Memberships']['fields']['amount_paid_c']['dependency']='';

 ?>