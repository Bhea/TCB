<?php
 // created: 2013-12-04 09:42:14
$layout_defs["Accounts"]["subpanel_setup"]['accounts_bhea_council_members_1'] = array (
  'order' => 100,
  'module' => 'Bhea_Council_Members',
  'subpanel_name' => 'default',
  'title_key' => 'LBL_ACCOUNTS_BHEA_COUNCIL_MEMBERS_1_FROM_BHEA_COUNCIL_MEMBERS_TITLE',
  'get_subpanel_data' => 'accounts_bhea_council_members_1',
);
