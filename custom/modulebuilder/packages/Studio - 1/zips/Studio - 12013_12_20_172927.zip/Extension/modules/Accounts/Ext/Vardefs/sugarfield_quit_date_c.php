<?php
 // created: 2013-12-03 20:04:10
$dictionary['Account']['fields']['quit_date_c']['labelValue']='Quit Date';
$dictionary['Account']['fields']['quit_date_c']['enforced']='';
$dictionary['Account']['fields']['quit_date_c']['dependency']='not(equal($request_quit_c,""))';

 ?>