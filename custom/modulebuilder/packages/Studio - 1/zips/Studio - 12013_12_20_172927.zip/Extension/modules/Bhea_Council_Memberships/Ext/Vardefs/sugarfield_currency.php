<?php
 // created: 2013-12-03 10:49:21
$dictionary['Bhea_Council_Memberships']['fields']['currency']['default']='';
$dictionary['Bhea_Council_Memberships']['fields']['currency']['options']='currency_0';

 ?>