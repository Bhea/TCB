<?php
 // created: 2013-12-03 09:17:19
$dictionary['Account']['fields']['duns_c']['labelValue']='DUNS';
$dictionary['Account']['fields']['duns_c']['full_text_search']=array (
  'boost' => '0',
);
$dictionary['Account']['fields']['duns_c']['enforced']='';
$dictionary['Account']['fields']['duns_c']['dependency']='';

 ?>