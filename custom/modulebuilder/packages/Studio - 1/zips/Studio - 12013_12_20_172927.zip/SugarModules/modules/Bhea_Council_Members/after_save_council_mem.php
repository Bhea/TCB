<?php

class AfterSaveCouncilMem{
	function councilPastMember($bean,$event,$arguments){
		if($bean->membership_status=="InActive")
		{
			$groupBean = BeanFactory::getBean('Bhea_Councils',$bean->bhea_councils_bhea_council_members_1bhea_councils_ida);
			
			$groupBean->load_relationship('bhea_councils_bhea_council_members_2');
			$groupBean->bhea_councils_bhea_council_members_2->add($bean->id);
			
			$groupBean->load_relationship('bhea_councils_bhea_council_members_1');
			$groupBean->bhea_councils_bhea_council_members_1->delete($groupBean->id,$bean->id);
		}
	}
}
?>
