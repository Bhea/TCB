<?php 
 // created: 2013-12-20 17:29:24
$mod_strings['LBL_ASSIGNED_TO_NAME'] = 'Key Executive';
$mod_strings['LNK_NEW_RECORD'] = 'Create Engagement Strategies';
$mod_strings['LNK_LIST'] = 'View Engagement Strategies';
$mod_strings['LBL_MODULE_NAME'] = 'Engagement Strategies';
$mod_strings['LBL_MODULE_NAME_SINGULAR'] = 'Engagement Strategies';
$mod_strings['LBL_NEW_FORM_TITLE'] = 'New Engagement Strategies';
$mod_strings['LNK_IMPORT_VCARD'] = 'Import Engagement Strategies vCard';
$mod_strings['LNK_IMPORT_BHEA_ACCOUNT_PLAN'] = 'Import Engagement Strategies';
$mod_strings['LBL_LIST_FORM_TITLE'] = 'Engagement Strategies List';
$mod_strings['LBL_SEARCH_FORM_TITLE'] = 'Search Engagement Strategies';
$mod_strings['LBL_HOMEPAGE_TITLE'] = 'My Engagement Strategies';
$mod_strings['LBL_ACCOUNTS_BHEA_ACCOUNT_PLAN_1_FROM_ACCOUNTS_TITLE'] = 'Company';

?>
