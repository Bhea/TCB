<?php
 // created: 2013-12-04 14:57:36
$dictionary['Account']['fields']['mem_status_c']['labelValue']='Membership Status';
$dictionary['Account']['fields']['mem_status_c']['dependency']='or(equal($account_type,"member"),equal($account_type,"past_member"))';
$dictionary['Account']['fields']['mem_status_c']['visibility_grid']='';

 ?>