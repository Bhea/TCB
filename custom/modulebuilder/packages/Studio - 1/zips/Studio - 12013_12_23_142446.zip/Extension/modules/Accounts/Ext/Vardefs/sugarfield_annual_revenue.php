<?php
 // created: 2013-12-20 11:12:54
$dictionary['Account']['fields']['annual_revenue']['comments']='Annual revenue for this company';
$dictionary['Account']['fields']['annual_revenue']['merge_filter']='disabled';
$dictionary['Account']['fields']['annual_revenue']['full_text_search']=array (
  'boost' => '0',
);
$dictionary['Account']['fields']['annual_revenue']['calculated']=false;

 ?>