<?php
 // created: 2013-12-18 18:59:31
$dictionary['Account']['fields']['le_email_c']['labelValue']='LE Email';
$dictionary['Account']['fields']['le_email_c']['full_text_search']=array (
  'boost' => '0',
);
$dictionary['Account']['fields']['le_email_c']['enforced']='';
$dictionary['Account']['fields']['le_email_c']['dependency']='';

 ?>