<?php
 // created: 2013-12-18 18:44:04
$dictionary['Account']['fields']['le_phone_c']['labelValue']='LE Phone';
$dictionary['Account']['fields']['le_phone_c']['full_text_search']=array (
  'boost' => '0',
);
$dictionary['Account']['fields']['le_phone_c']['enforced']='';
$dictionary['Account']['fields']['le_phone_c']['dependency']='';

 ?>