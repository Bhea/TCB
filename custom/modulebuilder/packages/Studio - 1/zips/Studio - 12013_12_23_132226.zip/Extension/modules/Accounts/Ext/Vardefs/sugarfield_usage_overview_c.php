<?php
 // created: 2013-12-04 15:11:19
$dictionary['Account']['fields']['usage_overview_c']['labelValue']='Benefits Usage Overview';
$dictionary['Account']['fields']['usage_overview_c']['full_text_search']=array (
  'boost' => '0',
);
$dictionary['Account']['fields']['usage_overview_c']['enforced']='';

 ?>