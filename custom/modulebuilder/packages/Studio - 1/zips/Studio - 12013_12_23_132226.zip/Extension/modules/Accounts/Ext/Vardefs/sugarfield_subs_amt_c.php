<?php
 // created: 2013-12-04 14:59:43
$dictionary['Account']['fields']['subs_amt_c']['labelValue']='Current Subscription Amount';
$dictionary['Account']['fields']['subs_amt_c']['enforced']='';
$dictionary['Account']['fields']['subs_amt_c']['dependency']='or(equal($account_type,"member"),equal($account_type,"past_member"))';

 ?>