<?php
 // created: 2013-12-21 10:42:59
$dictionary['Account']['fields']['classification_c']['labelValue']='Classification';
$dictionary['Account']['fields']['classification_c']['dependency']='';
$dictionary['Account']['fields']['classification_c']['visibility_grid']='';

 ?>