<?php
 // created: 2013-12-03 09:12:58
$layout_defs["Bhea_Councils"]["subpanel_setup"]['bhea_councils_bhea_council_members_1'] = array (
  'order' => 100,
  'module' => 'Bhea_Council_Members',
  'subpanel_name' => 'default',
  'title_key' => 'LBL_BHEA_COUNCILS_BHEA_COUNCIL_MEMBERS_1_FROM_BHEA_COUNCIL_MEMBERS_TITLE',
  'get_subpanel_data' => 'bhea_councils_bhea_council_members_1',
);
