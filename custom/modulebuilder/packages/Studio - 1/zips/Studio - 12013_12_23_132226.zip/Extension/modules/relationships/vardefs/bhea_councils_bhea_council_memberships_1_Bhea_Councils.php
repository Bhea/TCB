<?php
// created: 2013-12-03 09:19:32
$dictionary["Bhea_Councils"]["fields"]["bhea_councils_bhea_council_memberships_1"] = array (
  'name' => 'bhea_councils_bhea_council_memberships_1',
  'type' => 'link',
  'relationship' => 'bhea_councils_bhea_council_memberships_1',
  'source' => 'non-db',
  'module' => 'Bhea_Council_Memberships',
  'bean_name' => 'Bhea_Council_Memberships',
  'vname' => 'LBL_BHEA_COUNCILS_BHEA_COUNCIL_MEMBERSHIPS_1_FROM_BHEA_COUNCILS_TITLE',
  'id_name' => 'bhea_councils_bhea_council_memberships_1bhea_councils_ida',
  'link-type' => 'many',
  'side' => 'left',
);
