<?php
 // created: 2013-12-04 14:55:48
$dictionary['Account']['fields']['mem_start_date_c']['labelValue']='Membership Start Date';
$dictionary['Account']['fields']['mem_start_date_c']['enforced']='';
$dictionary['Account']['fields']['mem_start_date_c']['dependency']='or(equal($account_type,"member"),equal($account_type,"past_member"))';

 ?>