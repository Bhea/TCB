<?php
 // created: 2013-12-13 10:27:51
$dictionary['Account']['fields']['company_id_c']['labelValue']='Company ID';
$dictionary['Account']['fields']['company_id_c']['full_text_search']=array (
  'boost' => '0',
);
$dictionary['Account']['fields']['company_id_c']['enforced']='';
$dictionary['Account']['fields']['company_id_c']['dependency']='';

 ?>