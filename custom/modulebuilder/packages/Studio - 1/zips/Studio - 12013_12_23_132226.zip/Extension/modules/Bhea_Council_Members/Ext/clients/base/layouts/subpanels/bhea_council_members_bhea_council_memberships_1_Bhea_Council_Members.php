<?php
// created: 2013-12-09 18:32:17
$viewdefs['Bhea_Council_Members']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_BHEA_COUNCIL_MEMBERS_BHEA_COUNCIL_MEMBERSHIPS_1_FROM_BHEA_COUNCIL_MEMBERSHIPS_TITLE',
  'context' => 
  array (
    'link' => 'bhea_council_members_bhea_council_memberships_1',
  ),
);