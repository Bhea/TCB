<?php
 // created: 2013-12-03 09:19:03
$dictionary['Account']['fields']['vat_number_c']['labelValue']='VAT Number';
$dictionary['Account']['fields']['vat_number_c']['full_text_search']=array (
  'boost' => '0',
);
$dictionary['Account']['fields']['vat_number_c']['enforced']='';
$dictionary['Account']['fields']['vat_number_c']['dependency']='';

 ?>