<?php
 // created: 2013-12-16 11:59:08
$dictionary['Opportunity']['fields']['pricing_type_c']['labelValue']='Pricing Type';
$dictionary['Opportunity']['fields']['pricing_type_c']['dependency']='';
$dictionary['Opportunity']['fields']['pricing_type_c']['visibility_grid']='';

 ?>