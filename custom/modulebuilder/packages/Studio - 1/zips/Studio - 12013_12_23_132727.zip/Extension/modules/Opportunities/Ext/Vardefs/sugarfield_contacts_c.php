<?php
 // created: 2013-12-11 14:58:21
$dictionary['Opportunity']['fields']['contacts_c']['labelValue']='Contacts not used';
$dictionary['Opportunity']['fields']['contacts_c']['dependency']='';

 ?>