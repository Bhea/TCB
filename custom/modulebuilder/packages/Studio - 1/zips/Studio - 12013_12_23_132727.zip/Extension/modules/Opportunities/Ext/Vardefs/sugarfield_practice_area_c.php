<?php
 // created: 2013-12-19 10:58:14
$dictionary['Opportunity']['fields']['practice_area_c']['labelValue']='Practice Area';
$dictionary['Opportunity']['fields']['practice_area_c']['dependency']='';
$dictionary['Opportunity']['fields']['practice_area_c']['visibility_grid']=array (
  'trigger' => 'membership_sub_category_c',
  'values' => 
  array (
    'Enterprise' => 
    array (
    ),
    'Topic' => 
    array (
      0 => '',
      1 => 'human_capital',
      2 => 'corporate_leadership',
      3 => 'economy_value',
    ),
    'All' => 
    array (
    ),
  ),
);

 ?>