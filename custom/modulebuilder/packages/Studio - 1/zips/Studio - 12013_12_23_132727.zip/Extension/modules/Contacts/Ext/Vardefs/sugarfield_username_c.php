<?php
 // created: 2013-12-03 10:04:19
$dictionary['Contact']['fields']['username_c']['labelValue']='Username';
$dictionary['Contact']['fields']['username_c']['full_text_search']=array (
  'boost' => '0',
);
$dictionary['Contact']['fields']['username_c']['enforced']='';
$dictionary['Contact']['fields']['username_c']['dependency']='';

 ?>