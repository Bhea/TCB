<?php
 // created: 2013-12-20 11:20:37
$dictionary['Opportunity']['fields']['best_case']['importable']='false';
$dictionary['Opportunity']['fields']['best_case']['merge_filter']='disabled';
$dictionary['Opportunity']['fields']['best_case']['calculated']='true';
$dictionary['Opportunity']['fields']['best_case']['formula']='$membership_fee_c';
$dictionary['Opportunity']['fields']['best_case']['enforced']=true;
$dictionary['Opportunity']['fields']['best_case']['enable_range_search']=false;

 ?>