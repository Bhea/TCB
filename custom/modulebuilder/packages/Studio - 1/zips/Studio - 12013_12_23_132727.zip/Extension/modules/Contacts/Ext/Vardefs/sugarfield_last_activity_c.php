<?php
 // created: 2013-12-03 10:01:10
$dictionary['Contact']['fields']['last_activity_c']['labelValue']='Last Activity Date';
$dictionary['Contact']['fields']['last_activity_c']['enforced']='';
$dictionary['Contact']['fields']['last_activity_c']['dependency']='';

 ?>