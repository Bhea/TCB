<?php
 // created: 2013-12-03 12:23:54
$layout_defs["Contacts"]["subpanel_setup"]['contacts_bhea_council_memberships_1'] = array (
  'order' => 100,
  'module' => 'Bhea_Council_Memberships',
  'subpanel_name' => 'default',
  'title_key' => 'LBL_CONTACTS_BHEA_COUNCIL_MEMBERSHIPS_1_FROM_BHEA_COUNCIL_MEMBERSHIPS_TITLE',
  'get_subpanel_data' => 'contacts_bhea_council_memberships_1',
);
