<?php
 // created: 2013-12-20 10:02:38
$dictionary['Account']['fields']['territory_id_c']['labelValue']='Territory ID';
$dictionary['Account']['fields']['territory_id_c']['full_text_search']=array (
  'boost' => '0',
);
$dictionary['Account']['fields']['territory_id_c']['enforced']='';
$dictionary['Account']['fields']['territory_id_c']['dependency']='';

 ?>