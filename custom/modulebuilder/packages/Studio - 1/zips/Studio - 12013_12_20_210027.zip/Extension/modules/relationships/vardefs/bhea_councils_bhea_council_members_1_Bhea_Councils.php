<?php
// created: 2013-12-03 09:12:58
$dictionary["Bhea_Councils"]["fields"]["bhea_councils_bhea_council_members_1"] = array (
  'name' => 'bhea_councils_bhea_council_members_1',
  'type' => 'link',
  'relationship' => 'bhea_councils_bhea_council_members_1',
  'source' => 'non-db',
  'module' => 'Bhea_Council_Members',
  'bean_name' => 'Bhea_Council_Members',
  'vname' => 'LBL_BHEA_COUNCILS_BHEA_COUNCIL_MEMBERS_1_FROM_BHEA_COUNCILS_TITLE',
  'id_name' => 'bhea_councils_bhea_council_members_1bhea_councils_ida',
  'link-type' => 'many',
  'side' => 'left',
);
