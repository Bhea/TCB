<?php
 // created: 2013-12-03 09:15:00
$dictionary['Account']['fields']['fiscal_end_c']['labelValue']='Fiscal Year End';
$dictionary['Account']['fields']['fiscal_end_c']['full_text_search']=array (
  'boost' => '0',
);
$dictionary['Account']['fields']['fiscal_end_c']['enforced']='';
$dictionary['Account']['fields']['fiscal_end_c']['dependency']='';

 ?>