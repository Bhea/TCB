<?php
 // created: 2013-12-03 09:16:38
$dictionary['Account']['fields']['no_of_emp_c']['labelValue']='No of Employees';
$dictionary['Account']['fields']['no_of_emp_c']['full_text_search']=array (
  'boost' => '0',
);
$dictionary['Account']['fields']['no_of_emp_c']['enforced']='';
$dictionary['Account']['fields']['no_of_emp_c']['dependency']='';

 ?>