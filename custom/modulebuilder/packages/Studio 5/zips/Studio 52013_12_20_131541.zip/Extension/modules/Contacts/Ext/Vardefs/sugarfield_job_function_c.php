<?php
 // created: 2013-12-06 17:33:42
$dictionary['Contact']['fields']['job_function_c']['labelValue']='Job Function';
$dictionary['Contact']['fields']['job_function_c']['dependency']='';
$dictionary['Contact']['fields']['job_function_c']['visibility_grid']='';

 ?>