<?php
 // created: 2013-12-03 14:54:02
$layout_defs["Leads"]["subpanel_setup"]['leads_contacts_1'] = array (
  'order' => 100,
  'module' => 'Contacts',
  'subpanel_name' => 'default',
  'title_key' => 'LBL_LEADS_CONTACTS_1_FROM_CONTACTS_TITLE',
  'get_subpanel_data' => 'leads_contacts_1',
);
