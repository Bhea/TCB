<?php
 // created: 2013-12-17 14:51:41
$dictionary['Opportunity']['fields']['contact_c']['labelValue']='Contacts';
$dictionary['Opportunity']['fields']['contact_c']['dependency']='or(equal($opportunity_type,"Council"),equal($opportunity_type,"prod_service"))';

 ?>