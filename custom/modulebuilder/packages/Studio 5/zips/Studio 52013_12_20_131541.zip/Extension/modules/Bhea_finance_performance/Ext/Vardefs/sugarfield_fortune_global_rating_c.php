<?php
 // created: 2013-12-13 18:20:39
$dictionary['Bhea_finance_performance']['fields']['fortune_global_rating_c']['labelValue']='Fortune Global Rating';
$dictionary['Bhea_finance_performance']['fields']['fortune_global_rating_c']['full_text_search']=array (
  'boost' => '0',
);
$dictionary['Bhea_finance_performance']['fields']['fortune_global_rating_c']['enforced']='';
$dictionary['Bhea_finance_performance']['fields']['fortune_global_rating_c']['dependency']='';

 ?>