<?php
 // created: 2013-12-01 12:14:56
$dictionary['Bhea_Touch_Points']['fields']['registered_emp']['full_text_search']=array (
  'boost' => '0',
);

 ?>