<?php
 // created: 2013-12-13 18:19:34
$dictionary['Bhea_finance_performance']['fields']['assets_c']['labelValue']='Assets';
$dictionary['Bhea_finance_performance']['fields']['assets_c']['enforced']='';
$dictionary['Bhea_finance_performance']['fields']['assets_c']['dependency']='';

 ?>