<?php
 // created: 2013-12-17 19:18:10
$dictionary['Opportunity']['fields']['from_denomination_c']['labelValue']='Denomination';
$dictionary['Opportunity']['fields']['from_denomination_c']['dependency']='';
$dictionary['Opportunity']['fields']['from_denomination_c']['visibility_grid']='';

 ?>