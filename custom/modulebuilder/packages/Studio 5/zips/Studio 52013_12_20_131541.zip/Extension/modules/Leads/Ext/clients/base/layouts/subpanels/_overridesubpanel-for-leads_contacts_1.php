<?php
//auto-generated file DO NOT EDIT
$viewdefs['Leads']['base']['layout']['subpanels']['components'][]['override_subpanel_list_view'] = array (
  'link' => 'leads_contacts_1',
  'view' => 'subpanel-for-leads',
);
?>