<?php
 // created: 2013-12-18 16:33:19
$dictionary['Contact']['fields']['contact_type_c']['labelValue']='Contact Type';
$dictionary['Contact']['fields']['contact_type_c']['dependency']='';
$dictionary['Contact']['fields']['contact_type_c']['visibility_grid']='';

 ?>