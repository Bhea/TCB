<?php
// created: 2013-12-03 10:55:16
$viewdefs['Leads']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_LEADS_BHEA_FINANCE_PERFORMANCE_1_FROM_BHEA_FINANCE_PERFORMANCE_TITLE',
  'context' => 
  array (
    'link' => 'leads_bhea_finance_performance_1',
  ),
);