<?php
 // created: 2013-12-03 10:55:16
$layout_defs["Leads"]["subpanel_setup"]['leads_bhea_finance_performance_1'] = array (
  'order' => 100,
  'module' => 'Bhea_finance_performance',
  'subpanel_name' => 'default',
  'title_key' => 'LBL_LEADS_BHEA_FINANCE_PERFORMANCE_1_FROM_BHEA_FINANCE_PERFORMANCE_TITLE',
  'get_subpanel_data' => 'leads_bhea_finance_performance_1',
);
