<?php
 // created: 2013-12-03 10:39:15
$layout_defs["Bhea_Program"]["subpanel_setup"]['opportunities_bhea_program_1'] = array (
  'order' => 100,
  'module' => 'Opportunities',
  'subpanel_name' => 'default',
  'title_key' => 'LBL_OPPORTUNITIES_BHEA_PROGRAM_1_FROM_OPPORTUNITIES_TITLE',
  'get_subpanel_data' => 'opportunities_bhea_program_1',
);
