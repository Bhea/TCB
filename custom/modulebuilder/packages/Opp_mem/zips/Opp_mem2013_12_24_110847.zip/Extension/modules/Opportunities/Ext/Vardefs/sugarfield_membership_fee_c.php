<?php
 // created: 2013-12-21 10:51:30
$dictionary['Opportunity']['fields']['membership_fee_c']['labelValue']='Membership Fee';
$dictionary['Opportunity']['fields']['membership_fee_c']['enforced']='';
$dictionary['Opportunity']['fields']['membership_fee_c']['dependency']='';

 ?>