<?php
 // created: 2013-12-19 10:57:25
$dictionary['Opportunity']['fields']['membership_sub_category_c']['labelValue']='Membership Sub Category';
$dictionary['Opportunity']['fields']['membership_sub_category_c']['visibility_grid']='';

 ?>