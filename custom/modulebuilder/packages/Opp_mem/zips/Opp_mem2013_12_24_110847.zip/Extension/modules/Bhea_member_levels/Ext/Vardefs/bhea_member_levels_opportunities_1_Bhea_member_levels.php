<?php
// created: 2013-12-09 16:42:05
$dictionary["Bhea_member_levels"]["fields"]["bhea_member_levels_opportunities_1"] = array (
  'name' => 'bhea_member_levels_opportunities_1',
  'type' => 'link',
  'relationship' => 'bhea_member_levels_opportunities_1',
  'source' => 'non-db',
  'module' => 'Opportunities',
  'bean_name' => 'Opportunity',
  'vname' => 'LBL_BHEA_MEMBER_LEVELS_OPPORTUNITIES_1_FROM_BHEA_MEMBER_LEVELS_TITLE',
  'id_name' => 'bhea_member_levels_opportunities_1bhea_member_levels_ida',
  'link-type' => 'many',
  'side' => 'left',
);
