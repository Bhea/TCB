<?php
 // created: 2013-12-20 11:11:17
$dictionary['Opportunity']['fields']['access_level_c']['labelValue']='Access Level';
$dictionary['Opportunity']['fields']['access_level_c']['dependency']='';
$dictionary['Opportunity']['fields']['access_level_c']['visibility_grid']='';

 ?>