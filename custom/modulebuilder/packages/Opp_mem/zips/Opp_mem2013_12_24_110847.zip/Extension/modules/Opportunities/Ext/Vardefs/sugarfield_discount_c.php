<?php
 // created: 2013-12-03 16:34:52
$dictionary['Opportunity']['fields']['discount_c']['labelValue']='Discount';
$dictionary['Opportunity']['fields']['discount_c']['enforced']='';
$dictionary['Opportunity']['fields']['discount_c']['dependency']='';

 ?>