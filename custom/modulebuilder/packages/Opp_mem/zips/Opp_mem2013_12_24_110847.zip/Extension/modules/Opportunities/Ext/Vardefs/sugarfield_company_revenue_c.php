<?php
 // created: 2013-12-20 12:26:05
$dictionary['Opportunity']['fields']['company_revenue_c']['duplicate_merge_dom_value']=0;
$dictionary['Opportunity']['fields']['company_revenue_c']['labelValue']='Company Revenue(M)';
$dictionary['Opportunity']['fields']['company_revenue_c']['calculated']='1';
$dictionary['Opportunity']['fields']['company_revenue_c']['formula']='related($accounts,"annual_revenue")';
$dictionary['Opportunity']['fields']['company_revenue_c']['enforced']='1';
$dictionary['Opportunity']['fields']['company_revenue_c']['dependency']='';

 ?>