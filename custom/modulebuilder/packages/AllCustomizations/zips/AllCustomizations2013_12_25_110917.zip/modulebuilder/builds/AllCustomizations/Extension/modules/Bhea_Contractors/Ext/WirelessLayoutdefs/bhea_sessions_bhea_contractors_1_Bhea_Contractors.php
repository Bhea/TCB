<?php
 // created: 2013-12-20 11:10:57
$layout_defs["Bhea_Contractors"]["subpanel_setup"]['bhea_sessions_bhea_contractors_1'] = array (
  'order' => 100,
  'module' => 'Bhea_Sessions',
  'subpanel_name' => 'default',
  'title_key' => 'LBL_BHEA_SESSIONS_BHEA_CONTRACTORS_1_FROM_BHEA_SESSIONS_TITLE',
  'get_subpanel_data' => 'bhea_sessions_bhea_contractors_1',
);
