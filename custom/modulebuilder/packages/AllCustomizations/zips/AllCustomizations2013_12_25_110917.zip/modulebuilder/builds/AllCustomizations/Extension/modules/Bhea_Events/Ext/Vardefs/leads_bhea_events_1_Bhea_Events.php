<?php
// created: 2013-12-03 15:33:08
$dictionary["Bhea_Events"]["fields"]["leads_bhea_events_1"] = array (
  'name' => 'leads_bhea_events_1',
  'type' => 'link',
  'relationship' => 'leads_bhea_events_1',
  'source' => 'non-db',
  'module' => 'Leads',
  'bean_name' => 'Lead',
  'vname' => 'LBL_LEADS_BHEA_EVENTS_1_FROM_LEADS_TITLE',
  'id_name' => 'leads_bhea_events_1leads_ida',
);
