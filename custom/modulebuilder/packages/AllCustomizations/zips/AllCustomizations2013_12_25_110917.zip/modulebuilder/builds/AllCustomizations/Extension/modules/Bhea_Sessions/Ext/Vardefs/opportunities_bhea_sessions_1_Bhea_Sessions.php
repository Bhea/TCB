<?php
// created: 2013-12-19 18:57:27
$dictionary["Bhea_Sessions"]["fields"]["opportunities_bhea_sessions_1"] = array (
  'name' => 'opportunities_bhea_sessions_1',
  'type' => 'link',
  'relationship' => 'opportunities_bhea_sessions_1',
  'source' => 'non-db',
  'module' => 'Opportunities',
  'bean_name' => 'Opportunity',
  'vname' => 'LBL_OPPORTUNITIES_BHEA_SESSIONS_1_FROM_OPPORTUNITIES_TITLE',
  'id_name' => 'opportunities_bhea_sessions_1opportunities_ida',
);
