<?php
// created: 2013-12-04 09:46:31
$viewdefs['Bhea_Sessions']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_CONTACTS_BHEA_SESSIONS_1_FROM_CONTACTS_TITLE',
  'context' => 
  array (
    'link' => 'contacts_bhea_sessions_1',
  ),
);