<?php
/*********************************************************************************
 * By installing or using this file, you are confirming on behalf of the entity
 * subscribed to the SugarCRM Inc. product ("Company") that Company is bound by
 * the SugarCRM Inc. Master Subscription Agreement (“MSA”), which is viewable at:
 * http://www.sugarcrm.com/master-subscription-agreement
 *
 * If Company is not bound by the MSA, then by installing or using this file
 * you are agreeing unconditionally that Company will be bound by the MSA and
 * certifying that you have authority to bind Company accordingly.
 *
 * Copyright (C) 2004-2013 SugarCRM Inc.  All rights reserved.
 ********************************************************************************/

$mod_strings = array (
  'LBL_TEAM' => 'צוותים',
  'LBL_TEAMS' => 'צוותים',
  'LBL_TEAM_ID' => 'Team Id',
  'LBL_ASSIGNED_TO_ID' => 'משתמש שהוקצה Id',
  'LBL_ASSIGNED_TO_NAME' => 'משתמש',
  'LBL_ID' => 'ID',
  'LBL_DATE_ENTERED' => 'נוצר בתאריך',
  'LBL_DATE_MODIFIED' => 'שונה בתאריך',
  'LBL_MODIFIED' => 'שונה על ידי',
  'LBL_MODIFIED_ID' => 'שונה על ידי Id',
  'LBL_MODIFIED_NAME' => 'שונה על ידי ששמו',
  'LBL_CREATED' => 'נוצר על ידי',
  'LBL_CREATED_ID' => 'נוצר על ידי Id',
  'LBL_DESCRIPTION' => 'תיאור',
  'LBL_DELETED' => 'נמחק',
  'LBL_NAME' => 'שם',
  'LBL_CREATED_USER' => 'נוצר על ידי משתמש',
  'LBL_MODIFIED_USER' => 'שונה על ידי משתמש',
  'LBL_LIST_NAME' => 'שם',
  'LBL_LIST_FORM_TITLE' => 'Membership Levels List',
  'LBL_MODULE_NAME' => 'Membership Levels',
  'LBL_MODULE_TITLE' => 'Membership Levels',
  'LBL_HOMEPAGE_TITLE' => 'My Membership Levels',
  'LNK_NEW_RECORD' => 'Create Membership Levels',
  'LNK_LIST' => 'View Membership Levels',
  'LNK_IMPORT_BHEA_MEMBER_LEVELS' => 'Import Membership Levels',
  'LBL_SEARCH_FORM_TITLE' => 'Search Membership Levels',
  'LBL_HISTORY_SUBPANEL_TITLE' => 'View History',
  'LBL_ACTIVITIES_SUBPANEL_TITLE' => 'Activities',
  'LBL_BHEA_MEMBER_LEVELS_SUBPANEL_TITLE' => 'Membership Levels',
  'LBL_NEW_FORM_TITLE' => 'New Membership Levels',
  'LBL_MEM_TYPE' => 'Membership Type',
  'LBL_GEOGRAPHY' => 'Geography',
  'LBL_STATUS' => 'Status',
  'LBL_START_DATE' => 'Starting From',
  'LBL_END_DATE' => 'End Date',
  'LBL_MEM_PERIOD' => 'Membership Period',
  'LBL_CAT_TYPE' => 'Category Type',
  'LBL_PRICE_TYPE' => 'Pricing Type',
  'LBL_COST' => 'Cost',
  'LBL_DISCOUNT' => 'Discount',
  'LBL_MODULE_NAME_SINGULAR' => 'Membership Levels',
  'LNK_IMPORT_VCARD' => 'Import Membership Levels vCard',
  'LBL_IMPORT' => 'Import Membership Levels',
  'LBL_IMPORT_VCARDTEXT' => 'Automatically create a new Membership Levels record by importing a vCard from your file system.',
);