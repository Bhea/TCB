<?php
 // created: 2013-12-03 19:12:24
$dictionary['Bhea_Memberships']['fields']['final_mem_fee_c']['duplicate_merge_dom_value']=0;
$dictionary['Bhea_Memberships']['fields']['final_mem_fee_c']['labelValue']='Final Membership Fee';
$dictionary['Bhea_Memberships']['fields']['final_mem_fee_c']['calculated']='true';
$dictionary['Bhea_Memberships']['fields']['final_mem_fee_c']['formula']='subtract($mem_fee,$discount_c)';
$dictionary['Bhea_Memberships']['fields']['final_mem_fee_c']['enforced']='true';
$dictionary['Bhea_Memberships']['fields']['final_mem_fee_c']['dependency']='';

 ?>