<?php
 // created: 2013-12-06 15:49:44
$dictionary['Bhea_Memberships']['fields']['days_c']['labelValue']='days';
$dictionary['Bhea_Memberships']['fields']['days_c']['full_text_search']=array (
  'boost' => '0',
);
$dictionary['Bhea_Memberships']['fields']['days_c']['enforced']='';
$dictionary['Bhea_Memberships']['fields']['days_c']['dependency']='';

 ?>