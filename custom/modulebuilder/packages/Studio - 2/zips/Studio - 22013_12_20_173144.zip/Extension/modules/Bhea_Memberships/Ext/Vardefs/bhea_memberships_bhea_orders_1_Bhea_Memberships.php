<?php
// created: 2013-12-17 09:47:24
$dictionary["Bhea_Memberships"]["fields"]["bhea_memberships_bhea_orders_1"] = array (
  'name' => 'bhea_memberships_bhea_orders_1',
  'type' => 'link',
  'relationship' => 'bhea_memberships_bhea_orders_1',
  'source' => 'non-db',
  'module' => 'Bhea_Orders',
  'bean_name' => 'Bhea_Orders',
  'vname' => 'LBL_BHEA_MEMBERSHIPS_BHEA_ORDERS_1_FROM_BHEA_MEMBERSHIPS_TITLE',
  'id_name' => 'bhea_memberships_bhea_orders_1bhea_memberships_ida',
  'link-type' => 'many',
  'side' => 'left',
);
