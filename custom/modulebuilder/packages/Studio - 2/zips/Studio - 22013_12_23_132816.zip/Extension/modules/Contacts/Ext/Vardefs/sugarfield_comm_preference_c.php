<?php
 // created: 2013-12-03 09:59:07
$dictionary['Contact']['fields']['comm_preference_c']['labelValue']='Communication Preference';
$dictionary['Contact']['fields']['comm_preference_c']['dependency']='';
$dictionary['Contact']['fields']['comm_preference_c']['visibility_grid']='';

 ?>