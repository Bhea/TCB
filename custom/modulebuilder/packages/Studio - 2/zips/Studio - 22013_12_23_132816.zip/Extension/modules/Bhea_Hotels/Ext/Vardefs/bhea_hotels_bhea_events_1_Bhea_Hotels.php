<?php
// created: 2013-12-04 09:54:49
$dictionary["Bhea_Hotels"]["fields"]["bhea_hotels_bhea_events_1"] = array (
  'name' => 'bhea_hotels_bhea_events_1',
  'type' => 'link',
  'relationship' => 'bhea_hotels_bhea_events_1',
  'source' => 'non-db',
  'module' => 'Bhea_Events',
  'bean_name' => 'Bhea_Events',
  'vname' => 'LBL_BHEA_HOTELS_BHEA_EVENTS_1_FROM_BHEA_HOTELS_TITLE',
  'id_name' => 'bhea_hotels_bhea_events_1bhea_hotels_ida',
  'link-type' => 'many',
  'side' => 'left',
);
