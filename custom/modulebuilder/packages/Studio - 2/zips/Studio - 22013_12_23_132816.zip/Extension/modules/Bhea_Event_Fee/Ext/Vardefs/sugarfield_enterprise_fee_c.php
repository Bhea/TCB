<?php
 // created: 2013-12-16 15:19:32
$dictionary['Bhea_Event_Fee']['fields']['enterprise_fee_c']['labelValue']='Enterprise Fee';
$dictionary['Bhea_Event_Fee']['fields']['enterprise_fee_c']['enforced']='';
$dictionary['Bhea_Event_Fee']['fields']['enterprise_fee_c']['dependency']='equal($type_c,"Members")';

 ?>