<?php
 // created: 2013-12-17 09:47:24
$layout_defs["Bhea_Memberships"]["subpanel_setup"]['bhea_memberships_bhea_orders_1'] = array (
  'order' => 100,
  'module' => 'Bhea_Orders',
  'subpanel_name' => 'default',
  'title_key' => 'LBL_BHEA_MEMBERSHIPS_BHEA_ORDERS_1_FROM_BHEA_ORDERS_TITLE',
  'get_subpanel_data' => 'bhea_memberships_bhea_orders_1',
);
