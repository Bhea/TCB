<?php
 // created: 2013-12-03 18:37:00
$dictionary['Bhea_Events']['fields']['status']['default']='Tentative';
$dictionary['Bhea_Events']['fields']['status']['options']='event_status_3';
$dictionary['Bhea_Events']['fields']['status']['visibility_grid']=array (
  'trigger' => 'event_type',
  'values' => 
  array (
    'Conference' => 
    array (
      0 => 'Tentative',
      1 => 'Date_Confirmed',
      2 => 'Ready_for_Registration',
      3 => 'Early_Bird_Time',
      4 => 'Registration_Closure',
      5 => 'In_Session',
      6 => 'Completed',
      7 => 'Cancelled',
      8 => 'Postponed',
    ),
    'Seminar' => 
    array (
    ),
    'Web_Cast' => 
    array (
    ),
    'Council_Meeting' => 
    array (
    ),
    'Inter_Council_Meeting' => 
    array (
    ),
    'Working_Group' => 
    array (
    ),
    'Other' => 
    array (
    ),
  ),
);

 ?>