<?php
 // created: 2013-12-21 10:53:46
$dictionary['Bhea_Memberships']['fields']['payment_status']['default']='OrderGenerated';

 ?>