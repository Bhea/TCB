<?php
 // created: 2013-12-16 15:23:54
$dictionary['Bhea_Event_Fee']['fields']['mid_market_fee_c']['labelValue']='Mid Market Fee';
$dictionary['Bhea_Event_Fee']['fields']['mid_market_fee_c']['enforced']='';
$dictionary['Bhea_Event_Fee']['fields']['mid_market_fee_c']['dependency']='equal($type_c,"Members")';

 ?>