<?php
// created: 2013-12-03 12:23:01
$viewdefs['Bhea_Events']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_BHEA_EVENTS_BHEA_EVENTS_1_FROM_BHEA_EVENTS_R_TITLE',
  'context' => 
  array (
    'link' => 'bhea_events_bhea_events_1',
  ),
);