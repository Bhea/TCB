<?php
 // created: 2013-12-03 19:10:31
$dictionary['Bhea_Memberships']['fields']['discount_c']['labelValue']='Discount';
$dictionary['Bhea_Memberships']['fields']['discount_c']['enforced']='';
$dictionary['Bhea_Memberships']['fields']['discount_c']['dependency']='';

 ?>