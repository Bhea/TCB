<?php
 // created: 2013-12-16 16:39:57
$dictionary['Bhea_Event_Fee']['fields']['early_bird_discount_c']['labelValue']='Early Bird Discount';
$dictionary['Bhea_Event_Fee']['fields']['early_bird_discount_c']['full_text_search']=array (
  'boost' => '0',
);
$dictionary['Bhea_Event_Fee']['fields']['early_bird_discount_c']['enforced']='';

 ?>