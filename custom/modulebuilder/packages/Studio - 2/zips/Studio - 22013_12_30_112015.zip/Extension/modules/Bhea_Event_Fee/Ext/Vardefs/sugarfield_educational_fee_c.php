<?php
 // created: 2013-12-16 15:25:20
$dictionary['Bhea_Event_Fee']['fields']['educational_fee_c']['labelValue']='Educational Fee';
$dictionary['Bhea_Event_Fee']['fields']['educational_fee_c']['enforced']='';
$dictionary['Bhea_Event_Fee']['fields']['educational_fee_c']['dependency']='equal($type_c,"Members")';

 ?>