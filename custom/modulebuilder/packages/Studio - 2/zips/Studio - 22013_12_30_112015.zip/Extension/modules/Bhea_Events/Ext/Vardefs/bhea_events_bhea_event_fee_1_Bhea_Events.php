<?php
// created: 2013-12-16 15:30:32
$dictionary["Bhea_Events"]["fields"]["bhea_events_bhea_event_fee_1"] = array (
  'name' => 'bhea_events_bhea_event_fee_1',
  'type' => 'link',
  'relationship' => 'bhea_events_bhea_event_fee_1',
  'source' => 'non-db',
  'module' => 'Bhea_Event_Fee',
  'bean_name' => 'Bhea_Event_Fee',
  'vname' => 'LBL_BHEA_EVENTS_BHEA_EVENT_FEE_1_FROM_BHEA_EVENTS_TITLE',
  'id_name' => 'bhea_events_bhea_event_fee_1bhea_events_ida',
  'link-type' => 'many',
  'side' => 'left',
);
