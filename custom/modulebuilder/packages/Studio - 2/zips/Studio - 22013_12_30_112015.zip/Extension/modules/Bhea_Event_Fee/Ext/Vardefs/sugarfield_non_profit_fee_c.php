<?php
 // created: 2013-12-16 15:23:00
$dictionary['Bhea_Event_Fee']['fields']['non_profit_fee_c']['labelValue']='Non Profit Fee';
$dictionary['Bhea_Event_Fee']['fields']['non_profit_fee_c']['enforced']='';
$dictionary['Bhea_Event_Fee']['fields']['non_profit_fee_c']['dependency']='or(equal($type_c,"Members"),equal($type_c,"Non_Members"))';

 ?>