<?php
// created: 2013-12-04 09:54:49
$viewdefs['Bhea_Hotels']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_BHEA_HOTELS_BHEA_EVENTS_1_FROM_BHEA_EVENTS_TITLE',
  'context' => 
  array (
    'link' => 'bhea_hotels_bhea_events_1',
  ),
);