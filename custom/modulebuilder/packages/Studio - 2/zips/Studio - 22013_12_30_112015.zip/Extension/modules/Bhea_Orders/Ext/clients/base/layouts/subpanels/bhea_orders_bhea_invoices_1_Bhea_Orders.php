<?php
// created: 2013-12-24 09:35:41
$viewdefs['Bhea_Orders']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_BHEA_ORDERS_BHEA_INVOICES_1_FROM_BHEA_INVOICES_TITLE',
  'context' => 
  array (
    'link' => 'bhea_orders_bhea_invoices_1',
  ),
);