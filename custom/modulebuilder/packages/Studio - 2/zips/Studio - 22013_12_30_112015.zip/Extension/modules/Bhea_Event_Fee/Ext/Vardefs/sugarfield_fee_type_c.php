<?php
 // created: 2013-12-27 18:10:20
$dictionary['Bhea_Event_Fee']['fields']['fee_type_c']['labelValue']='Fee Type';
$dictionary['Bhea_Event_Fee']['fields']['fee_type_c']['dependency']='';
$dictionary['Bhea_Event_Fee']['fields']['fee_type_c']['visibility_grid']=array (
  'trigger' => 'type_c',
  'values' => 
  array (
    'Members' => 
    array (
      0 => 'Regular_Fee',
      1 => 'Academic_Fee',
      2 => 'Educational_Fee',
      3 => 'Enterprise_Fee',
      4 => 'Government_Fee',
      5 => 'Mid_Market_Fee',
      6 => 'Non_Profit_Fee',
      7 => 'Team_Discount',
    ),
    'Non_Members' => 
    array (
      0 => 'Regular_Fee',
      1 => 'Government_Fee',
      2 => 'Non_Profit_Fee',
      3 => 'Academic_Fee',
      4 => 'Educational_Fee',
      5 => 'Team_Discount',
    ),
  ),
);

 ?>