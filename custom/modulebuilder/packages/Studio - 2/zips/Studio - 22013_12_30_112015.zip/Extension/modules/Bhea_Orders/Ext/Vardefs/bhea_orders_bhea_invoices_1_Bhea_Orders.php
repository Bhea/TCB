<?php
// created: 2013-12-24 09:35:41
$dictionary["Bhea_Orders"]["fields"]["bhea_orders_bhea_invoices_1"] = array (
  'name' => 'bhea_orders_bhea_invoices_1',
  'type' => 'link',
  'relationship' => 'bhea_orders_bhea_invoices_1',
  'source' => 'non-db',
  'module' => 'Bhea_Invoices',
  'bean_name' => 'Bhea_Invoices',
  'vname' => 'LBL_BHEA_ORDERS_BHEA_INVOICES_1_FROM_BHEA_ORDERS_TITLE',
  'id_name' => 'bhea_orders_bhea_invoices_1bhea_orders_ida',
  'link-type' => 'many',
  'side' => 'left',
);
