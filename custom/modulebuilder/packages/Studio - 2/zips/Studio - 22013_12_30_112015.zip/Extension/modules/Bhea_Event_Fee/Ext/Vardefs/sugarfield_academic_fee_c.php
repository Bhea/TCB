<?php
 // created: 2013-12-16 15:26:07
$dictionary['Bhea_Event_Fee']['fields']['academic_fee_c']['labelValue']='Academic Fee';
$dictionary['Bhea_Event_Fee']['fields']['academic_fee_c']['enforced']='';
$dictionary['Bhea_Event_Fee']['fields']['academic_fee_c']['dependency']='or(equal($type_c,"Members"),equal($type_c,"Non_Members"))';

 ?>