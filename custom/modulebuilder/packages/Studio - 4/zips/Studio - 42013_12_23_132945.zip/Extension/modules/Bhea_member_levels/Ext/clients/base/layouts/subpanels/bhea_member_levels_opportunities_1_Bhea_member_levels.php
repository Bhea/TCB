<?php
// created: 2013-12-09 16:42:05
$viewdefs['Bhea_member_levels']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_BHEA_MEMBER_LEVELS_OPPORTUNITIES_1_FROM_OPPORTUNITIES_TITLE',
  'context' => 
  array (
    'link' => 'bhea_member_levels_opportunities_1',
  ),
);