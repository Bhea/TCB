<?php
 // created: 2013-12-03 10:06:35
$dictionary['Contact']['fields']['password_c']['labelValue']='Password';
$dictionary['Contact']['fields']['password_c']['enforced']='';
$dictionary['Contact']['fields']['password_c']['dependency']='';

 ?>