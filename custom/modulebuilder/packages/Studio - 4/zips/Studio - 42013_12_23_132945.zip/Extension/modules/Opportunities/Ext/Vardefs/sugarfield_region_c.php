<?php
 // created: 2013-12-16 11:54:05
$dictionary['Opportunity']['fields']['region_c']['labelValue']='Region';
$dictionary['Opportunity']['fields']['region_c']['dependency']='';
$dictionary['Opportunity']['fields']['region_c']['visibility_grid']='';

 ?>