<?php
 // created: 2013-12-09 16:42:05
$layout_defs["Bhea_member_levels"]["subpanel_setup"]['bhea_member_levels_opportunities_1'] = array (
  'order' => 100,
  'module' => 'Opportunities',
  'subpanel_name' => 'default',
  'title_key' => 'LBL_BHEA_MEMBER_LEVELS_OPPORTUNITIES_1_FROM_OPPORTUNITIES_TITLE',
  'get_subpanel_data' => 'bhea_member_levels_opportunities_1',
);
