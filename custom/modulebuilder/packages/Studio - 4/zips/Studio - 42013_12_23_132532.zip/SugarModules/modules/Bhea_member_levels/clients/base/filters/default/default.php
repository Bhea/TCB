<?php
// created: 2013-12-03 17:52:10
$viewdefs['Bhea_member_levels']['base']['filter']['default'] = array (
  'default_filter' => 'all_records',
  'fields' => 
  array (
    'name' => 
    array (
    ),
    'mem_type' => 
    array (
    ),
    'mem_period' => 
    array (
    ),
    'price_type' => 
    array (
    ),
    'cat_type' => 
    array (
    ),
    'assigned_user_name' => 
    array (
    ),
    '$owner' => 
    array (
      'predefined_filter' => true,
      'vname' => 'LBL_CURRENT_USER_FILTER',
    ),
    '$favorite' => 
    array (
      'predefined_filter' => true,
      'vname' => 'LBL_FAVORITES_FILTER',
    ),
  ),
);