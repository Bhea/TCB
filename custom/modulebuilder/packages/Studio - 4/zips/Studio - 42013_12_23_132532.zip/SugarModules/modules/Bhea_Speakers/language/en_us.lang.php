<?php 
 // created: 2013-12-23 13:25:30
$mod_strings['LBL_CONTACT'] = 'Contacts';
$mod_strings['LBL_ACCOUNT '] = 'Account not';
$mod_strings['LBL_FAMILIAR_NAME'] = 'Familiar Name';

?>
