<?php
 // created: 2013-12-03 09:00:41
$dictionary['Bhea_Speakers']['fields']['familiar_name_c']['labelValue']='Familiar Name';
$dictionary['Bhea_Speakers']['fields']['familiar_name_c']['full_text_search']=array (
  'boost' => '0',
);
$dictionary['Bhea_Speakers']['fields']['familiar_name_c']['enforced']='';
$dictionary['Bhea_Speakers']['fields']['familiar_name_c']['dependency']='';

 ?>