<?php
 // created: 2013-12-03 19:08:33
$dictionary['Bhea_Sponsorship']['fields']['sponsorship_type']['default']='Platinum';
$dictionary['Bhea_Sponsorship']['fields']['sponsorship_type']['options']='sponsorship_type_0';

 ?>