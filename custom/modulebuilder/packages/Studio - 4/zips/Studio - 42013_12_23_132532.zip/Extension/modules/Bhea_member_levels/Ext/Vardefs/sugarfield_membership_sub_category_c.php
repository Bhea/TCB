<?php
 // created: 2013-12-17 15:01:13
$dictionary['Bhea_member_levels']['fields']['membership_sub_category_c']['labelValue']='Membership Sub Category';
$dictionary['Bhea_member_levels']['fields']['membership_sub_category_c']['dependency']='';
$dictionary['Bhea_member_levels']['fields']['membership_sub_category_c']['visibility_grid']='';

 ?>