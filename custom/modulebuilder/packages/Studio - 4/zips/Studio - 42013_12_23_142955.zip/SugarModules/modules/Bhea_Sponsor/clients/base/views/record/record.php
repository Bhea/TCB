<?php
$module_name = 'Bhea_Sponsor';
$viewdefs[$module_name] = 
array (
  'base' => 
  array (
    'view' => 
    array (
      'record' => 
      array (
        'panels' => 
        array (
          0 => 
          array (
            'name' => 'panel_header',
            'label' => 'LBL_RECORD_HEADER',
            'header' => true,
            'fields' => 
            array (
              0 => 
              array (
                'name' => 'picture',
                'type' => 'avatar',
                'width' => 42,
                'height' => 42,
                'dismiss_label' => true,
                'readonly' => true,
              ),
              1 => 'name',
              2 => 
              array (
                'name' => 'favorite',
                'label' => 'LBL_FAVORITE',
                'type' => 'favorite',
                'readonly' => true,
                'dismiss_label' => true,
              ),
              3 => 
              array (
                'name' => 'follow',
                'label' => 'LBL_FOLLOW',
                'type' => 'follow',
                'readonly' => true,
                'dismiss_label' => true,
              ),
            ),
          ),
          1 => 
          array (
            'name' => 'panel_body',
            'label' => 'LBL_RECORD_BODY',
            'columns' => 2,
            'labelsOnTop' => true,
            'placeholders' => true,
            'fields' => 
            array (
              0 => 
              array (
                'name' => 'logo',
                'studio' => 'visible',
                'label' => 'LBL_LOGO',
              ),
              1 => 
              array (
                'name' => 'status',
                'studio' => 'visible',
                'label' => 'LBL_STATUS',
              ),
              2 => 
              array (
                'name' => 'bhea_events_bhea_sponsor_1_name',
                'label' => 'LBL_BHEA_EVENTS_BHEA_SPONSOR_1_FROM_BHEA_EVENTS_TITLE',
              ),
              3 => 
              array (
                'name' => 'contact_person_c',
                'studio' => 'visible',
                'label' => 'LBL_CONTACT_PERSON',
              ),
              4 => 
              array (
                'name' => 'mobile_phone_c',
                'label' => 'LBL_MOBILE_PHONE',
              ),
              5 => 
              array (
                'name' => 'office_phone_c',
                'label' => 'LBL_OFFICE_PHONE',
              ),
              6 => 
              array (
                'name' => 'company_address_street_c',
                'label' => 'LBL_COMPANY_ADDRESS_STREET',
                'span' => 6,
              ),
              7 => 
              array (
                'span' => 6,
              ),
              8 => 
              array (
                'name' => 'company_address_city_c',
                'label' => 'LBL_COMPANY_ADDRESS_CITY',
              ),
              9 => 
              array (
                'name' => 'company_address_state_c',
                'label' => 'LBL_COMPANY_ADDRESS_STATE',
              ),
              10 => 
              array (
                'name' => 'company_address_country_c',
                'label' => 'LBL_COMPANY_ADDRESS_COUNTRY',
              ),
              11 => 
              array (
                'name' => 'company_address_postalcode_c',
                'label' => 'LBL_COMPANY_ADDRESS_POSTALCODE',
              ),
              12 => 
              array (
                'name' => 'description',
                'comment' => 'Full text of the note',
                'studio' => 'visible',
                'label' => 'LBL_DESCRIPTION',
              ),
              13 => 
              array (
                'name' => 'sponsorship_description',
                'studio' => 'visible',
                'label' => 'LBL_SPONSORSHIP_DESCRIPTION ',
              ),
              14 => 
              array (
                'name' => 'date_entered',
                'comment' => 'Date record created',
                'studio' => 
                array (
                  'portaleditview' => false,
                ),
                'readonly' => true,
                'label' => 'LBL_DATE_ENTERED',
              ),
              15 => 
              array (
                'name' => 'created_by_name',
                'readonly' => true,
                'label' => 'LBL_CREATED',
              ),
              16 => 
              array (
                'name' => 'date_modified',
                'comment' => 'Date record last modified',
                'studio' => 
                array (
                  'portaleditview' => false,
                ),
                'readonly' => true,
                'label' => 'LBL_DATE_MODIFIED',
              ),
              17 => 
              array (
                'name' => 'modified_by_name',
                'readonly' => true,
                'label' => 'LBL_MODIFIED_NAME',
              ),
              18 => 'assigned_user_name',
              19 => 'team_name',
            ),
          ),
        ),
        'templateMeta' => 
        array (
          'useTabs' => false,
          'tabDefs' => 
          array (
            'LBL_RECORD_BODY' => 
            array (
              'newTab' => false,
              'panelDefault' => 'expanded',
            ),
          ),
        ),
      ),
    ),
  ),
);
