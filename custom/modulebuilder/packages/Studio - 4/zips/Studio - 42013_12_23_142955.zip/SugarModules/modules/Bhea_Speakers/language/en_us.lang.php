<?php 
 // created: 2013-12-23 14:29:53
$mod_strings['LBL_CONTACT'] = 'Contacts';
$mod_strings['LBL_ACCOUNT '] = 'Account not';
$mod_strings['LBL_FAMILIAR_NAME'] = 'Familiar Name';

?>
