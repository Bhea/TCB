<?php 
 // created: 2013-12-23 14:29:53
$mod_strings['LBL_DESCRIPTION'] = 'Company Description';
$mod_strings['LBL_SPONSORSHIP_DESCRIPTION '] = 'Sponsorship Description';
$mod_strings['LBL_BHEA_SPONSOR_BHEA_SESSIONS_1_FROM_BHEA_SESSIONS_TITLE'] = 'Sessions';
$mod_strings['LBL_BHEA_SPONSOR_BHEA_SPONSORSHIP_1_FROM_BHEA_SPONSORSHIP_TITLE'] = 'Sponsorship';
$mod_strings['LBL_COMPANY_ADDRESS_STREET'] = 'Company Address Street';
$mod_strings['LBL_COMPANY_ADDRESS_CITY'] = 'Company Address City';
$mod_strings['LBL_COMPANY_ADDRESS_STATE'] = 'Company Address State';
$mod_strings['LBL_COMPANY_ADDRESS_POSTALCODE'] = 'Company Address PostalCode';
$mod_strings['LBL_COMPANY_ADDRESS_COUNTRY'] = 'Company Address Country';
$mod_strings['LBL_COMPANY_ADDRESS'] = 'Company Address';
$mod_strings['LBL_OFFICE_PHONE'] = 'Office Phone';
$mod_strings['LBL_MOBILE_PHONE'] = 'Mobile Phone';
$mod_strings['LBL_CONTACT_PERSON_CONTACT_ID'] = 'Contact Person (related Contacts ID)';
$mod_strings['LBL_CONTACT_PERSON'] = 'Contact Person';
$mod_strings['LBL_SPONSOR_TYPE'] = 'Sponsor Type';

?>
