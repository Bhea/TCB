<?php
 // created: 2013-12-03 12:47:50
$dictionary['Bhea_Sponsor']['fields']['description']['full_text_search']=array (
  'boost' => '0',
);
$dictionary['Bhea_Sponsor']['fields']['description']['cols']='50';

 ?>