<?php
 // created: 2013-12-13 18:21:10
$dictionary['Bhea_finance_performance']['fields']['forbes_rating_c']['labelValue']='Forbes Rating';
$dictionary['Bhea_finance_performance']['fields']['forbes_rating_c']['full_text_search']=array (
  'boost' => '0',
);
$dictionary['Bhea_finance_performance']['fields']['forbes_rating_c']['enforced']='';
$dictionary['Bhea_finance_performance']['fields']['forbes_rating_c']['dependency']='';

 ?>