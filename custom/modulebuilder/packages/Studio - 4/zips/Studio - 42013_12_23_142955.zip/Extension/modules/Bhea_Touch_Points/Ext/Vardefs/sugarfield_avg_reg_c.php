<?php
 // created: 2013-12-01 12:10:15
$dictionary['Bhea_Touch_Points']['fields']['avg_reg_c']['labelValue']='Average Registrations';
$dictionary['Bhea_Touch_Points']['fields']['avg_reg_c']['full_text_search']=array (
  'boost' => '0',
);
$dictionary['Bhea_Touch_Points']['fields']['avg_reg_c']['enforced']='';
$dictionary['Bhea_Touch_Points']['fields']['avg_reg_c']['dependency']='';

 ?>