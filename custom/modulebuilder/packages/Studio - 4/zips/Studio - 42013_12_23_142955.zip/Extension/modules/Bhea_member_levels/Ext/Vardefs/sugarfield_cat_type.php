<?php
 // created: 2013-12-17 15:00:32
$dictionary['Bhea_member_levels']['fields']['cat_type']['default']='Local';

 ?>