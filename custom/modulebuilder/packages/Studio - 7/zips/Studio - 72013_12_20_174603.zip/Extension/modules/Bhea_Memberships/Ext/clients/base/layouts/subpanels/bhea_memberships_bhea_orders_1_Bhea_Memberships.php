<?php
// created: 2013-12-17 09:47:24
$viewdefs['Bhea_Memberships']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_BHEA_MEMBERSHIPS_BHEA_ORDERS_1_FROM_BHEA_ORDERS_TITLE',
  'context' => 
  array (
    'link' => 'bhea_memberships_bhea_orders_1',
  ),
);