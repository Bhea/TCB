<?php
 // created: 2013-12-12 19:32:31
$dictionary['Bhea_Orders']['fields']['id_auto_c']['labelValue']='ID';
$dictionary['Bhea_Orders']['fields']['id_auto_c']['full_text_search']=array (
  'boost' => '0',
);
$dictionary['Bhea_Orders']['fields']['id_auto_c']['enforced']='';
$dictionary['Bhea_Orders']['fields']['id_auto_c']['dependency']='';

$dictionary['Bhea_Orders']['fields']['id_auto_c']['auto_increment']=true;
$dictionary['Bhea_Orders']['fields']['id_auto_c']['autoinc_next']='1000';

 ?>
