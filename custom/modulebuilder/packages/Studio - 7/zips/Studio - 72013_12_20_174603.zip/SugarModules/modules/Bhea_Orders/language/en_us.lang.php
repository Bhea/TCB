<?php 
 // created: 2013-12-20 17:46:02
$mod_strings['LBL_ACCOUNTS_BHEA_ORDERS_1_FROM_ACCOUNTS_TITLE'] = 'Company';
$mod_strings['LBL_BHEA_ORDERS_BHEA_PAYMENTS_1_FROM_BHEA_PAYMENTS_TITLE'] = 'Payments';
$mod_strings['LBL_ID_AUTO'] = 'ID';
$mod_strings['LBL_PAYMENT_RECEIVED'] = 'Payment Received';

?>
