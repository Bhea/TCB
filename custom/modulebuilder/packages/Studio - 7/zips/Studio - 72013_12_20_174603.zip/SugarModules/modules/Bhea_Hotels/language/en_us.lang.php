<?php 
 // created: 2013-12-20 17:46:01
$mod_strings['LBL_BHEA_HOTELS_BHEA_EVENTS_1_FROM_BHEA_EVENTS_TITLE'] = 'Events';

?>
