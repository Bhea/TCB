<?php
 // created: 2013-12-13 11:25:13
$dictionary['Opportunity']['fields']['membership_category_c']['labelValue']='Membership Category';
$dictionary['Opportunity']['fields']['membership_category_c']['dependency']='';
$dictionary['Opportunity']['fields']['membership_category_c']['visibility_grid']=array (
  'trigger' => 'opportunity_type',
  'values' => 
  array (
    '' => 
    array (
    ),
    'membership' => 
    array (
      0 => 'Enterprise',
      1 => 'educational',
      2 => 'mid_market',
      3 => 'Government',
    ),
    'Council' => 
    array (
    ),
    'prod_service' => 
    array (
    ),
    'other' => 
    array (
    ),
  ),
);

 ?>