<?php
 // created: 2013-12-03 16:03:12
$dictionary['Lead']['fields']['practice_area_c']['labelValue']='Practice Area';
$dictionary['Lead']['fields']['practice_area_c']['dependency']='';
$dictionary['Lead']['fields']['practice_area_c']['visibility_grid']=array (
  'trigger' => 'sub_type_c',
  'values' => 
  array (
    'Corporate_Membership' => 
    array (
    ),
    'Educational' => 
    array (
    ),
    'MidMarket' => 
    array (
    ),
    'Council' => 
    array (
      0 => 'human_capital',
      1 => 'corporate_leadership',
      2 => 'economy_value',
    ),
    'Speaker' => 
    array (
    ),
    'Sponsor' => 
    array (
    ),
    'Conference' => 
    array (
    ),
    'Seminar' => 
    array (
    ),
    'Research_Working_Group' => 
    array (
    ),
    'Experiential' => 
    array (
    ),
  ),
);

 ?>