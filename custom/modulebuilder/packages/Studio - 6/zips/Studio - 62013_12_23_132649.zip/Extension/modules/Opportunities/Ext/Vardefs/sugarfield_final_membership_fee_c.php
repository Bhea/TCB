<?php
 // created: 2013-12-03 16:39:14
$dictionary['Opportunity']['fields']['final_membership_fee_c']['duplicate_merge_dom_value']=0;
$dictionary['Opportunity']['fields']['final_membership_fee_c']['labelValue']='Final Membership Fee';
$dictionary['Opportunity']['fields']['final_membership_fee_c']['calculated']='true';
$dictionary['Opportunity']['fields']['final_membership_fee_c']['formula']='subtract($membership_fee_c,$discount_c)';
$dictionary['Opportunity']['fields']['final_membership_fee_c']['enforced']='true';
$dictionary['Opportunity']['fields']['final_membership_fee_c']['dependency']='';

 ?>