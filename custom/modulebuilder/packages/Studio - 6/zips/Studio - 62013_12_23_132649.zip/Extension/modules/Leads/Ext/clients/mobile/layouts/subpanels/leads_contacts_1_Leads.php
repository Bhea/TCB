<?php
// created: 2013-12-03 14:54:02
$viewdefs['Leads']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_LEADS_CONTACTS_1_FROM_CONTACTS_TITLE',
  'context' => 
  array (
    'link' => 'leads_contacts_1',
  ),
);