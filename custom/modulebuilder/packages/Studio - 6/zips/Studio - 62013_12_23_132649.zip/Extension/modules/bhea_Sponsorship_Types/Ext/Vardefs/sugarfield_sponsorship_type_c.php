<?php
 // created: 2013-12-19 19:51:15
$dictionary['bhea_Sponsorship_Types']['fields']['sponsorship_type_c']['labelValue']='Sponsorship Type';
$dictionary['bhea_Sponsorship_Types']['fields']['sponsorship_type_c']['dependency']='';
$dictionary['bhea_Sponsorship_Types']['fields']['sponsorship_type_c']['visibility_grid']='';

 ?>