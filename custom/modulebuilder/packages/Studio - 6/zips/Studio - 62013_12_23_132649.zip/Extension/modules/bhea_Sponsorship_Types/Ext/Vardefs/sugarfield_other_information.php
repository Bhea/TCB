<?php
 // created: 2013-12-18 16:50:25
$dictionary['bhea_Sponsorship_Types']['fields']['other_information']['rows']='6';
$dictionary['bhea_Sponsorship_Types']['fields']['other_information']['cols']='50';

 ?>