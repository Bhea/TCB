<?php
 // created: 2013-12-03 16:29:54
$dictionary['bhea_Sponsorship_Types']['fields']['description']['comments']='Full text of the note';
$dictionary['bhea_Sponsorship_Types']['fields']['description']['merge_filter']='disabled';
$dictionary['bhea_Sponsorship_Types']['fields']['description']['full_text_search']=array (
  'boost' => '0',
);
$dictionary['bhea_Sponsorship_Types']['fields']['description']['calculated']=false;
$dictionary['bhea_Sponsorship_Types']['fields']['description']['cols']='50';

 ?>