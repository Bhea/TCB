<?php
 // created: 2013-12-13 10:54:44
$dictionary['Opportunity']['fields']['territory_id_c']['labelValue']='Territory ID';
$dictionary['Opportunity']['fields']['territory_id_c']['full_text_search']=array (
  'boost' => '0',
);
$dictionary['Opportunity']['fields']['territory_id_c']['enforced']='';
$dictionary['Opportunity']['fields']['territory_id_c']['dependency']='';

 ?>