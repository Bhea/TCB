<?php
 // created: 2013-12-03 10:15:22
$dictionary['Lead']['fields']['opportunity_date_c']['labelValue']='Opportunity Date';
$dictionary['Lead']['fields']['opportunity_date_c']['enforced']='';
$dictionary['Lead']['fields']['opportunity_date_c']['dependency']='';

 ?>