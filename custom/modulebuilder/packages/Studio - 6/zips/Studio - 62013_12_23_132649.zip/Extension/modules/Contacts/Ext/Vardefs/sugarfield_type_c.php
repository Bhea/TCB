<?php
 // created: 2013-12-20 10:53:19
$dictionary['Contact']['fields']['type_c']['labelValue']='Role';
$dictionary['Contact']['fields']['type_c']['dependency']='';
$dictionary['Contact']['fields']['type_c']['visibility_grid']='';

 ?>