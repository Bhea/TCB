<?php
 // created: 2013-12-18 15:53:03
$dictionary['Lead']['fields']['prod_serv_interest_c']['labelValue']='Opportunity Type';
$dictionary['Lead']['fields']['prod_serv_interest_c']['dependency']='';
$dictionary['Lead']['fields']['prod_serv_interest_c']['visibility_grid']='';

 ?>