<?php
 // created: 2013-12-03 20:17:43
$dictionary['Opportunity']['fields']['amount_usdollar']['comments']='Formatted amount of the opportunity';
$dictionary['Opportunity']['fields']['amount_usdollar']['duplicate_merge']='disabled';
$dictionary['Opportunity']['fields']['amount_usdollar']['duplicate_merge_dom_value']='0';
$dictionary['Opportunity']['fields']['amount_usdollar']['merge_filter']='disabled';
$dictionary['Opportunity']['fields']['amount_usdollar']['calculated']=false;
$dictionary['Opportunity']['fields']['amount_usdollar']['formula']='';
$dictionary['Opportunity']['fields']['amount_usdollar']['enforced']=false;
$dictionary['Opportunity']['fields']['amount_usdollar']['enable_range_search']=false;

 ?>