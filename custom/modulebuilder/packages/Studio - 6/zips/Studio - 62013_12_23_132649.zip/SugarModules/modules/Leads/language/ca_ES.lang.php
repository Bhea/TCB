<?php 
 // created: 2013-12-23 13:26:46
$mod_strings['LNK_NEW_SPEAKERS'] = 'Create Speakers';
$mod_strings['LNK_SELECT_BHEA_SPEAKERS'] = ' OR Select Speakers';
$mod_strings['LNK_NEW_PARTICIPANT'] = 'Create Participant';
$mod_strings['LNK_SELECT_BHEA_REGISTRANTS'] = ' OR Select Participant';
$mod_strings['LNK_NEW_SPONSOR'] = 'Create Sponsor';
$mod_strings['LNK_SELECT_BHEA_SPONSOR'] = ' OR Select Sponsor';
$mod_strings['LNK_NEW_CONTRACTORS'] = 'Create Contractors';
$mod_strings['LNK_SELECT_BHEA_CONTRACTORS'] = ' OR Select Contractors';
$mod_strings['LNK_NEW_MEMBERSHIP_LEVELS'] = 'Create Membership Levels';
$mod_strings['LNK_SELECT_BHEA_MEMBER_LEVELS'] = ' OR Select Membership Levels';

?>
