<?php
/*
*@File:Speakers.php.
*@Author:Prateek Kaushal @ Bhea Technologies.
*@Purpose:This file is used to create a record
* in the Speakers module by populating few
* values from the Opportunities.
*/

if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
class eventid{
	
	function eventid_method($bean,$event,$arguements){
		
		//global $db;
		$GLOBALS['log']->fatal($bean->id);
		$query = "SELECT event_id_c FROM bhea_events,bhea_events_cstm where deleted=0 order by name desc limit 0,1";
		$result = $db->query($query);
		$query = $bean->db->fetchByAssoc($result);
		
		//if($bean->event_type == "Conference"){	
		//$GLOBALS['log']->fatal("hi ID creation..event_type = Conference");		
		//}
	}
}
