<?php
 // created: 2013-12-16 17:41:18
$dictionary['Bhea_Event_Fee']['fields']['discount_c']['labelValue']='Discount in %';
$dictionary['Bhea_Event_Fee']['fields']['discount_c']['enforced']='';
$dictionary['Bhea_Event_Fee']['fields']['discount_c']['dependency']='';

 ?>