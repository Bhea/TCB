<?php
 // created: 2013-12-04 16:15:42
$layout_defs["Bhea_Memberships"]["subpanel_setup"]['bhea_memberships_bhea_payments_1'] = array (
  'order' => 100,
  'module' => 'Bhea_Payments',
  'subpanel_name' => 'default',
  'title_key' => 'LBL_BHEA_MEMBERSHIPS_BHEA_PAYMENTS_1_FROM_BHEA_PAYMENTS_TITLE',
  'get_subpanel_data' => 'bhea_memberships_bhea_payments_1',
);
