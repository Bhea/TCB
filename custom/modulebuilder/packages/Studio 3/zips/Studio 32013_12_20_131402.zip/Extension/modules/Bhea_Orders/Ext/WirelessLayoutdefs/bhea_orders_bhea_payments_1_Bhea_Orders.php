<?php
 // created: 2013-12-09 10:02:24
$layout_defs["Bhea_Orders"]["subpanel_setup"]['bhea_orders_bhea_payments_1'] = array (
  'order' => 100,
  'module' => 'Bhea_Payments',
  'subpanel_name' => 'default',
  'title_key' => 'LBL_BHEA_ORDERS_BHEA_PAYMENTS_1_FROM_BHEA_PAYMENTS_TITLE',
  'get_subpanel_data' => 'bhea_orders_bhea_payments_1',
);
