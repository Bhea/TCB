<?php
// created: 2013-12-09 10:02:24
$viewdefs['Bhea_Orders']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_BHEA_ORDERS_BHEA_PAYMENTS_1_FROM_BHEA_PAYMENTS_TITLE',
  'context' => 
  array (
    'link' => 'bhea_orders_bhea_payments_1',
  ),
);