<?php
//auto-generated file DO NOT EDIT
$viewdefs['Bhea_Memberships']['base']['layout']['subpanels']['components'][]['override_subpanel_list_view'] = array (
  'link' => 'bhea_memberships_bhea_payments_1',
  'view' => 'subpanel-for-bhea_memberships',
);
?>