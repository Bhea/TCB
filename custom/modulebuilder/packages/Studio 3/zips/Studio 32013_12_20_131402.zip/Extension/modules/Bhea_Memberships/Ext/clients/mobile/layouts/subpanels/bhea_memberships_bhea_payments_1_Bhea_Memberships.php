<?php
// created: 2013-12-04 16:15:42
$viewdefs['Bhea_Memberships']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_BHEA_MEMBERSHIPS_BHEA_PAYMENTS_1_FROM_BHEA_PAYMENTS_TITLE',
  'context' => 
  array (
    'link' => 'bhea_memberships_bhea_payments_1',
  ),
);