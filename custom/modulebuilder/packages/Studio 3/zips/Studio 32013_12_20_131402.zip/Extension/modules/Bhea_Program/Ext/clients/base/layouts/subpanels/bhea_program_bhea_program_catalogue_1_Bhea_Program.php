<?php
// created: 2013-12-03 14:13:31
$viewdefs['Bhea_Program']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_BHEA_PROGRAM_BHEA_PROGRAM_CATALOGUE_1_FROM_BHEA_PROGRAM_CATALOGUE_TITLE',
  'context' => 
  array (
    'link' => 'bhea_program_bhea_program_catalogue_1',
  ),
);