<?php
// created: 2013-12-04 16:15:42
$dictionary["Bhea_Memberships"]["fields"]["bhea_memberships_bhea_payments_1"] = array (
  'name' => 'bhea_memberships_bhea_payments_1',
  'type' => 'link',
  'relationship' => 'bhea_memberships_bhea_payments_1',
  'source' => 'non-db',
  'module' => 'Bhea_Payments',
  'bean_name' => 'Bhea_Payments',
  'vname' => 'LBL_BHEA_MEMBERSHIPS_BHEA_PAYMENTS_1_FROM_BHEA_MEMBERSHIPS_TITLE',
  'id_name' => 'bhea_memberships_bhea_payments_1bhea_memberships_ida',
  'link-type' => 'many',
  'side' => 'left',
);
