<?php 
 // created: 2013-12-20 13:14:01
$mod_strings['LNK_NEW_RECORD'] = 'Create Payment';
$mod_strings['LNK_LIST'] = 'View Payments';
$mod_strings['LBL_MODULE_NAME'] = 'Payments';
$mod_strings['LBL_MODULE_NAME_SINGULAR'] = 'Payments';
$mod_strings['LBL_NEW_FORM_TITLE'] = 'New Payments';
$mod_strings['LNK_IMPORT_VCARD'] = 'Import Payments vCard';
$mod_strings['LNK_IMPORT_BHEA_PAYMENTS'] = 'Import Payment';
$mod_strings['LBL_LIST_FORM_TITLE'] = 'Paymentss List';
$mod_strings['LBL_SEARCH_FORM_TITLE'] = 'Search Payments';
$mod_strings['LBL_HOMEPAGE_TITLE'] = 'My Paymentss';
$mod_strings['LBL_PAYMENT_DATE'] = 'Payment Date';

?>
