<?php
 // created: 2013-12-03 14:13:31
$layout_defs["Bhea_Program"]["subpanel_setup"]['bhea_program_bhea_program_catalogue_1'] = array (
  'order' => 100,
  'module' => 'Bhea_Program_Catalogue',
  'subpanel_name' => 'default',
  'title_key' => 'LBL_BHEA_PROGRAM_BHEA_PROGRAM_CATALOGUE_1_FROM_BHEA_PROGRAM_CATALOGUE_TITLE',
  'get_subpanel_data' => 'bhea_program_bhea_program_catalogue_1',
);
