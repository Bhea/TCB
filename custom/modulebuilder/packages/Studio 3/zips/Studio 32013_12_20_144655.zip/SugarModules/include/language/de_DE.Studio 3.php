<?php 
$app_list_strings['salutation_dom'] = array (
  '' => '',
  'Mr.' => 'Herr',
  'Ms.' => 'Frau',
  'Mrs.' => 'Frau',
  'Dr.' => 'Dr.',
  'Prof.' => 'Prof.',
  'Honourable' => 'Honourable',
);