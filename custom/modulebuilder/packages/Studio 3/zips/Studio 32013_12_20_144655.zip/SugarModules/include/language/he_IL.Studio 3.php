<?php 
$app_list_strings['salutation_dom'] = array (
  '' => '',
  'Mr.' => 'מר.',
  'Ms.' => 'עלמה.',
  'Mrs.' => 'גברת.',
  'Dr.' => 'ד"ר.',
  'Prof.' => 'פרופ.',
  'Honourable' => 'Honourable',
);