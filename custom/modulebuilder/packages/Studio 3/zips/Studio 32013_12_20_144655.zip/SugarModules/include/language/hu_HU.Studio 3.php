<?php 
$app_list_strings['salutation_dom'] = array (
  '' => '',
  'Mr.' => 'Úr',
  'Ms.' => 'Hölgy',
  'Mrs.' => 'Asszony',
  'Dr.' => 'Dr.',
  'Prof.' => 'Prof.',
  'Honourable' => 'Honourable',
);