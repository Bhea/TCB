<?php 
$app_list_strings['salutation_dom'] = array (
  '' => '',
  'Mr.' => 'Zr.',
  'Ms.' => 'Z-shë',
  'Mrs.' => 'Z-një',
  'Dr.' => 'Dr.',
  'Prof.' => 'Prof.',
  'Honourable' => 'Honourable',
);