<?php 
$app_list_strings['salutation_dom'] = array (
  '' => '',
  'Mr.' => 'Mr.',
  'Ms.' => 'Ms.',
  'Mrs.' => 'Mrs.',
  'Dr.' => 'Dr.',
  'Prof.' => 'Prof.',
  'Honourable' => 'Honourable',
);