<?php 
$app_list_strings['salutation_dom'] = array (
  '' => '',
  'Mr.' => 'Sr.',
  'Ms.' => 'M.na',
  'Mrs.' => 'Sra.',
  'Dr.' => 'Dr.',
  'Prof.' => 'Prof.',
  'Honourable' => 'Honourable',
);