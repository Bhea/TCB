<?php 
$app_list_strings['salutation_dom'] = array (
  '' => '',
  'Mr.' => '様',
  'Ms.' => 'Ms.',
  'Mrs.' => 'Mrs.',
  'Dr.' => '先生',
  'Prof.' => '教授',
  'Honourable' => 'Honourable',
);