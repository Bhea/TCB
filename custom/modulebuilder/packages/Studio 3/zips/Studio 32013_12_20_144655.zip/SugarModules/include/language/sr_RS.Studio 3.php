<?php 
$app_list_strings['salutation_dom'] = array (
  '' => '',
  'Mr.' => 'Gosp.',
  'Ms.' => 'Gđa.',
  'Mrs.' => 'Gđica.',
  'Dr.' => 'Dr.',
  'Prof.' => 'Prof.',
  'Honourable' => 'Honourable',
);