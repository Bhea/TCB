<?php 
$app_list_strings['salutation_dom'] = array (
  '' => '',
  'Mr.' => 'Hr.',
  'Ms.' => 'Fru',
  'Mrs.' => 'Frk.',
  'Dr.' => 'Mr.',
  'Prof.' => 'Prof.',
  'Honourable' => 'Honourable',
);