<?php 
$app_list_strings['salutation_dom'] = array (
  '' => '',
  'Mr.' => 'Г-н',
  'Ms.' => 'Г-ца.',
  'Mrs.' => 'Г-жа.',
  'Dr.' => 'Д-р.',
  'Prof.' => 'Проф.',
  'Honourable' => 'Honourable',
);