<?php 
$app_list_strings['salutation_dom'] = array (
  '' => '[-κενό-]',
  'Mr.' => 'Κύριος',
  'Ms.' => 'Κυρία',
  'Mrs.' => 'Δεσποινίς',
  'Dr.' => 'Δρ.',
  'Prof.' => 'Καθ.',
  'Honourable' => 'Honourable',
);