<?php 
$app_list_strings['salutation_dom'] = array (
  '' => '',
  'Mr.' => 'A. god.',
  'Ms.' => 'Ļ. cien.',
  'Mrs.' => 'Ļ. cien.',
  'Dr.' => 'Dr.',
  'Prof.' => 'Prof.',
  'Honourable' => 'Honourable',
);