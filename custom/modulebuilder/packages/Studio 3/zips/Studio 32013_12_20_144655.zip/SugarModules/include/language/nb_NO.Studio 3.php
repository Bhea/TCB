<?php 
$app_list_strings['salutation_dom'] = array (
  '' => '',
  'Mr.' => 'Hr.',
  'Ms.' => 'Fr.',
  'Mrs.' => 'Fru',
  'Dr.' => 'Dr.',
  'Prof.' => 'Prof.',
  'Honourable' => 'Honourable',
);