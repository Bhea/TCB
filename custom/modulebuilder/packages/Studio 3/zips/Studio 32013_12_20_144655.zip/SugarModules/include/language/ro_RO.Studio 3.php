<?php 
$app_list_strings['salutation_dom'] = array (
  '' => '',
  'Mr.' => 'Dl.',
  'Ms.' => 'Doamna',
  'Mrs.' => 'Doamna',
  'Dr.' => 'Doctor',
  'Prof.' => 'Profesor',
  'Honourable' => 'Honourable',
);