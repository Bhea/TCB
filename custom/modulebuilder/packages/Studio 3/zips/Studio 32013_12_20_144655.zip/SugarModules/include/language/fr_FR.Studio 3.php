<?php 
$app_list_strings['salutation_dom'] = array (
  '' => '',
  'Mr.' => 'M.',
  'Ms.' => 'Mlle',
  'Mrs.' => 'Mme',
  'Dr.' => 'Dr.',
  'Prof.' => 'Prof.',
  'Honourable' => 'Honourable',
);