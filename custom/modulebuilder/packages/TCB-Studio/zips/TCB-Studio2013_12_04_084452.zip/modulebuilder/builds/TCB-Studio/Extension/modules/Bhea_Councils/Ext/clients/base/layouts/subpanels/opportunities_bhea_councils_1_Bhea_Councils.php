<?php
// created: 2013-12-03 11:19:05
$viewdefs['Bhea_Councils']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_OPPORTUNITIES_BHEA_COUNCILS_1_FROM_OPPORTUNITIES_TITLE',
  'context' => 
  array (
    'link' => 'opportunities_bhea_councils_1',
  ),
);