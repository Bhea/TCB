<?php
 // created: 2013-12-20 10:48:26
$layout_defs["Bhea_Sessions"]["subpanel_setup"]['bhea_sessions_bhea_sponsorship_1'] = array (
  'order' => 100,
  'module' => 'Bhea_Sponsorship',
  'subpanel_name' => 'default',
  'title_key' => 'LBL_BHEA_SESSIONS_BHEA_SPONSORSHIP_1_FROM_BHEA_SPONSORSHIP_TITLE',
  'get_subpanel_data' => 'bhea_sessions_bhea_sponsorship_1',
);
