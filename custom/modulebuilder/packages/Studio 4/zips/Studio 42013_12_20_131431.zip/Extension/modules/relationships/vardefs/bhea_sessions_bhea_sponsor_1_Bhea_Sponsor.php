<?php
// created: 2013-12-20 10:46:46
$dictionary["Bhea_Sponsor"]["fields"]["bhea_sessions_bhea_sponsor_1"] = array (
  'name' => 'bhea_sessions_bhea_sponsor_1',
  'type' => 'link',
  'relationship' => 'bhea_sessions_bhea_sponsor_1',
  'source' => 'non-db',
  'module' => 'Bhea_Sessions',
  'bean_name' => 'Bhea_Sessions',
  'vname' => 'LBL_BHEA_SESSIONS_BHEA_SPONSOR_1_FROM_BHEA_SESSIONS_TITLE',
  'id_name' => 'bhea_sessions_bhea_sponsor_1bhea_sessions_ida',
);
