<?php
 // created: 2013-12-04 10:19:01
$layout_defs["Bhea_Sponsor"]["subpanel_setup"]['bhea_sponsor_bhea_sessions_1'] = array (
  'order' => 100,
  'module' => 'Bhea_Sessions',
  'subpanel_name' => 'default',
  'title_key' => 'LBL_BHEA_SPONSOR_BHEA_SESSIONS_1_FROM_BHEA_SESSIONS_TITLE',
  'get_subpanel_data' => 'bhea_sponsor_bhea_sessions_1',
);
