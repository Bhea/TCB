<?php
// created: 2013-12-04 10:16:05
$dictionary["Bhea_Sessions"]["fields"]["bhea_sessions_bhea_speakers_1"] = array (
  'name' => 'bhea_sessions_bhea_speakers_1',
  'type' => 'link',
  'relationship' => 'bhea_sessions_bhea_speakers_1',
  'source' => 'non-db',
  'module' => 'Bhea_Speakers',
  'bean_name' => 'Bhea_Speakers',
  'vname' => 'LBL_BHEA_SESSIONS_BHEA_SPEAKERS_1_FROM_BHEA_SESSIONS_TITLE',
  'id_name' => 'bhea_sessions_bhea_speakers_1bhea_sessions_ida',
  'link-type' => 'many',
  'side' => 'left',
);
