<?php
// created: 2013-12-20 10:46:46
$viewdefs['Bhea_Sponsor']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_BHEA_SESSIONS_BHEA_SPONSOR_1_FROM_BHEA_SESSIONS_TITLE',
  'context' => 
  array (
    'link' => 'bhea_sessions_bhea_sponsor_1',
  ),
);