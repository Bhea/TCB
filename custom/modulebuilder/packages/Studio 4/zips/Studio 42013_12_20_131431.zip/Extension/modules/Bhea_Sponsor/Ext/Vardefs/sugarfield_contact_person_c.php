<?php
 // created: 2013-12-12 15:21:09
$dictionary['Bhea_Sponsor']['fields']['contact_person_c']['labelValue']='Contact Person';
$dictionary['Bhea_Sponsor']['fields']['contact_person_c']['dependency']='';

 ?>