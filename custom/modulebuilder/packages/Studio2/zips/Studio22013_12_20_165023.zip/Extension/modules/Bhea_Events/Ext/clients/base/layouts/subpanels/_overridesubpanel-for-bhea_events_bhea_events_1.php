<?php
//auto-generated file DO NOT EDIT
$viewdefs['Bhea_Events']['base']['layout']['subpanels']['components'][]['override_subpanel_list_view'] = array (
  'link' => 'bhea_events_bhea_events_1',
  'view' => 'subpanel-for-bhea_events',
);
?>