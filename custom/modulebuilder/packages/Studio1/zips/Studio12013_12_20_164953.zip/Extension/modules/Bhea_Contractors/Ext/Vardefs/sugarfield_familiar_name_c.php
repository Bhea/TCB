<?php
 // created: 2013-12-03 10:01:21
$dictionary['Bhea_Contractors']['fields']['familiar_name_c']['labelValue']='Familiar Name';
$dictionary['Bhea_Contractors']['fields']['familiar_name_c']['full_text_search']=array (
  'boost' => '0',
);
$dictionary['Bhea_Contractors']['fields']['familiar_name_c']['enforced']='';
$dictionary['Bhea_Contractors']['fields']['familiar_name_c']['dependency']='';

 ?>