<?php
 // created: 2013-12-03 09:17:48
$dictionary['Account']['fields']['forbes_rating_c']['labelValue']='Forbes Rating';
$dictionary['Account']['fields']['forbes_rating_c']['full_text_search']=array (
  'boost' => '0',
);
$dictionary['Account']['fields']['forbes_rating_c']['enforced']='';
$dictionary['Account']['fields']['forbes_rating_c']['dependency']='';

 ?>