<?php
 // created: 2013-12-13 10:45:45
$dictionary['Account']['fields']['classification_c']['labelValue']='Classification';
$dictionary['Account']['fields']['classification_c']['dependency']='';
$dictionary['Account']['fields']['classification_c']['visibility_grid']='';

 ?>