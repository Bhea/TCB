<?php
// created: 2013-12-04 09:42:14
$dictionary["Account"]["fields"]["accounts_bhea_council_members_1"] = array (
  'name' => 'accounts_bhea_council_members_1',
  'type' => 'link',
  'relationship' => 'accounts_bhea_council_members_1',
  'source' => 'non-db',
  'module' => 'Bhea_Council_Members',
  'bean_name' => 'Bhea_Council_Members',
  'vname' => 'LBL_ACCOUNTS_BHEA_COUNCIL_MEMBERS_1_FROM_ACCOUNTS_TITLE',
  'id_name' => 'accounts_bhea_council_members_1accounts_ida',
  'link-type' => 'many',
  'side' => 'left',
);
