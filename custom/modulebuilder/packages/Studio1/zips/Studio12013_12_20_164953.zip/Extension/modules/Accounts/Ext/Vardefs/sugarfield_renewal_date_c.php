<?php
 // created: 2013-12-04 15:00:10
$dictionary['Account']['fields']['renewal_date_c']['labelValue']='Renewal Date';
$dictionary['Account']['fields']['renewal_date_c']['enforced']='';
$dictionary['Account']['fields']['renewal_date_c']['dependency']='or(equal($account_type,"member"),equal($account_type,"past_member"))';

 ?>