<?php
 // created: 2013-12-03 09:05:42
$dictionary['Account']['fields']['legal_status_c']['labelValue']='Company Legal Status';
$dictionary['Account']['fields']['legal_status_c']['dependency']='';
$dictionary['Account']['fields']['legal_status_c']['visibility_grid']='';

 ?>