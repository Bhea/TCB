<?php
// created: 2013-12-20 11:10:57
$viewdefs['Bhea_Contractors']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_BHEA_SESSIONS_BHEA_CONTRACTORS_1_FROM_BHEA_SESSIONS_TITLE',
  'context' => 
  array (
    'link' => 'bhea_sessions_bhea_contractors_1',
  ),
);