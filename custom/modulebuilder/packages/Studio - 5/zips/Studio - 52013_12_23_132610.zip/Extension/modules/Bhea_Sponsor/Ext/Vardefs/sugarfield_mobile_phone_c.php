<?php
 // created: 2013-12-12 15:18:31
$dictionary['Bhea_Sponsor']['fields']['mobile_phone_c']['labelValue']='Mobile Phone';
$dictionary['Bhea_Sponsor']['fields']['mobile_phone_c']['full_text_search']=array (
  'boost' => '0',
);
$dictionary['Bhea_Sponsor']['fields']['mobile_phone_c']['enforced']='';
$dictionary['Bhea_Sponsor']['fields']['mobile_phone_c']['dependency']='';

 ?>