<?php
// created: 2013-12-04 12:42:53
$viewdefs['Bhea_Sponsor']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_BHEA_SPONSOR_BHEA_SPONSORSHIP_1_FROM_BHEA_SPONSORSHIP_TITLE',
  'context' => 
  array (
    'link' => 'bhea_sponsor_bhea_sponsorship_1',
  ),
);