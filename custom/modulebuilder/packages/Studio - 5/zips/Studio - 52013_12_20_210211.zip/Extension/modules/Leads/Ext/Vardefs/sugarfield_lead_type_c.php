<?php
 // created: 2013-12-18 16:03:25
$dictionary['Lead']['fields']['lead_type_c']['labelValue']='Lead Type';
$dictionary['Lead']['fields']['lead_type_c']['dependency']='';
$dictionary['Lead']['fields']['lead_type_c']['visibility_grid']=array (
  'trigger' => 'sub_type_c',
  'values' => 
  array (
    '' => 
    array (
    ),
    'Corporate_Membership' => 
    array (
    ),
    'Educational' => 
    array (
    ),
    'MidMarket' => 
    array (
    ),
    'Government' => 
    array (
    ),
    'Conference' => 
    array (
      0 => 'Member_Sponsor',
      1 => 'Non_Member_Sponsor',
      2 => 'Member_Speaker',
      3 => 'Non_Member_Speaker',
      4 => 'Member_Contractor',
      5 => 'Non_Member_Contractor',
      6 => 'Member_Participant',
      7 => 'Non_Member_Participant',
      8 => 'Sponsor_Speaker',
    ),
    'Seminar' => 
    array (
    ),
    'Research_Working_Group' => 
    array (
    ),
    'Experiential' => 
    array (
    ),
    'new_mem' => 
    array (
    ),
    'renewal' => 
    array (
    ),
    'mem_upgrade' => 
    array (
    ),
    'conference' => 
    array (
      0 => 'Member_Contractor',
      1 => 'Member_Participant',
      2 => 'Member_Speaker',
      3 => 'Member_Sponsor',
      4 => 'Non_Member_Contractor',
      5 => 'Non_Member_Participant',
      6 => 'Non_Member_Speaker',
      7 => 'Sponsor_Speaker',
      8 => 'Non_Member_Sponsor',
    ),
    'seminar' => 
    array (
    ),
    'research_working' => 
    array (
    ),
    'experiential_learning' => 
    array (
    ),
  ),
);

 ?>