<?php
 // created: 2013-12-16 12:17:38
$dictionary['Opportunity']['fields']['membership_fee_c']['labelValue']='Membership Fee';
$dictionary['Opportunity']['fields']['membership_fee_c']['enforced']='';

 ?>