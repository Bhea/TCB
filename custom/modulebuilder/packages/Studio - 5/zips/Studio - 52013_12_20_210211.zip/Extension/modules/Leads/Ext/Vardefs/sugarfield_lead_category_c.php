<?php
 // created: 2013-12-20 10:16:56
$dictionary['Lead']['fields']['lead_category_c']['labelValue']='Lead Category';
$dictionary['Lead']['fields']['lead_category_c']['dependency']='';
$dictionary['Lead']['fields']['lead_category_c']['visibility_grid']='';

 ?>