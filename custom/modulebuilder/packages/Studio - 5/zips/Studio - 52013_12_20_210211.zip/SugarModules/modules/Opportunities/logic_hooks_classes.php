<?php


if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
class logic_hooks_classes
{
	function after_save_method($bean,$event,$arguements)
	{

	}		
}
