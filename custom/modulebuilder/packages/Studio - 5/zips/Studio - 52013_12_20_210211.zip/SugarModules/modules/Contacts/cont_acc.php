<?php
class cont_acc
{
	function cont_acc($bean,$event,$arguments)
	{
		$GLOBALS['log']->fatal("hiiiiiiiiiiiii");
		
	}
}
?>
