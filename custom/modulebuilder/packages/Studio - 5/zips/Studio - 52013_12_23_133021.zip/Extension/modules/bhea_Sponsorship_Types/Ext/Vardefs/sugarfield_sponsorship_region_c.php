<?php
 // created: 2013-12-18 17:04:42
$dictionary['bhea_Sponsorship_Types']['fields']['sponsorship_region_c']['labelValue']='Sponsorship Region';
$dictionary['bhea_Sponsorship_Types']['fields']['sponsorship_region_c']['dependency']='';
$dictionary['bhea_Sponsorship_Types']['fields']['sponsorship_region_c']['visibility_grid']='';

 ?>