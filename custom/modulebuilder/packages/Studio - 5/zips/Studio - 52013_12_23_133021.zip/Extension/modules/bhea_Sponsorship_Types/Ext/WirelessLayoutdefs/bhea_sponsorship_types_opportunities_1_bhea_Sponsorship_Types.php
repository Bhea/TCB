<?php
 // created: 2013-12-19 18:30:01
$layout_defs["bhea_Sponsorship_Types"]["subpanel_setup"]['bhea_sponsorship_types_opportunities_1'] = array (
  'order' => 100,
  'module' => 'Opportunities',
  'subpanel_name' => 'default',
  'title_key' => 'LBL_BHEA_SPONSORSHIP_TYPES_OPPORTUNITIES_1_FROM_OPPORTUNITIES_TITLE',
  'get_subpanel_data' => 'bhea_sponsorship_types_opportunities_1',
);
