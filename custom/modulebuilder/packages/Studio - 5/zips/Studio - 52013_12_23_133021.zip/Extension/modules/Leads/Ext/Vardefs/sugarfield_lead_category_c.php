<?php
 // created: 2013-12-21 10:34:56
$dictionary['Lead']['fields']['lead_category_c']['labelValue']='Lead Category';
$dictionary['Lead']['fields']['lead_category_c']['dependency']='';
$dictionary['Lead']['fields']['lead_category_c']['visibility_grid']='';

 ?>