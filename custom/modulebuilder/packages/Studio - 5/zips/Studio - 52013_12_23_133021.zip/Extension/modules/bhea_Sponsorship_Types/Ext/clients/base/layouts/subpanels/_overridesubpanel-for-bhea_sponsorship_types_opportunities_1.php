<?php
//auto-generated file DO NOT EDIT
$viewdefs['bhea_Sponsorship_Types']['base']['layout']['subpanels']['components'][]['override_subpanel_list_view'] = array (
  'link' => 'bhea_sponsorship_types_opportunities_1',
  'view' => 'subpanel-for-bhea_sponsorship_types',
);
?>