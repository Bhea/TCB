<?php
/*
*@File:Speakers.php.
*@Author:Prateek Kaushal @ Bhea Technologies.
*@Purpose:This file is used to create a record
* in the Sponsors module by populating few
* values from the Opportunities.
*/

if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
class sponsors_record
{
		function sponsors_record_method($bean,$event,$arguments)
		{
			global $db;
			/**
			* Upon Type->Products & Services, Subtype->Conference, Conferences subtype->Sponsors, Sales Stage->Closed Won
			*/
			if($bean->opportunity_type == "prod_service" && $bean->subtype_c == "conference" && $bean->conference_sub_type_c == "Sponsors" && $bean->sales_stage == "Closed Won")
			{
				/**
				 * To retrieve the Accounts details
				 */
				$account = BeanFactory::getBean('Accounts',$bean->account_id);
				
				/**
				 * To retrieve the Contacts details
				 */
				$contact = BeanFactory::getBean('Contacts',$bean->contact_id_c);
						
				/**
				 * Create a record in Sponsors module
				 */
				$sponsorBean = BeanFactory::newBean('Bhea_Sponsor');
				
				$sponsorBean->name 								= $account->name;
				$sponsorBean->contact_id_c						= $contact->id;
				$sponsorBean->office_phone_c 					= $contact->phone_work;
				$sponsorBean->mobile_phone_c 					= $contact->phone_mobile;
				$sponsorBean->company_address_street_c 			= $account->billing_address_street;
				$sponsorBean->company_address_city_c 			= $account->billing_address_city;
				$sponsorBean->company_address_state_c			= $account->billing_address_state;
				$sponsorBean->company_address_country_c 		= $account->billing_address_country;
				$sponsorBean->company_address_postalcode_c 		= $account->billing_address_postalcode;	
				$sponsorBean->description						= $account->description;	
				$sponsorBean->save();
		
		
				/**
				 * Create a record in Bhea_Sponsorship module
				 */
				
				$sponsorshipBean = BeanFactory::newBean('Bhea_Sponsorship');
				$sponsorshipBean->name = "Sponsorship for ".$account->name;
				$sponsorshipBean->save();
				
				
				/*Creating relationship between Events and Sponsors.
				 * */
				$event_id	 		= $bean->bhea_events_opportunities_1bhea_events_ida;
				$eventBean 			= BeanFactory::getBean('Bhea_Events',$event_id);
				//$GLOBALS['log']->fatal($eventBean->name);
			
				$eventBean->load_relationship('bhea_events_bhea_sponsor_1');
				$eventBean->bhea_events_bhea_sponsor_1->add($sponsorBean->id);	
				
				/*Creating relationship between Sponsorship_Types and Sponsorship.
				 * */
				$sponsorship_type_id	 		= $bean->bhea_sponsorship_types_opportunities_1bhea_sponsorship_types_ida;
				$sponsorship_type 				= BeanFactory::getBean('bhea_Sponsorship_Types',$sponsorship_type_id);
				
				$sponsorship_type->load_relationship('bhea_sponsorship_types_bhea_sponsorship_1');
				$sponsorship_type->bhea_sponsorship_types_bhea_sponsorship_1->add($sponsorshipBean->id);
				
				/*Creating relationship between Events and Sponsorship.
				 * */
				$eventBean->load_relationship('bhea_events_bhea_sponsorship_1');
				$eventBean->bhea_events_bhea_sponsorship_1->add($sponsorshipBean->id);
				
				/*Creating relationship between Sponsor and Sponsorship.
				 * */
				$sponsorBean->load_relationship('bhea_sponsor_bhea_sponsorship_1');
				$sponsorBean->bhea_sponsor_bhea_sponsorship_1->add($sponsorshipBean->id);	
				
				/*Fetching the Sessions ids from the subpannel.
				* */
				 $sql   =    'SELECT opportunities_bhea_sessions_1bhea_sessions_idb FROM opportunities_bhea_sessions_1_c WHERE opportunities_bhea_sessions_1opportunities_ida ="'.$bean->id.'" AND deleted=0 ';
				 $result = $db->query($sql);
				 while ($sessionid = $db->fetchByAssoc($result)) {
					
					$sponsorshipBean->load_relationship('bhea_sessions_bhea_sponsorship_1');
					$sponsorshipBean->bhea_sessions_bhea_sponsorship_1->add($sessionid);
				
				}
				
			}
		}
}
