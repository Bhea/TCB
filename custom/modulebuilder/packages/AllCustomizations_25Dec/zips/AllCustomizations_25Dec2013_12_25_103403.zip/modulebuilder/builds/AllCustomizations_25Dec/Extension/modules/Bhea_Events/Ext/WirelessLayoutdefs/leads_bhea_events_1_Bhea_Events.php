<?php
 // created: 2013-12-03 15:33:08
$layout_defs["Bhea_Events"]["subpanel_setup"]['leads_bhea_events_1'] = array (
  'order' => 100,
  'module' => 'Leads',
  'subpanel_name' => 'default',
  'title_key' => 'LBL_LEADS_BHEA_EVENTS_1_FROM_LEADS_TITLE',
  'get_subpanel_data' => 'leads_bhea_events_1',
);
