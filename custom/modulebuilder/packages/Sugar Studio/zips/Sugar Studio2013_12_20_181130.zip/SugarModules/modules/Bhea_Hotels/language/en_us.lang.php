<?php 
 // created: 2013-12-20 18:11:28
$mod_strings['LBL_BHEA_HOTELS_BHEA_EVENTS_1_FROM_BHEA_EVENTS_TITLE'] = 'Events';

?>
