<?php 
 // created: 2013-12-20 18:11:28
$mod_strings['LBL_BHEA_INVOICES_BHEA_PAYMENTS_1_FROM_BHEA_PAYMENTS_TITLE'] = 'Payments';

?>
