<?php 
$app_list_strings['mem_type_0'] = array (
  'new' => 'New',
  '' => '',
  'Upgrade' => 'Upgrade',
  'Renewal' => 'Renewal',
);