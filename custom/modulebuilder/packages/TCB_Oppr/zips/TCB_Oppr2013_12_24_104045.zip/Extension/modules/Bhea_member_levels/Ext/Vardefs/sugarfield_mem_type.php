<?php
 // created: 2013-12-17 15:00:08
$dictionary['Bhea_member_levels']['fields']['mem_type']['default']='Enterprise';

 ?>