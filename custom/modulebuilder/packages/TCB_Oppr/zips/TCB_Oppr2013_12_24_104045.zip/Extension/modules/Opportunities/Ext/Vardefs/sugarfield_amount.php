<?php
 // created: 2013-12-20 11:23:10
$dictionary['Opportunity']['fields']['amount']['comments']='Unconverted amount of the opportunity';
$dictionary['Opportunity']['fields']['amount']['importable']='false';
$dictionary['Opportunity']['fields']['amount']['duplicate_merge']='disabled';
$dictionary['Opportunity']['fields']['amount']['duplicate_merge_dom_value']=0;
$dictionary['Opportunity']['fields']['amount']['merge_filter']='disabled';
$dictionary['Opportunity']['fields']['amount']['calculated']='true';
$dictionary['Opportunity']['fields']['amount']['formula']='$final_membership_fee_c';
$dictionary['Opportunity']['fields']['amount']['enforced']=true;

 ?>