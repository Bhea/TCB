<?php 
 // created: 2013-12-24 10:40:43
$mod_strings['LBL_BHEA_MEMBER_LEVELS_BHEA_MEMBERSHIPS_1_FROM_BHEA_MEMBERSHIPS_TITLE'] = 'Memberships';
$mod_strings['LBL_BHEA_MEMBER_LEVELS_BHEA_COUNCIL_MEMBERSHIPS_1_FROM_BHEA_COUNCIL_MEMBERSHIPS_TITLE'] = 'Council Memberships';
$mod_strings['LBL_BHEA_MEMBER_LEVELS_OPPORTUNITIES_1_FROM_OPPORTUNITIES_TITLE'] = 'Opportunities';
$mod_strings['LBL_MEM_TYPE'] = 'Membership Category';
$mod_strings['LBL_CAT_TYPE'] = 'Access Level';
$mod_strings['LBL_MEMBERSHIP_TYPE'] = 'Membership Type';
$mod_strings['LBL_GEOGRAPHY'] = 'Region';
$mod_strings['LBL_COST'] = 'Membership Fee';
$mod_strings['LBL_MEM_PERIOD'] = 'Membership Period (Yrs)';
$mod_strings['LBL_MEMBERSHIP_SUB_CATEGORY'] = 'Membership Sub Category';
$mod_strings['LBL_PRACTICE_AREA'] = 'Practice Area';
$mod_strings['LBL_BHEA_MEMBER_LEVELS_BHEA_COUNCILS_1_FROM_BHEA_COUNCILS_TITLE'] = 'Groups';
$mod_strings['LBL_BHEA_MEMBER_LEVELS_BHEA_PRICING_LINE_ITEM_1_FROM_BHEA_PRICING_LINE_ITEM_TITLE'] = 'Pricing Line Items';
$mod_strings['LBL_BHEA_PRICING_LINE_ITEM_BHEA_MEMBER_LEVELS_1_FROM_BHEA_PRICING_LINE_ITEM_TITLE'] = 'Pricing Line Items';

?>
