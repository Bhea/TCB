<?php
/*
*@File:Speakers.php.
*@Author:Prateek Kaushal @ Bhea Technologies.
*@Purpose:This file is used to creating the relationship.
*/

if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
class after_relationship_class
{
	function after_relationship_method($bean,$event,$arguments)
	{
		/*Fetching the Sponsor id from the layout.
		* */
		$sponsor_id	 		= $bean->opportunities_bhea_sponsor_1bhea_sponsor_idb;
		$sponsorBean 		= BeanFactory::getBean('Bhea_Sponsor',$sponsor_id);
		
		/*Fetching the Sessions ids from the subpannel.
		* */
		$sessionBean = BeanFactory::getBean('Bhea_Sessions',$arguments['related_id']);
		
		
		$sessionBean->load_relationship('bhea_sessions_bhea_sponsor_1');
		$sessionBean->bhea_sessions_bhea_sponsor_1->add($sponsorBean->id);
		
	}
}
