<?php
/*
*@File:Speakers.php.
*@Author:Prateek Kaushal @ Bhea Technologies.
*@Purpose:This file is used to create a record
* in the Speakers module by populating few
* values from the Opportunities.
*/

if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
class speakers_record
{
		function speakers_record_method($bean,$event,$arguements)
		{
			/**
			* Upon Type->Products & Services, Subtype->Conference, Conferences subtype->Speakers, Sales Stage->Closed Won
			*/
			if($bean->opportunity_type == "prod_service" && $bean->subtype_c == "conference" && $bean->conference_sub_type_c == "Speakers" && $bean->sales_stage == "Closed Won")
			{
				/**
				 * To retrieve the Accounts details
				 */				
				$account = BeanFactory::getBean('Accounts',$bean->account_id);
				
				
				/**
				 * To retrieve the Contacts details
				 */
				$contact = BeanFactory::getBean('Contacts',$bean->contact_id_c);
				
					
				/**
				 * Create a record in Speakers module
				 */
			
				$obj = BeanFactory::newBean('Bhea_Speakers');
				
				$obj->salutation 						= $contact->salutation;
				$obj->first_name 						= $contact->first_name;
				$obj->last_name 						= $contact->last_name;
				$obj->familiar_name_c 					= $contact->familiar_name_c;
				$obj->title 							= $contact->title;
				$obj->department 						= $contact->department;
				$obj->phone_work 						= $contact->phone_work;
				$obj->phone_mobile 						= $contact->phone_mobile;
				$obj->company_name 						= $account->name;
				$obj->company_address 					= $account->billing_address_street;
				$obj->company_address_city 				= $account->billing_address_city;
				$obj->company_address_state 			= $account->billing_address_state;
				$obj->company_address_country 			= $account->billing_address_country;
				$obj->company_address_postalcode 		= $account->billing_address_postalcode;					
				$obj->save();
				
				/*Creating relationship between Events and Speakers.
				 * */
				$event_id	 		= $bean->bhea_events_opportunities_1bhea_events_ida;
				$event 				= BeanFactory::getBean('Bhea_Events',$event_id);
				
				$event->load_relationship('bhea_events_bhea_speakers_1');
				$event->bhea_events_bhea_speakers_1->add($obj->id);
				
				//~ /*Creating relationship between Sessions and Speakers.
				 //~ * */
				//~ $sessions_id	 		= $bean->bhea_sessions_opportunities_1bhea_sessions_ida;
				//~ $session_bean			= BeanFactory::getBean('Bhea_Sessions',$sessions_id);
				//~ 
				//~ $session_bean->load_relationship('bhea_sessions_bhea_speakers_1');
				//~ $session_bean->bhea_sessions_bhea_speakers_1->add($obj->id);
			}
		}
}
