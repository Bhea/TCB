<?php 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/bhea_events_campaigns_1MetaData.php');

?>