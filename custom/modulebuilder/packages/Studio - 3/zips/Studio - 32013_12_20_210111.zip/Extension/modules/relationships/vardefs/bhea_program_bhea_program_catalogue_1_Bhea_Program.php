<?php
// created: 2013-12-03 14:13:31
$dictionary["Bhea_Program"]["fields"]["bhea_program_bhea_program_catalogue_1"] = array (
  'name' => 'bhea_program_bhea_program_catalogue_1',
  'type' => 'link',
  'relationship' => 'bhea_program_bhea_program_catalogue_1',
  'source' => 'non-db',
  'module' => 'Bhea_Program_Catalogue',
  'bean_name' => 'Bhea_Program_Catalogue',
  'vname' => 'LBL_BHEA_PROGRAM_BHEA_PROGRAM_CATALOGUE_1_FROM_BHEA_PROGRAM_TITLE',
  'id_name' => 'bhea_program_bhea_program_catalogue_1bhea_program_ida',
  'link-type' => 'many',
  'side' => 'left',
);
