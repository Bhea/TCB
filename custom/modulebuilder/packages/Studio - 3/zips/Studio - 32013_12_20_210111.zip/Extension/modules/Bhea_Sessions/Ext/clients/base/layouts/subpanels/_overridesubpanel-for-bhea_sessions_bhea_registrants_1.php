<?php
//auto-generated file DO NOT EDIT
$viewdefs['Bhea_Sessions']['base']['layout']['subpanels']['components'][]['override_subpanel_list_view'] = array (
  'link' => 'bhea_sessions_bhea_registrants_1',
  'view' => 'subpanel-for-bhea_sessions',
);
?>