<?php 
$app_list_strings['salutation_dom'] = array (
  '' => '',
  'Mr.' => 'Dl.',
  'Ms.' => 'Doamna',
  'Mrs.' => 'Doamna',
  'Dr.' => 'Doctor',
  'Prof.' => 'Profesor',
  'Honourable' => 'Honourable',
);$app_list_strings['sessions_status'] = array (
  '' => '',
  'Planned' => 'Planned',
  'Held' => 'Held',
  'Cancelled' => 'Cancelled',
  'Preponed' => 'Preponed',
  'Postponed' => 'Postponed',
);