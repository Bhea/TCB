<?php 
 // created: 2013-12-23 13:25:07
$mod_strings['LBL_FAMILIAR_NAME'] = 'Familiar Name';
$mod_strings['LBL_COMPANY_NAME'] = 'Company Name';
$mod_strings['LBL_COMPANY_ADDRESS_STREET'] = 'Company Address Street';
$mod_strings['LBL_COMPANY_ADDRESS_CITY'] = 'Company Address City';
$mod_strings['LBL_COMPANY_ADDRESS_STATE'] = 'Company Address State';
$mod_strings['LBL_COMPANY_ADDRESS_POSTALCODE'] = 'Company Address PostalCode';
$mod_strings['LBL_COMPANY_ADDRESS_COUNTRY'] = 'Company Address Country';
$mod_strings['LBL_COMPANY_ADDRESS'] = 'Company Address';
$mod_strings['LBL_ACCOUNT'] = 'Account not';
$mod_strings['LBL_CONTACT '] = 'Contact not';
$mod_strings['LNK_NEW_RECORD'] = 'Create Participants';
$mod_strings['LNK_LIST'] = 'View Participants';
$mod_strings['LBL_MODULE_NAME'] = 'Participants';
$mod_strings['LBL_MODULE_NAME_SINGULAR'] = 'Participant';
$mod_strings['LBL_NEW_FORM_TITLE'] = 'New Participant';
$mod_strings['LNK_IMPORT_VCARD'] = 'Import Participant vCard';
$mod_strings['LNK_IMPORT_BHEA_REGISTRANTS'] = 'Import Participants';
$mod_strings['LBL_LIST_FORM_TITLE'] = 'Participant List';
$mod_strings['LBL_SEARCH_FORM_TITLE'] = 'Search Participant';
$mod_strings['LBL_HOMEPAGE_TITLE'] = 'My Participants';

?>
