<?php 
 // created: 2013-12-23 13:25:07
$mod_strings['LBL_FROM_REVENUE'] = 'From Revenue(M)';
$mod_strings['LBL_TO_REVENUE'] = 'To Revenue(M)';
$mod_strings['LBL_MODULE_NAME'] = 'Pricing Line Items';
$mod_strings['LBL_MODULE_NAME_SINGULAR'] = 'Pricing Line Item';
$mod_strings['LBL_MODULE_TITLE'] = 'Pricing Line Items';
$mod_strings['LBL_NEW_FORM_TITLE'] = 'New Pricing Line Item';
$mod_strings['LBL_SEARCH_FORM_TITLE'] = 'Search Pricing Line Item';
$mod_strings['LBL__PRICING_LINE_ITEM_SUBPANEL_TITLE'] = 'Pricing Line Items';
$mod_strings['LNK_IMPORT_BHEA_PRICING_LINE_ITEM'] = 'Import Pricing Line Item';
$mod_strings['LNK_IMPORT_VCARD'] = 'Import Pricing Line Item vCard';
$mod_strings['LNK_IMPORT__PRICING_LINE_ITEM'] = 'Import Pricing Line Item';
$mod_strings['LNK_LIST'] = 'View Pricing Line Items';
$mod_strings['LNK_NEW_RECORD'] = 'Create Pricing Line Item';
$mod_strings['LBL_BHEA_PRICING_LINE_ITEM_SUBPANEL_TITLE'] = 'Pricing Line Items';
$mod_strings['LBL_HOMEPAGE_TITLE'] = 'My Pricing Line Items';
$mod_strings['LBL_IMPORT'] = 'Import Pricing Line Items';
$mod_strings['LBL_IMPORT_VCARDTEXT'] = 'Automatically create a new Pricing Line Item record by importing a vCard from your file system.';
$mod_strings['LBL_LIST_FORM_TITLE'] = 'Pricing Line Items List';
$mod_strings['LBL_MEMBERSHIP_PRICE'] = 'Membership Fee';

?>
