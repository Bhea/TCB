<?php
 // created: 2013-12-19 16:45:19
$dictionary['Bhea_Pricing_Line_Item']['fields']['to_revenue_c']['labelValue']='To Revenue(M)';
$dictionary['Bhea_Pricing_Line_Item']['fields']['to_revenue_c']['enforced']='';
$dictionary['Bhea_Pricing_Line_Item']['fields']['to_revenue_c']['dependency']='';

 ?>