<?php
 // created: 2013-12-20 13:12:48
$dictionary['Bhea_Payments']['fields']['payment_date']['required']=true;

 ?>