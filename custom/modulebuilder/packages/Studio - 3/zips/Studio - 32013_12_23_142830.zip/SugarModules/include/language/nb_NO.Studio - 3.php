<?php 
$app_list_strings['payment_status_list'] = array (
  'InvoiceRaised' => 'Invoice Raised',
  'PaymentReceived' => 'Payment Received',
  'OrderGenerated' => 'Order Generated',
);$app_list_strings['salutation_dom'] = array (
  '' => '',
  'Mr.' => 'Hr.',
  'Ms.' => 'Fr.',
  'Mrs.' => 'Fru',
  'Dr.' => 'Dr.',
  'Prof.' => 'Prof.',
  'Honourable' => 'Honourable',
);$app_list_strings['sessions_status'] = array (
  '' => '',
  'Planned' => 'Planned',
  'Held' => 'Held',
  'Cancelled' => 'Cancelled',
  'Preponed' => 'Preponed',
  'Postponed' => 'Postponed',
);