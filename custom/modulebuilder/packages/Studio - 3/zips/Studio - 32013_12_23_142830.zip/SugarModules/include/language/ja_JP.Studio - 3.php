<?php 
$app_list_strings['payment_status_list'] = array (
  'InvoiceRaised' => 'Invoice Raised',
  'PaymentReceived' => 'Payment Received',
  'OrderGenerated' => 'Order Generated',
);$app_list_strings['salutation_dom'] = array (
  '' => '',
  'Mr.' => '様',
  'Ms.' => 'Ms.',
  'Mrs.' => 'Mrs.',
  'Dr.' => '先生',
  'Prof.' => '教授',
  'Honourable' => 'Honourable',
);$app_list_strings['sessions_status'] = array (
  '' => '',
  'Planned' => 'Planned',
  'Held' => 'Held',
  'Cancelled' => 'Cancelled',
  'Preponed' => 'Preponed',
  'Postponed' => 'Postponed',
);