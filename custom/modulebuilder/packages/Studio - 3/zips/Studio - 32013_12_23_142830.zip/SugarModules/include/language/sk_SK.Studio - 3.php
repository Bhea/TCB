<?php 
$app_list_strings['payment_status_list'] = array (
  'InvoiceRaised' => 'Invoice Raised',
  'PaymentReceived' => 'Payment Received',
  'OrderGenerated' => 'Order Generated',
);$app_list_strings['salutation_dom'] = array (
  '' => '',
  'Mr.' => 'Pán',
  'Ms.' => 'Slečna',
  'Mrs.' => 'Pani',
  'Dr.' => 'Doktor',
  'Prof.' => 'Profesor',
  'Honourable' => 'Honourable',
);$app_list_strings['sessions_status'] = array (
  '' => '',
  'Planned' => 'Planned',
  'Held' => 'Held',
  'Cancelled' => 'Cancelled',
  'Preponed' => 'Preponed',
  'Postponed' => 'Postponed',
);