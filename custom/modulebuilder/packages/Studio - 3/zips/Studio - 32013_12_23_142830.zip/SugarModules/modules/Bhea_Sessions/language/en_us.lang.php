<?php 
 // created: 2013-12-23 14:28:29
$mod_strings['LBL_SESSION_COORDINATOR'] = 'Session Coordinator not';
$mod_strings['LBL_SPEAKER'] = 'Speaker not';
$mod_strings['LBL_BHEA_SESSIONS_BHEA_SPONSORSHIP_TYPES_1_FROM_BHEA_SPONSORSHIP_TYPES_TITLE'] = 'Sponsorship Type';
$mod_strings['LBL_BHEA_SESSIONS_BHEA_REGISTRANTS_1_FROM_BHEA_REGISTRANTS_TITLE'] = 'Participants';
$mod_strings['LBL_CONTACTS_BHEA_SESSIONS_1_FROM_CONTACTS_TITLE'] = 'Contacts';
$mod_strings['LBL_BHEA_SESSIONS_BHEA_SPEAKERS_1_FROM_BHEA_SPEAKERS_TITLE'] = 'Speakers';
$mod_strings['LBL_STATUS'] = 'Status';

?>
