<?php
 // created: 2013-12-21 10:54:12
$dictionary['Bhea_Payments']['fields']['payment_status']['default']='OrderGenerated';

 ?>