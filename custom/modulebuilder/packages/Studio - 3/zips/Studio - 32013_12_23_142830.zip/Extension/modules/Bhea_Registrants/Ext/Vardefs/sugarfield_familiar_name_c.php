<?php
 // created: 2013-12-03 09:46:09
$dictionary['Bhea_Registrants']['fields']['familiar_name_c']['labelValue']='Familiar Name';
$dictionary['Bhea_Registrants']['fields']['familiar_name_c']['full_text_search']=array (
  'boost' => '0',
);
$dictionary['Bhea_Registrants']['fields']['familiar_name_c']['enforced']='';
$dictionary['Bhea_Registrants']['fields']['familiar_name_c']['dependency']='';

 ?>