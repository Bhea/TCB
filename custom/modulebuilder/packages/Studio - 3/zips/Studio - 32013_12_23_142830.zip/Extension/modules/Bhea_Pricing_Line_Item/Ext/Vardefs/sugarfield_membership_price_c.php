<?php
 // created: 2013-12-17 13:51:31
$dictionary['Bhea_Pricing_Line_Item']['fields']['membership_price_c']['labelValue']='Membership Fee';
$dictionary['Bhea_Pricing_Line_Item']['fields']['membership_price_c']['enforced']='';
$dictionary['Bhea_Pricing_Line_Item']['fields']['membership_price_c']['dependency']='';

 ?>