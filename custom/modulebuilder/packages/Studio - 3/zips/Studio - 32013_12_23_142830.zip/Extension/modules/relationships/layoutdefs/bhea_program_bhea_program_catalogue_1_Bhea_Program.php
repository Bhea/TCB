<?php
 // created: 2013-12-03 14:13:31
$layout_defs["Bhea_Program"]["subpanel_setup"]['bhea_program_bhea_program_catalogue_1'] = array (
  'order' => 100,
  'module' => 'Bhea_Program_Catalogue',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_BHEA_PROGRAM_BHEA_PROGRAM_CATALOGUE_1_FROM_BHEA_PROGRAM_CATALOGUE_TITLE',
  'get_subpanel_data' => 'bhea_program_bhea_program_catalogue_1',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
