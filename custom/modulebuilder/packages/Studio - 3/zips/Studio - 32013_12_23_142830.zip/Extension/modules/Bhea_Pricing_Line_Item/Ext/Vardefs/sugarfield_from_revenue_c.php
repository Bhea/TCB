<?php
 // created: 2013-12-19 16:44:58
$dictionary['Bhea_Pricing_Line_Item']['fields']['from_revenue_c']['labelValue']='From Revenue(M)';
$dictionary['Bhea_Pricing_Line_Item']['fields']['from_revenue_c']['enforced']='';
$dictionary['Bhea_Pricing_Line_Item']['fields']['from_revenue_c']['dependency']='';

 ?>