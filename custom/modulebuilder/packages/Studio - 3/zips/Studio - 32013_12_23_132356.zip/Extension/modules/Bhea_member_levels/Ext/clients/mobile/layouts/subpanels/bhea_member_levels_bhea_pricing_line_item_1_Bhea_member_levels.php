<?php
// created: 2013-12-16 10:10:55
$viewdefs['Bhea_member_levels']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_BHEA_MEMBER_LEVELS_BHEA_PRICING_LINE_ITEM_1_FROM_BHEA_PRICING_LINE_ITEM_TITLE',
  'context' => 
  array (
    'link' => 'bhea_member_levels_bhea_pricing_line_item_1',
  ),
);