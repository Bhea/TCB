<?php
 // created: 2013-12-03 10:03:54
$dictionary['Contact']['fields']['sync_to_outlook_c']['labelValue']='Sync to Outlook';
$dictionary['Contact']['fields']['sync_to_outlook_c']['enforced']='';
$dictionary['Contact']['fields']['sync_to_outlook_c']['dependency']='';

 ?>