<?php
 // created: 2013-12-03 09:49:57
$dictionary['Contact']['fields']['status_c']['labelValue']='Status';
$dictionary['Contact']['fields']['status_c']['dependency']='';
$dictionary['Contact']['fields']['status_c']['visibility_grid']='';

 ?>