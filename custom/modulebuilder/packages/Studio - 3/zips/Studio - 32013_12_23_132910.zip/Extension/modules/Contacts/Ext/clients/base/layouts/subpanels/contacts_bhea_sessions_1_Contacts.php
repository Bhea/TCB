<?php
// created: 2013-12-04 09:46:31
$viewdefs['Contacts']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_CONTACTS_BHEA_SESSIONS_1_FROM_BHEA_SESSIONS_TITLE',
  'context' => 
  array (
    'link' => 'contacts_bhea_sessions_1',
  ),
);