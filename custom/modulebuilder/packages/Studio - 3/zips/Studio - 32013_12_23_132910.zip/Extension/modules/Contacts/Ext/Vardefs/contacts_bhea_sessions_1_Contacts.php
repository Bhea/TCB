<?php
// created: 2013-12-04 09:46:31
$dictionary["Contact"]["fields"]["contacts_bhea_sessions_1"] = array (
  'name' => 'contacts_bhea_sessions_1',
  'type' => 'link',
  'relationship' => 'contacts_bhea_sessions_1',
  'source' => 'non-db',
  'module' => 'Bhea_Sessions',
  'bean_name' => 'Bhea_Sessions',
  'vname' => 'LBL_CONTACTS_BHEA_SESSIONS_1_FROM_BHEA_SESSIONS_TITLE',
  'id_name' => 'contacts_bhea_sessions_1bhea_sessions_idb',
);
