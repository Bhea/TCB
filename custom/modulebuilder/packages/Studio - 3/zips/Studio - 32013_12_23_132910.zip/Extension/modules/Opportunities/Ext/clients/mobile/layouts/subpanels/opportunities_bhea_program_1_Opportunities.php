<?php
// created: 2013-12-03 10:39:15
$viewdefs['Opportunities']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_OPPORTUNITIES_BHEA_PROGRAM_1_FROM_BHEA_PROGRAM_TITLE',
  'context' => 
  array (
    'link' => 'opportunities_bhea_program_1',
  ),
);