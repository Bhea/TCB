<?php
 // created: 2013-12-03 10:39:15
$layout_defs["Opportunities"]["subpanel_setup"]['opportunities_bhea_program_1'] = array (
  'order' => 100,
  'module' => 'Bhea_Program',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_OPPORTUNITIES_BHEA_PROGRAM_1_FROM_BHEA_PROGRAM_TITLE',
  'get_subpanel_data' => 'opportunities_bhea_program_1',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
