<?php 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/bhea_sessions_bhea_sponsorship_types_1MetaData.php');

?>