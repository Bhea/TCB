<?php 
 // created: 2013-12-20 13:12:46
$mod_strings['LBL_FAMILIAR_NAME'] = 'Familiar Name';
$mod_strings['LBL_DESCRIPTION'] = 'Description';
$mod_strings['LBL_AREA_OF_EXPERTISE'] = 'Area of Expertise';
$mod_strings['LBL_BHEA_CONTRACTORS_BHEA_SESSIONS_1_FROM_BHEA_SESSIONS_TITLE'] = 'Sessions';
$mod_strings['LBL_BHEA_CONTRACTORS_BHEA_EVENTS_1_FROM_BHEA_EVENTS_TITLE'] = 'Events';

?>
