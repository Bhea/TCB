<?php 
 // created: 2013-12-20 13:12:47
$mod_strings['LBL_CURRENCY'] = 'Currency';
$mod_strings['LBL_MEMBERS'] = 'Members';
$mod_strings['LBL_BHEA_COUNCIL_MEMBERSHIPS_OPPORTUNITIES_1_FROM_OPPORTUNITIES_TITLE'] = 'Opportunities';
$mod_strings['LBL_ACCOUNTS_BHEA_COUNCIL_MEMBERSHIPS_1_FROM_ACCOUNTS_TITLE'] = 'Company';
$mod_strings['LBL_DESCRIPTION'] = 'Lost Reason';
$mod_strings['LBL_AMOUNT_PAID'] = 'Amount Paid';
$mod_strings['LBL_DISCOUNT'] = 'Discount';
$mod_strings['LBL_FINAL_MEMBERSHIP_FEE'] = 'Final Membership Fee';
$mod_strings['LBL_BHEA_COUNCIL_MEMBERSHIPS_BHEA_PAYMENTS_1_FROM_BHEA_PAYMENTS_TITLE'] = 'Payments';
$mod_strings['LBL_BHEA_COUNCILS_BHEA_COUNCIL_MEMBERSHIPS_1_FROM_BHEA_COUNCILS_TITLE'] = 'Group';
$mod_strings['LBL_EXPIRY_DATE '] = 'Expiry Date';

?>
