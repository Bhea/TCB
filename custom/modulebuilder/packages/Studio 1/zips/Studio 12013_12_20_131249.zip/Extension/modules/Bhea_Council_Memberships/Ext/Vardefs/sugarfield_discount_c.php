<?php
 // created: 2013-12-06 14:56:21
$dictionary['Bhea_Council_Memberships']['fields']['discount_c']['labelValue']='Discount';
$dictionary['Bhea_Council_Memberships']['fields']['discount_c']['enforced']='';
$dictionary['Bhea_Council_Memberships']['fields']['discount_c']['dependency']='';

 ?>