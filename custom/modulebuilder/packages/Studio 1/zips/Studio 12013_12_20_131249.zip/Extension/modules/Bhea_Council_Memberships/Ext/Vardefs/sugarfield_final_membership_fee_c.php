<?php
 // created: 2013-12-06 14:56:54
$dictionary['Bhea_Council_Memberships']['fields']['final_membership_fee_c']['labelValue']='Final Membership Fee';
$dictionary['Bhea_Council_Memberships']['fields']['final_membership_fee_c']['enforced']='';
$dictionary['Bhea_Council_Memberships']['fields']['final_membership_fee_c']['dependency']='';

 ?>