<?php
 // created: 2013-12-03 19:38:25
$dictionary['Account']['fields']['request_quit_c']['labelValue']='Request Quit';
$dictionary['Account']['fields']['request_quit_c']['enforced']='';
$dictionary['Account']['fields']['request_quit_c']['dependency']='';

 ?>