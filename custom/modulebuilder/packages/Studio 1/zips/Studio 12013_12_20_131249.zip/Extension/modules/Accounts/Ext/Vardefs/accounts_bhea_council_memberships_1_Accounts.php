<?php
// created: 2013-12-03 12:24:34
$dictionary["Account"]["fields"]["accounts_bhea_council_memberships_1"] = array (
  'name' => 'accounts_bhea_council_memberships_1',
  'type' => 'link',
  'relationship' => 'accounts_bhea_council_memberships_1',
  'source' => 'non-db',
  'module' => 'Bhea_Council_Memberships',
  'bean_name' => 'Bhea_Council_Memberships',
  'vname' => 'LBL_ACCOUNTS_BHEA_COUNCIL_MEMBERSHIPS_1_FROM_ACCOUNTS_TITLE',
  'id_name' => 'accounts_bhea_council_memberships_1accounts_ida',
  'link-type' => 'many',
  'side' => 'left',
);
