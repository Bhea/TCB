<?php
 // created: 2013-12-20 10:02:17
$dictionary['Account']['fields']['company_category_c']['labelValue']='Company Category';
$dictionary['Account']['fields']['company_category_c']['dependency']='';
$dictionary['Account']['fields']['company_category_c']['visibility_grid']='';

 ?>