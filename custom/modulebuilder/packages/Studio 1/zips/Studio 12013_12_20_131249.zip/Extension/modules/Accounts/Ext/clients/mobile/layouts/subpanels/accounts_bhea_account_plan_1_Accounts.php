<?php
// created: 2013-12-04 09:27:55
$viewdefs['Accounts']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_ACCOUNTS_BHEA_ACCOUNT_PLAN_1_FROM_BHEA_ACCOUNT_PLAN_TITLE',
  'context' => 
  array (
    'link' => 'accounts_bhea_account_plan_1',
  ),
);