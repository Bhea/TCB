<?php
 // created: 2013-12-03 08:57:18
$dictionary['Account']['fields']['company_alias_c']['labelValue']='Company Alias';
$dictionary['Account']['fields']['company_alias_c']['full_text_search']=array (
  'boost' => '0',
);
$dictionary['Account']['fields']['company_alias_c']['enforced']='';
$dictionary['Account']['fields']['company_alias_c']['dependency']='';

 ?>