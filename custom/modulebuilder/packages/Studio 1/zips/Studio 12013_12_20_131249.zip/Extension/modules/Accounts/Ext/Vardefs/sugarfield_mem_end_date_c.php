<?php
 // created: 2013-12-04 14:56:32
$dictionary['Account']['fields']['mem_end_date_c']['labelValue']='Membership End Date';
$dictionary['Account']['fields']['mem_end_date_c']['enforced']='';
$dictionary['Account']['fields']['mem_end_date_c']['dependency']='or(equal($account_type,"member"),equal($account_type,"past_member"))';

 ?>