<?php
// created: 2013-12-19 18:57:27
$viewdefs['Bhea_Sessions']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_OPPORTUNITIES_BHEA_SESSIONS_1_FROM_OPPORTUNITIES_TITLE',
  'context' => 
  array (
    'link' => 'opportunities_bhea_sessions_1',
  ),
);