({
    extendsFrom: 'RecordView',

    initialize: function (options) {
        app.view.invokeParent(this, {type: 'view', name: 'record', method: 'initialize', args:[options]});

        this.context.on('button:get_membership_fees:click', this.get_membership_fees, this);
    },
    
    editClicked:function() {
		var sales_stage = this.model.get('sales_stage');
      
				if(sales_stage =="Closed Won"){
											$('[name="duplicate_button"]').hide();
											$('[name="delete_button"]').hide();
						$('[name="edit_button"]').attr("disabled", "disabled");
						$('body div span.record-edit-link-wrapper').hide();
						}
						else
						{
							this.setButtonStates(this.STATE.EDIT);this.toggleEdit(true);
						}
					},
	saveClicked:function() {
		var sales_stage = this.model.get('sales_stage');
		if(sales_stage =="Closed Won"){
						$('[name="save_button"]').attr("disabled", "disabled");
						}
						else
						{
							this.model.doValidate(this.getFields(this.module),_.bind(this.validationComplete,this));
						}
					},
	get_membership_fees: function() {
		
		var oppID = this.model.get('id');
        var cmp_rev = this.model.get('company_revenue_c');
        var pricing_type_c = this.model.get('pricing_type_c');
        var opportunity_type = this.model.get('opportunity_type');
		$(document).ready(function()
		{
				 $.ajax({
					url:'MemberFeeAjax.php',
					type: "GET",
					async: false,
					data:
					{ 		
						oppID: oppID,
						cmp_rev: cmp_rev,
						pricing_type_c : pricing_type_c,
						opportunity_type : opportunity_type,
						
					},
					success:function(resp) {
						response=resp;
						location.reload();
					}	
				});
		});
	}
})

