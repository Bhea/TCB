<?php
 // created: 2014-01-08 09:46:13
$dictionary['Bhea_Memberships']['fields']['expiry_date']['importable']='false';
$dictionary['Bhea_Memberships']['fields']['expiry_date']['calculated']='1';
$dictionary['Bhea_Memberships']['fields']['expiry_date']['formula']='addDays($start_date,multiply(365,$member_period_c))';
$dictionary['Bhea_Memberships']['fields']['expiry_date']['enforced']=true;

 ?>