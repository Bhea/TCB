<?php
 // created: 2013-12-05 13:06:28
$dictionary['Bhea_Memberships']['fields']['mem_type']['default']='';

 ?>