<?php
$dictionary['Bhea_Memberships']['fields']['payment_mode']['readonly']=true;
 ?>
