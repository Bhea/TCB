<?php
 // created: 2014-01-08 09:45:16
$dictionary['Bhea_Memberships']['fields']['mem_period']['importable']='false';
$dictionary['Bhea_Memberships']['fields']['mem_period']['full_text_search']=array (
  'boost' => '0',
);
$dictionary['Bhea_Memberships']['fields']['mem_period']['calculated']=false;

 ?>