<?php
 // created: 2014-01-08 09:51:42
$dictionary['Bhea_Memberships']['fields']['member_period_c']['duplicate_merge_dom_value']=0;
$dictionary['Bhea_Memberships']['fields']['member_period_c']['labelValue']='Member Period';
$dictionary['Bhea_Memberships']['fields']['member_period_c']['full_text_search']=array (
  'boost' => '0',
);
$dictionary['Bhea_Memberships']['fields']['member_period_c']['calculated']='1';
$dictionary['Bhea_Memberships']['fields']['member_period_c']['formula']='getDropdownValue("membership_period_list",$membership_period_c)';
$dictionary['Bhea_Memberships']['fields']['member_period_c']['enforced']='1';
$dictionary['Bhea_Memberships']['fields']['member_period_c']['dependency']='';

 ?>