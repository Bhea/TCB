<?php
 // created: 2014-01-08 09:29:47
$dictionary['Bhea_Memberships']['fields']['membership_period_c']['labelValue']='Membership Period';
$dictionary['Bhea_Memberships']['fields']['membership_period_c']['dependency']='';
$dictionary['Bhea_Memberships']['fields']['membership_period_c']['visibility_grid']='';

 ?>