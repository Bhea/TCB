<?php
// created: 2013-12-04 12:54:45
$dictionary["Bhea_Contractors"]["fields"]["bhea_contractors_bhea_events_1"] = array (
  'name' => 'bhea_contractors_bhea_events_1',
  'type' => 'link',
  'relationship' => 'bhea_contractors_bhea_events_1',
  'source' => 'non-db',
  'module' => 'Bhea_Events',
  'bean_name' => 'Bhea_Events',
  'vname' => 'LBL_BHEA_CONTRACTORS_BHEA_EVENTS_1_FROM_BHEA_EVENTS_TITLE',
  'id_name' => 'bhea_contractors_bhea_events_1bhea_events_idb',
);
