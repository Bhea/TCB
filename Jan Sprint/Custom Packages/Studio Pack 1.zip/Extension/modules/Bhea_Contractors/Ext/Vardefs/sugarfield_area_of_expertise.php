<?php
 // created: 2013-12-03 10:10:17
$dictionary['Bhea_Contractors']['fields']['area_of_expertise']['full_text_search']=array (
  'boost' => '0',
);
$dictionary['Bhea_Contractors']['fields']['area_of_expertise']['cols']='50';

 ?>