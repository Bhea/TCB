<?php
 // created: 2013-12-04 12:54:45
$layout_defs["Bhea_Contractors"]["subpanel_setup"]['bhea_contractors_bhea_events_1'] = array (
  'order' => 100,
  'module' => 'Bhea_Events',
  'subpanel_name' => 'default',
  'title_key' => 'LBL_BHEA_CONTRACTORS_BHEA_EVENTS_1_FROM_BHEA_EVENTS_TITLE',
  'get_subpanel_data' => 'bhea_contractors_bhea_events_1',
);
