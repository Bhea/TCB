<?php
// created: 2013-12-04 12:54:45
$viewdefs['Bhea_Contractors']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_BHEA_CONTRACTORS_BHEA_EVENTS_1_FROM_BHEA_EVENTS_TITLE',
  'context' => 
  array (
    'link' => 'bhea_contractors_bhea_events_1',
  ),
);