<?php
 // created: 2014-01-17 18:48:57
$dictionary['Lead']['fields']['territory_id_c']['labelValue']='Territory ID';
$dictionary['Lead']['fields']['territory_id_c']['full_text_search']=array (
  'boost' => '0',
);
$dictionary['Lead']['fields']['territory_id_c']['enforced']='';
$dictionary['Lead']['fields']['territory_id_c']['dependency']='';

 ?>