<?php
 // created: 2014-01-17 18:50:24
$dictionary['Lead']['fields']['sub_type_c']['labelValue']='Sub Type';
$dictionary['Lead']['fields']['sub_type_c']['dependency']='';
$dictionary['Lead']['fields']['sub_type_c']['visibility_grid']=array (
  'trigger' => 'prod_serv_interest_c',
  'values' => 
  array (
    'membership' => 
    array (
      0 => 'new',
      1 => 'Upgrade',
      2 => 'renewal',
    ),
    'product_services' => 
    array (
      0 => 'conference',
      1 => 'seminar',
      2 => 'research_working',
      3 => 'experiential_learning',
    ),
    '' => 
    array (
    ),
    'Council' => 
    array (
      0 => 'new',
      1 => 'Upgrade',
      2 => 'renewal',
    ),
    'prod_service' => 
    array (
      0 => 'seminar',
      1 => 'conference',
      2 => 'research_working',
      3 => 'experiential_learning',
    ),
    'other' => 
    array (
    ),
  ),
);

 ?>