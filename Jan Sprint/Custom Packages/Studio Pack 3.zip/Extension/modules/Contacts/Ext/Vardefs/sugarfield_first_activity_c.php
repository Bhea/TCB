<?php
 // created: 2013-12-03 10:00:38
$dictionary['Contact']['fields']['first_activity_c']['labelValue']='First Activity Date';
$dictionary['Contact']['fields']['first_activity_c']['enforced']='';
$dictionary['Contact']['fields']['first_activity_c']['dependency']='';

 ?>