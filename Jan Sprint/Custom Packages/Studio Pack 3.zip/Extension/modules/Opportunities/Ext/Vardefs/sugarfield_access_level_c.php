<?php
 // created: 2013-12-25 19:27:27
$dictionary['Opportunity']['fields']['access_level_c']['labelValue']='Access Level';
$dictionary['Opportunity']['fields']['access_level_c']['dependency']='not(equal($opportunity_type,"prod_service"))';
$dictionary['Opportunity']['fields']['access_level_c']['visibility_grid']='';

 ?>