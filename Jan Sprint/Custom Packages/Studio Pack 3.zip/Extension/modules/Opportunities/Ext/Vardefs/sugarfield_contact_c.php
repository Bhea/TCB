<?php
 // created: 2014-01-15 14:06:33
$dictionary['Opportunity']['fields']['contact_c']['labelValue']='Contact';
$dictionary['Opportunity']['fields']['contact_c']['dependency']='or(equal($opportunity_type,"Council"),and(equal($opportunity_type,"prod_service"),equal($subtype_c,"conference"),equal($conference_sub_type_c,"Speakers")))';

 ?>