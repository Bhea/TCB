<?php
 // created: 2013-12-25 09:27:00
$dictionary['Opportunity']['fields']['membership_sub_category_c']['labelValue']='Membership Sub Category';
$dictionary['Opportunity']['fields']['membership_sub_category_c']['visibility_grid']=array (
  'trigger' => 'opportunity_type',
  'values' => 
  array (
    '' => 
    array (
    ),
    'membership' => 
    array (
      0 => 'All',
      1 => 'Topic',
    ),
    'Council' => 
    array (
      0 => 'All',
      1 => 'Topic',
    ),
    'prod_service' => 
    array (
    ),
    'other' => 
    array (
    ),
  ),
);

 ?>