<?php
 // created: 2014-01-16 18:56:46
$dictionary['Opportunity']['fields']['discount_c']['labelValue']='Adjustment';
$dictionary['Opportunity']['fields']['discount_c']['enforced']='';
$dictionary['Opportunity']['fields']['discount_c']['dependency']='';

 ?>