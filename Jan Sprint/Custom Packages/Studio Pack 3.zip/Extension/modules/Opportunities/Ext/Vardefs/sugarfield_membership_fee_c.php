<?php
 // created: 2014-01-02 10:30:45
$dictionary['Opportunity']['fields']['membership_fee_c']['labelValue']='Fee';
$dictionary['Opportunity']['fields']['membership_fee_c']['formula']='rollupMin($bhea_member_levels_opportunities_1,"cost")';
$dictionary['Opportunity']['fields']['membership_fee_c']['enforced']='false';
$dictionary['Opportunity']['fields']['membership_fee_c']['dependency']='';
$dictionary['Opportunity']['fields']['membership_fee_c']['readonly']='true';

 ?>
