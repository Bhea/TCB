<?php
 // created: 2014-01-17 14:12:28
$dictionary['Opportunity']['fields']['subtype_c']['labelValue']='Sub Type';
$dictionary['Opportunity']['fields']['subtype_c']['dependency']='';
$dictionary['Opportunity']['fields']['subtype_c']['visibility_grid']=array (
  'trigger' => 'opportunity_type',
  'values' => 
  array (
    'membership' => 
    array (
      0 => 'new',
      1 => 'Upgrade',
      2 => 'renewal',
    ),
    'prod_service' => 
    array (
      0 => 'conference',
      1 => 'seminar',
      2 => 'research_working',
      3 => 'experiential_learning',
    ),
    'other' => 
    array (
    ),
    '' => 
    array (
    ),
    'Council' => 
    array (
      0 => 'renewal',
    ),
  ),
);

 ?>