<?php
 // created: 2014-01-17 10:11:40
$dictionary['Opportunity']['fields']['final_membership_fee_c']['duplicate_merge_dom_value']=0;
$dictionary['Opportunity']['fields']['final_membership_fee_c']['labelValue']='Final Fee';
$dictionary['Opportunity']['fields']['final_membership_fee_c']['calculated']='1';
$dictionary['Opportunity']['fields']['final_membership_fee_c']['formula']='ifElse(equal(subStr($discount_c,0,1),"-"),subtract($membership_fee_c,abs($discount_c)),add($membership_fee_c,$discount_c))';
$dictionary['Opportunity']['fields']['final_membership_fee_c']['enforced']='1';
$dictionary['Opportunity']['fields']['final_membership_fee_c']['dependency']='';

 ?>