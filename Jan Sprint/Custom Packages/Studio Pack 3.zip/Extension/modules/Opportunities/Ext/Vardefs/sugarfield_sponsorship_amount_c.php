<?php
 // created: 2014-01-17 19:17:32
$dictionary['Opportunity']['fields']['sponsorship_amount_c']['labelValue']='Sponsorship Amount';
$dictionary['Opportunity']['fields']['sponsorship_amount_c']['enforced']='';
$dictionary['Opportunity']['fields']['sponsorship_amount_c']['dependency']='';

 ?>