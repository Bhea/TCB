<?php
 // created: 2014-01-17 08:53:57
$dictionary['Opportunity']['fields']['company_revenue_c']['duplicate_merge_dom_value']=0;
$dictionary['Opportunity']['fields']['company_revenue_c']['labelValue']='Company Revenue(M)';
$dictionary['Opportunity']['fields']['company_revenue_c']['calculated']='1';
$dictionary['Opportunity']['fields']['company_revenue_c']['formula']='ifElse(equal($region_c,"The_Americas"),related($accounts,"us_revenue_c"),related($accounts,"annual_revenue"))';
$dictionary['Opportunity']['fields']['company_revenue_c']['enforced']='1';
$dictionary['Opportunity']['fields']['company_revenue_c']['dependency']='';

 ?>