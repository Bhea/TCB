<?php
 // created: 2014-01-17 14:18:55
$dictionary['Opportunity']['fields']['membership_category_c']['labelValue']='Membership Category';
$dictionary['Opportunity']['fields']['membership_category_c']['dependency']='';
$dictionary['Opportunity']['fields']['membership_category_c']['visibility_grid']=array (
  'trigger' => 'opportunity_type',
  'values' => 
  array (
    '' => 
    array (
    ),
    'membership' => 
    array (
      0 => 'Enterprise',
      1 => 'Educational',
      2 => 'Government',
      3 => 'Mid_Market',
      4 => 'Non_Profit',
    ),
    'Council' => 
    array (
      0 => 'Enterprise',
      1 => 'Educational',
      2 => 'Government',
      3 => 'Mid_Market',
      4 => 'Non_Profit',
    ),
    'prod_service' => 
    array (
    ),
    'other' => 
    array (
    ),
  ),
);

 ?>