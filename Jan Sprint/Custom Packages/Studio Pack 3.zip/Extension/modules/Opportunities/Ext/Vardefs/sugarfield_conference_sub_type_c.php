<?php
 // created: 2013-12-25 09:48:29
$dictionary['Opportunity']['fields']['conference_sub_type_c']['labelValue']='Opportunity Entity';
$dictionary['Opportunity']['fields']['conference_sub_type_c']['dependency']='';
$dictionary['Opportunity']['fields']['conference_sub_type_c']['visibility_grid']=array (
  'trigger' => 'subtype_c',
  'values' => 
  array (
    '' => 
    array (
    ),
    'new_mem' => 
    array (
    ),
    'renewal' => 
    array (
    ),
    'mem_upgrade' => 
    array (
    ),
    'conference' => 
    array (
      0 => '',
      1 => 'Speakers',
      2 => 'Sponsors',
    ),
    'seminar' => 
    array (
      0 => '',
      1 => 'Speakers',
      2 => 'Sponsors',
    ),
    'sponsorship' => 
    array (
    ),
    'research_working' => 
    array (
      0 => '',
      1 => 'Speakers',
      2 => 'Sponsors',
    ),
    'experiential_learning' => 
    array (
      0 => '',
      1 => 'Speakers',
      2 => 'Sponsors',
    ),
  ),
);

 ?>