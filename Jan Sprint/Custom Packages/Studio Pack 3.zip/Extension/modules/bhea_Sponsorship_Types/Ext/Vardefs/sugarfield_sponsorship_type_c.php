<?php
 // created: 2014-01-06 12:24:51
$dictionary['bhea_Sponsorship_Types']['fields']['sponsorship_type_c']['labelValue']='Sponsorship Type';
$dictionary['bhea_Sponsorship_Types']['fields']['sponsorship_type_c']['dependency']='';
$dictionary['bhea_Sponsorship_Types']['fields']['sponsorship_type_c']['visibility_grid']='';

 ?>