<?php
 // created: 2014-01-10 11:43:53
$dictionary['Team']['fields']['territory_id_c']['labelValue']='Territory ID';
$dictionary['Team']['fields']['territory_id_c']['enforced']='';
$dictionary['Team']['fields']['territory_id_c']['dependency']='';
$dictionary['Team']['fields']['territory_id_c']['readonly']=true;

 ?>
