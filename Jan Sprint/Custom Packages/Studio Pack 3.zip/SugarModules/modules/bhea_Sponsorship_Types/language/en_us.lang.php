<?php 
 // created: 2014-01-20 11:00:49
$mod_strings['LNK_NEW_RECORD'] = 'Create Sponsorship Type';
$mod_strings['LNK_LIST'] = 'View Sponsorship Types';
$mod_strings['LBL_MODULE_NAME'] = 'Sponsorship Types';
$mod_strings['LBL_MODULE_NAME_SINGULAR'] = 'Sponsorship Type';
$mod_strings['LBL_NEW_FORM_TITLE'] = 'New Sponsorship Type';
$mod_strings['LNK_IMPORT_VCARD'] = 'Import Sponsorship Type vCard';
$mod_strings['LNK_IMPORT_BHEA_SPONSORSHIP_TYPES'] = 'Import Sponsorship Type';
$mod_strings['LBL_LIST_FORM_TITLE'] = 'Sponsorship Types List';
$mod_strings['LBL_SEARCH_FORM_TITLE'] = 'Search Sponsorship Type';
$mod_strings['LBL_HOMEPAGE_TITLE'] = 'My Sponsorship Types';
$mod_strings['LBL_DESCRIPTION'] = 'Description';
$mod_strings['LBL_OTHER_INFORMATION'] = 'Sponsorship Offering';
$mod_strings['LBL_SPONSORSHIP_COVERAGE'] = 'Sponsorship Coverage';
$mod_strings['LBL_SPONSORSHIP_REGION'] = 'Sponsorship Region';
$mod_strings['LBL_SPONSORSHIP_TYPE'] = 'Sponsorship Type';
$mod_strings['LBL_SPONSORSHIP_FEE'] = 'Sponsorship Fee';
$mod_strings['LBL_BHEA_SPONSORSHIP_TYPES_BHEA_SPONSORSHIP_1_FROM_BHEA_SPONSORSHIP_TITLE'] = 'Sponsorships';
$mod_strings['LBL_BHEA_SPONSORSHIP_TYPES_OPPORTUNITIES_1_FROM_OPPORTUNITIES_TITLE'] = 'Opportunity';
$mod_strings['LBL_BHEA_SESSIONS_BHEA_SPONSORSHIP_TYPES_1_FROM_BHEA_SESSIONS_TITLE'] = 'Session';
$mod_strings['LBL_BHEA_EVENTS_BHEA_SPONSORSHIP_TYPES_1_FROM_BHEA_EVENTS_TITLE'] = 'Event';

?>
