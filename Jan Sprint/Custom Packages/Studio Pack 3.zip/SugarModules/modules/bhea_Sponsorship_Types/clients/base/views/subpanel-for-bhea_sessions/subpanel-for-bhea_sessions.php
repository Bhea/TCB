<?php
// created: 2013-12-20 09:31:39
$viewdefs['bhea_Sponsorship_Types']['base']['view']['subpanel-for-bhea_sessions'] = array (
  'panels' => 
  array (
    0 => 
    array (
      'name' => 'panel_header',
      'label' => 'LBL_PANEL_1',
      'fields' => 
      array (
        0 => 
        array (
          'label' => 'LBL_NAME',
          'enabled' => true,
          'default' => true,
          'name' => 'name',
        ),
        1 => 
        array (
          'name' => 'sponsorship_region_c',
          'label' => 'LBL_SPONSORSHIP_REGION',
          'enabled' => true,
          'default' => true,
        ),
        2 => 
        array (
          'name' => 'sponsor_type_c',
          'label' => 'LBL_SPONSOR_TYPE',
          'enabled' => true,
          'default' => true,
        ),
        3 => 
        array (
          'name' => 'sponsorship_type_c',
          'label' => 'LBL_SPONSORSHIP_TYPE',
          'enabled' => true,
          'default' => true,
        ),
        4 => 
        array (
          'name' => 'sponsorship_coverage_c',
          'label' => 'LBL_SPONSORSHIP_COVERAGE',
          'enabled' => true,
          'default' => true,
        ),
        5 => 
        array (
          'name' => 'sponsorship_fee',
          'label' => 'LBL_SPONSORSHIP_FEE',
          'enabled' => true,
          'currency_format' => true,
          'default' => true,
        ),
        6 => 
        array (
          'label' => 'LBL_DATE_MODIFIED',
          'enabled' => true,
          'default' => true,
          'name' => 'date_modified',
        ),
      ),
    ),
  ),
  'orderBy' => 
  array (
    'field' => 'date_modified',
    'direction' => 'desc',
  ),
  'type' => 'subpanel-list',
);