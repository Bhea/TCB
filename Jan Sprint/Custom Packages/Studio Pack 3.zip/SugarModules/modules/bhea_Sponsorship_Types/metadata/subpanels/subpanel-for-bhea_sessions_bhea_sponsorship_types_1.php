<?php
// created: 2013-12-20 09:31:39
$subpanel_layout['list_fields'] = array (
  'name' => 
  array (
    'vname' => 'LBL_NAME',
    'widget_class' => 'SubPanelDetailViewLink',
    'width' => '10%',
    'default' => true,
  ),
  'sponsorship_region_c' => 
  array (
    'type' => 'enum',
    'default' => true,
    'studio' => 'visible',
    'vname' => 'LBL_SPONSORSHIP_REGION',
    'width' => '10%',
  ),
  'sponsor_type_c' => 
  array (
    'type' => 'enum',
    'default' => true,
    'studio' => 'visible',
    'vname' => 'LBL_SPONSOR_TYPE',
    'width' => '10%',
  ),
  'sponsorship_type_c' => 
  array (
    'type' => 'enum',
    'default' => true,
    'studio' => 'visible',
    'vname' => 'LBL_SPONSORSHIP_TYPE',
    'width' => '10%',
  ),
  'sponsorship_coverage_c' => 
  array (
    'type' => 'enum',
    'default' => true,
    'studio' => 'visible',
    'vname' => 'LBL_SPONSORSHIP_COVERAGE',
    'width' => '10%',
  ),
  'sponsorship_fee' => 
  array (
    'type' => 'currency',
    'vname' => 'LBL_SPONSORSHIP_FEE',
    'currency_format' => true,
    'width' => '10%',
    'default' => true,
  ),
  'date_modified' => 
  array (
    'vname' => 'LBL_DATE_MODIFIED',
    'width' => '10%',
    'default' => true,
  ),
);