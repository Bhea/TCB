<?php
class Territory_id
{
	function Territory_id($bean,$event,$arguments)
	{
		$team_obj = BeanFactory::getBean("Teams", $bean->team_id);
		$bean->territory_id_c = $team_obj->territory_id_c;
		$bean->save();
	}
}
?>
