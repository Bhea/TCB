<?php 
 // created: 2014-01-20 11:00:49
$mod_strings['LBL_TERRITORY_ID'] = 'Territory ID';

?>
