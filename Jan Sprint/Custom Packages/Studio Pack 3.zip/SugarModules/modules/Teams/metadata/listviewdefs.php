<?php
$listViewDefs['Teams'] = 
array (
  'name' => 
  array (
    'width' => '20%',
    'label' => 'LBL_NAME',
    'link' => true,
    'default' => true,
    'related_fields' => 
    array (
      0 => 'name_2',
    ),
  ),
  'territory_id_c' => 
  array (
    'type' => 'varchar',
    'default' => true,
    'label' => 'LBL_TERRITORY_ID',
    'width' => '10%',
  ),
  'description' => 
  array (
    'width' => '80%',
    'label' => 'LBL_DESCRIPTION',
    'default' => true,
  ),
);
