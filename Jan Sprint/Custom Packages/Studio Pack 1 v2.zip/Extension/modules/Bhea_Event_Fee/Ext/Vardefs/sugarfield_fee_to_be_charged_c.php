<?php
 // created: 2014-01-07 18:49:46
$dictionary['Bhea_Event_Fee']['fields']['fee_to_be_charged_c']['labelValue']='Fee To Be Charged';
$dictionary['Bhea_Event_Fee']['fields']['fee_to_be_charged_c']['enforced']='false';
$dictionary['Bhea_Event_Fee']['fields']['fee_to_be_charged_c']['dependency']='';
$dictionary['Bhea_Event_Fee']['fields']['fee_to_be_charged_c']['readonly']=true;
 ?>
