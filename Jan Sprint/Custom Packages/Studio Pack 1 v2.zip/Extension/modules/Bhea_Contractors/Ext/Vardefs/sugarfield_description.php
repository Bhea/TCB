<?php
 // created: 2013-12-03 10:10:04
$dictionary['Bhea_Contractors']['fields']['description']['comments']='Full text of the note';
$dictionary['Bhea_Contractors']['fields']['description']['merge_filter']='disabled';
$dictionary['Bhea_Contractors']['fields']['description']['full_text_search']=array (
  'boost' => '0',
);
$dictionary['Bhea_Contractors']['fields']['description']['calculated']=false;
$dictionary['Bhea_Contractors']['fields']['description']['rows']='4';
$dictionary['Bhea_Contractors']['fields']['description']['cols']='50';

 ?>