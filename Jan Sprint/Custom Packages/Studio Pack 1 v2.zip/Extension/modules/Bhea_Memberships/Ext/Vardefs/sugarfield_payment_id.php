<?php
$dictionary['Bhea_Memberships']['fields']['payment_id']['readonly']=true;
 ?>


