<?php
$dictionary['Bhea_Memberships']['fields']['payment_date']['readonly']=true;
 ?>

