<?php
 // created: 2014-01-01 19:14:40
$dictionary['Bhea_Memberships']['fields']['membership_code_c']['labelValue']='Membership Code';
$dictionary['Bhea_Memberships']['fields']['membership_code_c']['full_text_search']=array (
  'boost' => '0',
);
$dictionary['Bhea_Memberships']['fields']['membership_code_c']['enforced']='';
$dictionary['Bhea_Memberships']['fields']['membership_code_c']['dependency']='';
$dictionary['Bhea_Memberships']['fields']['membership_code_c']['readonly']=true;

 ?>
