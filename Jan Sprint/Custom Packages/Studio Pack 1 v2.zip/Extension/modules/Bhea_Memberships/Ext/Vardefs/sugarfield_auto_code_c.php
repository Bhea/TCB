<?php
 // created: 2014-01-01 18:53:29
$dictionary['Bhea_Memberships']['fields']['auto_code_c']['labelValue']='Auto Code';
$dictionary['Bhea_Memberships']['fields']['auto_code_c']['full_text_search']=array (
  'boost' => '0',
);
$dictionary['Bhea_Memberships']['fields']['auto_code_c']['enforced']='';
$dictionary['Bhea_Memberships']['fields']['auto_code_c']['dependency']='';

$dictionary['Bhea_Memberships']['fields']['auto_code_c']['auto_increment']=true;
$dictionary['Bhea_Memberships']['fields']['auto_code_c']['autoinc_next']='1000';

 ?>
