<?php
/**
* Purpose: This file is used to check if the Company selected in Opportunities has an active membership or not.
* Author:Venkata Krishna C V.
* Date: 27/1/2014
*/

if(!defined('sugarEntry')) define('sugarEntry', true);
require_once('include/entryPoint.php');
require_once('data/BeanFactory.php');

global $db;
$acc_id = $_GET['account'];
$query = "SELECT account_type FROM accounts WHERE id='$acc_id' AND deleted=0";
$result = $db->query($query);
$row = $db->fetchByAssoc($result);
if($row['account_type']=="member")
{
	echo "yes";
}
else
{
	echo "no";
}

?>
