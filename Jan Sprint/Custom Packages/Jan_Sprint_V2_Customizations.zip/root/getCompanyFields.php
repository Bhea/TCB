<?php

/**
 * Purpose: This file is used for the Ajax Call done from opportunity module which populates fields in opportunity based on the company selected.
 * Author: Venkata Krishna C V
 * Date: 24/1/2014
 * */

if(!defined('sugarEntry')) define('sugarEntry', true);
require_once('include/entryPoint.php');
require_once('data/BeanFactory.php');
$acc_id = $_GET['account'];
	global $db;
	if($acc_id!="")
	{
		$query = "SELECT a.account_type,ac.us_revenue_c,a.annual_revenue,ac.territory_id_c,ac.region_c FROM accounts a,accounts_cstm ac WHERE a.id='$acc_id' AND a.deleted=0 AND ac.id_c=a.id";
		$result = $db->query($query);
		$row = $db->fetchByAssoc($result);
		if($row['region_c'] == "us")
					$revenue = $row['us_revenue_c'];
				else
					$revenue = $row['annual_revenue'];
		if($row['account_type'] == "member")
		{
			$query2 = "SELECT m.id FROM bhea_memberships AS m JOIN accounts_bhea_memberships_1_c AS cm ON cm.accounts_bhea_memberships_1bhea_memberships_idb = m.id WHERE cm.accounts_bhea_memberships_1accounts_ida =  '$acc_id' AND m.deleted =0 AND cm.deleted =0 AND m.mem_type='new'";
			$result2 = $db->query($query2);
			$row2 = $db->fetchByAssoc($result2);
			$mem_id = $row2['id'];
			if($mem_id)
			{
				$query3 = "SELECT ml.mem_type,mlc.membership_sub_category_c,mlc.practice_area_c,ml.cat_type,ml.id,ml.name FROM bhea_member_levels_cstm AS mlc,bhea_member_levels AS ml JOIN bhea_member_levels_bhea_memberships_1_c AS mlm ON mlm.bhea_member_levels_bhea_memberships_1bhea_member_levels_ida=ml.id WHERE bhea_member_levels_bhea_memberships_1bhea_memberships_idb='$mem_id' AND ml.id=mlc.id_c";
				$result3 = $db->query($query3);
				$row3 = $db->fetchByAssoc($result3);
				echo $revenue."^".$row['territory_id_c']."^".$row['region_c']."^".$row3['mem_type']."^".$row3['membership_sub_category_c']."^".$row3['practice_area_c']."^".$row3['cat_type']."^".$row3['id']."^".$row3['name'];
			}
			else
			{
				echo $revenue."^".$row['territory_id_c']."^".$row['region_c'];
			}
		}
		else
		{
			echo $revenue."^".$row['territory_id_c']."^".$row['region_c'];
		}
	}
?>

