<?php
if(!defined('sugarEntry')) define('sugarEntry', true);
require_once('include/entryPoint.php');

$contact_id = $_GET['contact_id'];
$session_id = $_GET['session_id'];
$event_id1 = $_GET['event_id'];

global $db;

$query = "SELECT salutation,first_name,last_name,title,department,phone_work,phone_mobile,phone_fax FROM contacts WHERE id='$contact_id' AND deleted=0";
$result = $db->query($query);
$row = $db->fetchByAssoc($result);

$query2 = "SELECT account_id FROM accounts_contacts WHERE contact_id = '$contact_id' AND deleted=0";
$result2 = $db->query($query2);
$row2 = $db->fetchByAssoc($result2);

$account_id = $row2['account_id'];

$query3 = "SELECT name, billing_address_street, billing_address_city, billing_address_state, billing_address_country, billing_address_postalcode FROM accounts WHERE id = '$account_id' AND deleted=0";
$result3 = $db->query($query3);
$row3 = $db->fetchByAssoc($result3);

if($session_id){
	
	$query1 = "SELECT bhea_events_bhea_sessions_1bhea_events_ida FROM bhea_events_bhea_sessions_1_c WHERE bhea_events_bhea_sessions_1bhea_sessions_idb='$session_id' AND deleted=0";
	$result1	=	$db->query($query1);
	$row1		=	$db->fetchByAssoc($result1);

	$event_id	=	$row1['bhea_events_bhea_sessions_1bhea_events_ida'];

	$query4 = "SELECT id,name,event_type FROM bhea_events WHERE id='$event_id' AND deleted=0";
	$result4	=	$db->query($query4);
	$row4		=	$db->fetchByAssoc($result4);
	$event_type = 	$row4['event_type'];

	if($event_type == 'Council_Meeting'){
		$participant_type = 'Council_Member';		
	}
	else {
		$participant_type = '';		
	}
	
}
if($event_id1){
			
	$query5 = "SELECT event_type FROM bhea_events WHERE id='$event_id1' AND deleted=0";
	$result5	=	$db->query($query5);
	$row5		=	$db->fetchByAssoc($result5);
	$event_type = 	$row5['event_type'];

	if($event_type == 'Council_Meeting'){
		$participant_type = 'Council_Member';		
	}
	else {
		$participant_type = '';		
	}
}


if($session_id){
	echo $row['salutation']."^".$row['first_name']."^".$row['last_name']."^".$row['title']."^".$row['department']."^".$row['phone_work']."^".$row['phone_mobile']."^".$row['phone_fax']."^".$row3['name']."^".$row3['billing_address_street']."^".$row3['billing_address_city']."^".$row3['billing_address_state']."^".$row3['billing_address_country']."^".$row3['billing_address_postalcode']."^".$row4['name']."^".$participant_type."^".$row4['id'];
}

elseif($event_id1){
	echo $row['salutation']."^".$row['first_name']."^".$row['last_name']."^".$row['title']."^".$row['department']."^".$row['phone_work']."^".$row['phone_mobile']."^".$row['phone_fax']."^".$row3['name']."^".$row3['billing_address_street']."^".$row3['billing_address_city']."^".$row3['billing_address_state']."^".$row3['billing_address_country']."^".$row3['billing_address_postalcode']."^".$participant_type;
}

?>
