<?php
/**
 * Purpose: Get Membership Fee from the group selected and populate in Opportunity's Fee field.
 * Date: 23/1/2014
 * Author: Venkata Krishna C V
 **/

if(!defined('sugarEntry')) define('sugarEntry', true);
require_once('include/entryPoint.php');
require_once('data/BeanFactory.php');
$grp_id = $_GET['groupid'];
global $db;
$query = "SELECT membership_fee FROM bhea_councils WHERE id='$grp_id' AND deleted=0";
$result = $db->query($query);
$row = $db->fetchByAssoc($result);
echo $row['membership_fee'];

?>
