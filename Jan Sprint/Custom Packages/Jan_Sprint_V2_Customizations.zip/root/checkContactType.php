<?php
/**
 * Purpose: This file is used to check if the contact selected in Opportunity, is having and Active Council Membership
 * Author: Venkata Krishna C V
 * Date: 27/1/2014
 **/
if(!defined('sugarEntry')) define('sugarEntry', true);
require_once('include/entryPoint.php');
require_once('data/BeanFactory.php');
global $db;
$contact_id = $_GET['contactID'];
$query = "SELECT cs.contact_type_c,cs.status_c FROM contacts_cstm AS cs JOIN contacts AS c ON c.id=cs.id_c WHERE cs.id_c = '$contact_id' AND c.deleted=0";
$result = $db->query($query);
$row = $db->fetchByAssoc($result);
if(($row['contact_type_c'] == "Council_Member") && ($row['status_c'] == "active"))
{
	echo "yes";
}
else
{
	echo "no";
}
?>
