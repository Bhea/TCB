({
	    extendsFrom: 'CreateView',
	    initialize: function (options) {
	        app.view.invokeParent(this, {type: 'view', name: 'create', method: 'initialize', args:[options]});
			
			/**
			 * Purpose: Hiding the fields based on the condition in Opportunities
			 * Author: Meghana A & Venkata Krishna C V & Prateek Kaushal
			 * Date: 24/1/2014
			 */
			this.model.on("change",function()
				{
				if (($('li.active').attr('data-module') == "Opportunities") || ($('li.active').attr('data-module') == "Accounts") || ($('li.active').attr('data-module') == "Bhea_Councils") || ($('li.active').attr('data-module') == "Bhea_member_levels") || ($('li.active').attr('data-module') == "Contacts") || ($('li.active').attr('data-module') == "Bhea_Events") || ($('li.active').attr('data-module') == "bhea_Sponsorship_Types") || ($('li.active').attr('data-module') == "Bhea_Council_Members") ) {
					
					if($('li.active').attr('data-module') == "Bhea_Council_Members") {
					
						var status = this.model.get("membership_status");				
					
						if(status == 'Active') {
							$('div[data-name="bhea_councils_bhea_council_members_1_name"]').show();
							$('span[data-fieldname="bhea_councils_bhea_council_members_1_name"]').show();
							
							$('div[data-name="bhea_councils_bhea_council_members_2_name"]').hide();
							$('span[data-fieldname="bhea_councils_bhea_council_members_2_name"]').hide();
						}
						else if(status == 'InActive'){
							$('div[data-name="bhea_councils_bhea_council_members_1_name"]').hide();
							$('span[data-fieldname="bhea_councils_bhea_council_members_1_name"]').hide();
							
							$('div[data-name="bhea_councils_bhea_council_members_2_name"]').show();
							$('span[data-fieldname="bhea_councils_bhea_council_members_2_name"]').show();
						}
					}
					
					
					var opportunity_type=this.model.get('opportunity_type');
					if (this.model.get('opportunity_type') == 'membership')
					{
						$("div[data-name='bhea_councils_opportunities_1_name']").hide();
						$("div[data-name='bhea_events_opportunities_1_name']").hide();
						$("div[data-name='bhea_sponsorship_types_opportunities_1_name']").hide();

					}
					else if((this.model.get('opportunity_type') == 'Council') || (this.model.get('opportunity_type') == 'R_W_G'))
					{
						/**
						 * Author: Venkata Krishna C V
						 **/
						$("div[data-name='bhea_councils_opportunities_1_name']").show();
						$("div[data-name='conference_sub_type_c']").hide();
						$("div[data-name='bhea_events_opportunities_1_name']").hide();
						$("div[data-name='bhea_sponsorship_types_opportunities_1_name']").hide();
					}
					else if(this.model.get('opportunity_type') == 'Conference')
					{
						/**
						 * Author: Prateek Kaushal 
						 **/
						if(this.model.get('conference_sub_type_c')=='Speakers') 
						{
							$("div[data-name='bhea_sponsorship_types_opportunities_1_name']").hide();
						}
						else
						{
							$("div[data-name='bhea_sponsorship_types_opportunities_1_name']").show();
						}
					}
					else
					{
						$("div[data-name='bhea_councils_opportunities_1_name']").show();
						$("div[data-name='conference_sub_type_c']").show();
						$("div[data-name='bhea_events_opportunities_1_name']").show();
						$("div[data-name='bhea_sponsorship_types_opportunities_1_name']").show();
					}	
				}
				},this);
				
	        //add validation
			this.model.addValidationTask('check_account_type', _.bind(this._doValidateCheckType, this));					
			this.model.on("change", this._doChange, this);	
			//~ this.model.on("change:membership_status", this._doChangeMemTill, this);	
			this.model.on("change", this._doMemType, this);	
			this.model.on("change:bhea_member_levels_opportunities_1bhea_member_levels_ida", this._doMemFee, this);
			this.model.on("change", this._doChangeOpp, this);	
			this.model.on("change", this._doChangeParticipant, this);	
			//~ this.model.on("change:opportunity_type", this._companyFirst, this);
			//~ this.model.on("change:contact_c", this._doChangeContactOpp, this);	
			//~ this.model.on("change:opportunity_type", this._doChangeContactOpp, this);	
			//~ this.model.on("change:subtype_c", this._doChangeContactOpp, this);	
			this.model.on("change:account_name",this._populateFromCompany, this);
			this.model.on("change:opportunity_type",this._populateFromCompany, this);
			this.model.on("change",this._groupInEvent, this);
							
	    },	 
	    
		/**
		 * Purpose: This alerts a message if the opportunity type is selected without selecting a company in the company field, saying "Select a Company First"
		 * Author: Venkata Krishna C V
		 * Date: 27/1/2014 
		 **/
		/*_companyFirst:function(){
			if (($('li.active').attr('data-module') == "Opportunities") || ($('li.active').attr('data-module') == "Accounts")) {
				if(!this.model.get('account_id'))
				{	
					if(this.model.get('opportunity_type'))
					{
						alert('Select a Company first');
						this.model.set('opportunity_type','');
					}
				}
			}
		},*/
	    
	   /* _doChangeMemTill:function()
				{
					if ( $('li.active').attr('data-module') == "Bhea_Council_Members") {
					var today;
					var dd = (new Date).getDate();
					var mm = (new Date).getMonth()+1; //January is 0!
					var yyyy = (new Date).getFullYear();
					if(dd<10)
					{dd='0'+dd} 
					if(mm<10)
					{mm='0'+mm} 
					today = mm+'/'+dd+'/'+yyyy;
					var status = this.model.get('membership_status');
					var mem_till = this.model.get('member_till');
					if(status == "InActive")
					{
						this.model.set('member_till',today);
					}
				}
		},*/
				
	    _doMemFee:function(){
		if (($('li.active').attr('data-module') == "Opportunities") || ($('li.active').attr('data-module') == "Accounts") || ($('li.active').attr('data-module') == "Bhea_Councils") || ($('li.active').attr('data-module') == "Bhea_member_levels") || ($('li.active').attr('data-module') == "Contacts") || ($('li.active').attr('data-module') == "Bhea_Events") || ($('li.active').attr('data-module') == "bhea_Sponsorship_Types")) {
		var memLev_id = this.model.get('bhea_member_levels_opportunities_1bhea_member_levels_ida');
        var cmp_rev = this.model.get('company_revenue_c');
        var pricing_type_c = this.model.get('pricing_type_c');
        var opportunity_type = this.model.get('opportunity_type');
        var subtype_c = this.model.get('subtype_c');
        var compID = this.model.get('account_id');
        var memFee;
        var response;
        if(memLev_id)
        {
			if(opportunity_type == "membership")
			{	
					 $.ajax({
						url:'MemberFeeAjax.php',
						type: "GET",
						async: false,
						data:
						{ 		
							cmp_rev: cmp_rev,
							memLev_id: memLev_id,
							pricing_type_c : pricing_type_c,
							opportunity_type : opportunity_type,
						},
						success:function(resp) {
							memFee=resp;
							//alert(memFee);
						}	
					});
			this.model.set('membership_fee_c',memFee);
			}
		}
		else
		{
			this.model.set('membership_fee_c',"0.00");
		}
	}
},

/**
* Purpose: Hiding the fields based on the Opportunity Type in Opportunities
* Author: Prateek Kaushal
* Date: 26/1/2014
*/
	    _doChangeOpp:function(){
			if (($('li.active').attr('data-module') == "Opportunities") || ($('li.active').attr('data-module') == "Accounts") || ($('li.active').attr('data-module') == "Bhea_Councils") || ($('li.active').attr('data-module') == "Bhea_member_levels") || ($('li.active').attr('data-module') == "Contacts") || ($('li.active').attr('data-module') == "Bhea_Events") || ($('li.active').attr('data-module') == "bhea_Sponsorship_Types")) {
				
				//Hide the field Membership Level, Fee, Discout, FinalFee, Budget Amount, Amount when Opportunity type in Product & Services, Conference, Seminar. 
				var opportunity_type=this.model.get('opportunity_type');
				
				if((opportunity_type=='Conference')||(opportunity_type=='Seminar')||(opportunity_type=='prod_service')) {	
					
					$("div[data-name='bhea_councils_opportunities_1_name']").hide();
					$("div[data-name='access_level_c']").hide();
					$("div[data-name='pricing_type_c']").hide();
					$("div[data-name='bhea_member_levels_opportunities_1_name']").hide();
					$("div[data-name='membership_fee_c']").hide();
					$("div[data-name='discount_c']").hide();
					$("div[data-name='final_membership_fee_c']").hide();
					$("div[data-name='budget_amt_c']").hide();
					$("div[data-name='amount_usdollar']").hide();
				}
				else {
					$("div[data-name='bhea_councils_opportunities_1_name']").show();
					$("div[data-name='access_level_c']").show();
					$("div[data-name='pricing_type_c']").show();
					$("div[data-name='bhea_member_levels_opportunities_1_name']").show();
					$("div[data-name='membership_fee_c']").show();
					$("div[data-name='discount_c']").show();
					$("div[data-name='final_membership_fee_c']").show();
					$("div[data-name='budget_amt_c']").show();
					$("div[data-name='amount_usdollar']").show();			
				}
			}	
		},
		/**
			 * End of code(Hiding fields in Opportunities based on Opportunity Type)--By Prateek
			 * Author: Prateek Kaushal
			 * Date: 26/1/2014
			 */
		 
		 /**
			 * Purpose: Autopopulating the field of Participant based on the Contact selected,
			 * when we create a record from the Event or Session subpanel.
			 * Author: Prateek Kaushal
			 * Date: 26/1/2014
			 */
		_doChangeParticipant:function() {	
			if (($('li.active').attr('data-module') == "Bhea_Events")||($('li.active').attr('data-module') == "Bhea_Registrants")) {
			
			var participant_type=this.model.get('participant_type_c');
				
				if(participant_type=='Non_Member') {	
					$("div[data-name='bhea_registrants_contacts_1_name']").hide();
				}
				else {
					$("div[data-name='bhea_registrants_contacts_1_name']").show();	
				}
			
			var contact_id = this.model.get('bhea_registrants_contacts_1contacts_idb');
			var event_id = this.model.get('bhea_events_bhea_registrants_1bhea_events_ida');
			var details;
			$.ajax({
				url: 'contact.php',
				data: {
					event_id : event_id,
					contact_id : contact_id,
				},
				type: "GET",
				async: false,
				}).done(function(res){
					details = res.split('^');					
					});
					
			this.model.set('salutation',details[0]);
			this.model.set('first_name',details[1]);
			this.model.set('last_name',details[2]);
			this.model.set('title',details[3]);
			this.model.set('department',details[4]);
			this.model.set('phone_work',details[5]);
			this.model.set('phone_mobile',details[6]);
			this.model.set('phone_fax',details[7]);	
			this.model.set('company_name_c',details[8]);
			this.model.set('company_address_street_c',details[9]);
			this.model.set('company_address_city_c',details[10]);
			this.model.set('company_address_state_c',details[11]);
			this.model.set('company_address_country_c',details[12]);
			this.model.set('company_address_postalcode_c',details[13]);
			
			if(details[14])
			this.model.set('participant_type_c',details[14]);
		}		
			
		else if (($('li.active').attr('data-module') == "Bhea_Sessions")||($('li.active').attr('data-module') == "Bhea_Registrants")) {
			
			var participant_type=this.model.get('participant_type_c');
				
				if(participant_type=='Non_Member') {	
					$("div[data-name='bhea_registrants_contacts_1_name']").hide();
					//~ $("span[data-fieldname='bhea_sponsorship_types_opportunities_1_name']").hide();																							
				}
				else {
					$("div[data-name='bhea_registrants_contacts_1_name']").show();	
					//~ $("span[data-fieldname='bhea_sponsorship_types_opportunities_1_name']").show();	
				}
			
			var contact_id = this.model.get('bhea_registrants_contacts_1contacts_idb');
			var session_id = this.model.get('bhea_sessions_bhea_registrants_1bhea_sessions_ida');
			var details;
			$.ajax({
				url: 'contact.php',
				data: {
					contact_id : contact_id,
					session_id : session_id,
				},
				type: "GET",
				async: false,
				}).done(function(res){
					details = res.split('^');					
					});
					
			this.model.set('salutation',details[0]);
			this.model.set('first_name',details[1]);
			this.model.set('last_name',details[2]);
			this.model.set('title',details[3]);
			this.model.set('department',details[4]);
			this.model.set('phone_work',details[5]);
			this.model.set('phone_mobile',details[6]);
			this.model.set('phone_fax',details[7]);	
			this.model.set('company_name_c',details[8]);
			this.model.set('company_address_street_c',details[9]);
			this.model.set('company_address_city_c',details[10]);
			this.model.set('company_address_state_c',details[11]);
			this.model.set('company_address_country_c',details[12]);
			this.model.set('company_address_postalcode_c',details[13]);
			this.model.set('bhea_events_bhea_registrants_1_name',details[14]);
			if(details[15]) {
				this.model.set('participant_type_c',details[15]);
			}
			if(details[16]){
			this.model.set('bhea_events_bhea_registrants_1bhea_events_ida',details[16]);
			}
			
			
		}
	},
/**
* End of code--Autopopulating the field of Participant based on the Contact selected,
* when we create a record from the Event or Session subpanel.
* Author: Prateek Kaushal
* Date: 26/1/2014
*/

/**
 * Purpose: Show the group field in event when event_type is Council_Meeting, Else hide it. 
 * Author: Prateek Kaushal
 * Date: 30/1/2014
 */
		_groupInEvent:function(){		
			if (($('li.active').attr('data-module') == "Bhea_Events")) {
				
				var event_type=this.model.get('event_type');
				
				if(event_type=='Council_Meeting') {	
					$("div[data-name='bhea_councils_bhea_events_1_name']").show();																							
				}
				else {
					$("div[data-name='bhea_councils_bhea_events_1_name']").hide();	
				}
			}	
		},
/**
* End of code
* Author: Prateek Kaushal
* Date: 30/1/2014
*/
	    //For Contacts
	    _doChange:function()
		{		
			if (($('li.active').attr('data-module') == "Opportunities") || ($('li.active').attr('data-module') == "Accounts") || ($('li.active').attr('data-module') == "Bhea_Councils") || ($('li.active').attr('data-module') == "Bhea_member_levels") || ($('li.active').attr('data-module') == "Contacts") || ($('li.active').attr('data-module') == "Bhea_Events") || ($('li.active').attr('data-module') == "bhea_Sponsorship_Types")) {
				if(this.model.get('sales_stage') != 'Closed Lost')
				{
					$("div[data-name='lost_reason_c']").hide();
				}
				else
				{
					$("div[data-name='lost_reason_c']").show();
				}
				
				/** 
				* Purpose: Populate Fee in Opportunity from selected Group record.
				* Author : Venkata Krishna C V
				* Date: 24/1/2014
				* */
				var group_id = this.model.get('bhea_councils_opportunities_1bhea_councils_ida');
				var oppType = this.model.get('opportunity_type');
				if(oppType == "Council")
				{
					var OppFee;
						$.ajax({
								url: 'getGroupFee.php',
								data: {groupid: group_id},
								async: false,
								type: 'GET',
							}).done(function(resp){
										OppFee = resp;
								});
								if(OppFee)
						this.model.set('membership_fee_c',OppFee);
						else
						this.model.set('membership_fee_c','0.00');
				}
			}	
	    },
	    /* 
	     * To get the membership type
	     */
	 
	    _doMemType:function()
		{	
			if ($('li.active').attr('data-module') == "Bhea_Memberships") {	
			var mem_lev_id = this.model.get('bhea_member_levels_bhea_memberships_1bhea_member_levels_ida');
			var MemType;
				$.ajax({
						url: 'getMemberType.php',
						data: 
						{
							mem_lev_id: mem_lev_id,
						},
						async: false,
						type: 'GET',
					}).done(function(resp){
								MemType = resp;
						});
				this.model.set('mem_type',MemType);
			}
		},
		
		_populateFromCompany:function(){
/**
* Purpose: Get fields from Company and Membership Levels and populate in Opportunities
* Author : Venkata Krishna C V
* Date: 24/1/2014
**/	
				if (($('li.active').attr('data-module') == "Opportunities") || ($('li.active').attr('data-module') == "Accounts") || ($('li.active').attr('data-module') == "Bhea_Councils") || ($('li.active').attr('data-module') == "Bhea_member_levels") || ($('li.active').attr('data-module') == "Contacts") || ($('li.active').attr('data-module') == "Bhea_Events") || ($('li.active').attr('data-module') == "bhea_Sponsorship_Types")) {
				var account_id = this.model.get('account_id');
				var companyMemFlag;
				if(account_id)
				{
					var ml_fields;
						$.ajax({
							url: 'getCompanyFields.php',
							data: {
								account: account_id,
							},
							type: "GET",
							async: false,
							}).done(function(res){
									ml_fields = res.split('^');
								});
								if(ml_fields[0])
								this.model.set('company_revenue_c', $.trim(ml_fields[0]));
								if(ml_fields[1])
								this.model.set('territory_id_c', $.trim(ml_fields[1]));
								if(ml_fields[2])
								this.model.set('region_c', $.trim(ml_fields[2]));
								if(ml_fields[3])
								this.model.set('membership_category_c', $.trim(ml_fields[3]));
								if(ml_fields[4])
								this.model.set('membership_sub_category_c', $.trim(ml_fields[4]));
								if(ml_fields[5])
								this.model.set('practice_area_c', $.trim(ml_fields[5]));
								if(ml_fields[6])
								this.model.set('access_level_c', $.trim(ml_fields[6]));
								
							
/**
 * Purpose: This checks if the company selected is of type member, which if not, gives a message.
 * Author: Venkata Krishna C V
 * Date: 27/1/2014 
 **/
							/*$.ajax({
							url: 'checkCompany.php',
							data: {
								account: account_id,
							},
							type: "GET",
							async: false,
							}).done(function(res){
								if(res == "no")
								{
									alert("The Company selected does not have an Active Membership");
									this.model.set('opportunity_type',"");
									$('a[name="save_button"]').attr('disabled','true');
								}
								else
								{
									$('a[name="save_button"]').removeAttr('disabled');
								}
							});*/
				}
				else
				{
								this.model.set('company_revenue_c',"0.00");
								this.model.set('territory_id_c', "");
								this.model.set('region_c', "");
								this.model.set('membership_category_c', "");
								this.model.set('membership_sub_category_c', "");
								this.model.set('practice_area_c', "");
								this.model.set('access_level_c', "");
				}
			}
		},

/**
* Purpose: On selection of Contact in Opportunity when the Opportunity Type is Council Membership and Subtype is Renewal, check if the contact is having an Council Membership
* Author : Venkata Krishna C V
* Date: 27/1/2014
* */
			/*_doChangeContactOpp:function(){
				if (($('li.active').attr('data-module') == "Opportunities") || ($('li.active').attr('data-module') == "Accounts")) {
				var opp_type = this.model.get('opportunity_type');
					if(opp_type == "Council")
					{
						if(this.model.get('subtype_c')=="renewal")
						{
							var contact_id = this.model.get('contact_id_c');
							if(contact_id)
							{
							$.ajax({
								url: 'checkContactType.php',
								data: {contactID: contact_id},
								async: false,
								type: 'GET',
							}).done(function(resp){
									if(resp == "no")
									{
											alert("The contact you selected does not have an Active Council Membership");
											$('a[name="save_button"]').attr('disabled','true');
									}
									else
									{
											$('a[name="save_button"]').removeAttr('disabled');
									}
								});
							}
						}
						else
						{
							$('a[name="save_button"]').removeAttr('disabled');
						}
					}
					else
					{
							$('a[name="save_button"]').removeAttr('disabled');
					}
				}
			},*/
		
	    /*
	     * For making the
	     * fields mandatory
	     */
			_doValidateCheckType: function(fields, errors, callback) {
				
	       if (($('li.active').attr('data-module') == "Opportunities") || ($('li.active').attr('data-module') == "Accounts") || ($('li.active').attr('data-module') == "Bhea_Councils") || ($('li.active').attr('data-module') == "Bhea_member_levels") || ($('li.active').attr('data-module') == "Contacts") || ($('li.active').attr('data-module') == "Bhea_Events") || ($('li.active').attr('data-module') == "bhea_Sponsorship_Types")) {
								
				if (this.model.get('opportunity_type') == 'membership' &&  _.isEmpty(this.model.get('membership_category_c'))  && _.isEmpty(this.model.get('membership_sub_category_c')) && _.isEmpty(this.model.get('region_c')) )
				{
					errors['region_c'] = errors['region_c'] || {};
					errors['region_c'].required = true;	 
					errors['membership_category_c'] = errors['membership_category_c'] || {};
					errors['membership_category_c'].required = true;	           
					errors['membership_sub_category_c'] = errors['membership_sub_category_c'] || {};
					errors['membership_sub_category_c'].required = true;	           
				}
				if (this.model.get('membership_sub_category_c') == 'Topic' && _.isEmpty(this.model.get('practice_area_c')))
				{
					errors['practice_area_c'] = errors['practice_area_c'] || {};
					errors['practice_area_c'].required = true;	 
				}
				if (this.model.get('opportunity_type') == 'membership' && this.model.get('sales_stage') == 'Negotiation/Review' && _.isEmpty(this.model.get('bhea_member_levels_opportunities_1_name')))
				{
					errors['bhea_member_levels_opportunities_1_name'] = errors['bhea_member_levels_opportunities_1_name'] || {};
					errors['bhea_member_levels_opportunities_1_name'].required = true;
				}
				if (this.model.get('sales_stage') == 'Proposal/Price Quote' && _.isEmpty(this.model.get('bhea_member_levels_opportunities_1_name')))
				{
					errors['bhea_member_levels_opportunities_1_name'] = errors['bhea_member_levels_opportunities_1_name'] || {};
					errors['bhea_member_levels_opportunities_1_name'].required = true;
				}
				if(this.model.get('sales_stage') == 'Closed Lost' && _.isEmpty(this.model.get('lost_reason_c')) )
				{
					errors['lost_reason_c'] = errors['lost_reason_c'] || {};
					errors['lost_reason_c'].required = true;	
				}
				
		/**
		* Purpose: For making the fields mandatory in Participants.
		* Author: Prateek Kaushal
		* Date: 28/1/2014
		*/
				 
				if(this.model.get('opportunity_type') == 'Conference' && this.model.get('conference_sub_type')=='Speakers' && _.isEmpty(this.model.get('contact_c')))
				{
					errors['contact_c'] = errors['contact_c'] || {};
					errors['contact_c'].required = true;	 
				}
				
				if(this.model.get('opportunity_type') == 'Conference' && this.model.get('conference_sub_type')=='Sponsors' && _.isEmpty(this.model.get('bhea_sponsorship_types_opportunities_1_name')))
				{
					errors['bhea_sponsorship_types_opportunities_1_name'] = errors['bhea_sponsorship_types_opportunities_1_name'] || {};
					errors['bhea_sponsorship_types_opportunities_1_name'].required = true;	 
				} 
				
				/**
				 * Purpose: Custom Validations
				 * Author: Venkata Krishna C V
				 * Date: 28/1/2014 
				 **/
				 if(this.model.get('opportunity_type') == 'Council' && _.isEmpty(this.model.get('contact_c')))
				 {
					 errors['contact_c'] = errors['contact_c'] || {};
					 errors['contact_c'].required = true;
				 }
			}
/**
 * Purpose: For making the fields mandatory in Events.
 * Author: Prateek Kaushal
 * Date: 28/1/2014
 */			
			if (($('li.active').attr('data-module') == "Bhea_Events")) {
				if (this.model.get('event_type') == 'Council_Meeting' && _.isEmpty(this.model.get('bhea_councils_bhea_events_1_name'))){
							errors['bhea_councils_bhea_events_1_name'] = errors['bhea_councils_bhea_events_1_name'] || {};
							errors['bhea_councils_bhea_events_1_name'].required = true;	 
				}	
			}
/**
 * Purpose: For making the fields mandatory in Participants.
 * Author: Prateek Kaushal
 * Date: 28/1/2014
 */
		//~ if(($('li.active').attr('data-module') == ("Bhea_Events")) || ($('li.active').attr('data-module') == ("Bhea_Sessions"))) {       			
					//~ if (_.isEmpty(this.model.get('bhea_sessions_bhea_registrants_1_name')))
					//~ {
						//~ errors['bhea_sessions_bhea_registrants_1_name'] = errors['bhea_sessions_bhea_registrants_1_name'] || {};
						//~ errors['bhea_sessions_bhea_registrants_1_name'].required = true;
					//~ }
					//~ if (_.isEmpty(this.model.get('bhea_events_bhea_registrants_1_name')))
					//~ {
						//~ errors['bhea_events_bhea_registrants_1_name'] = errors['bhea_events_bhea_registrants_1_name'] || {};
						//~ errors['bhea_events_bhea_registrants_1_name'].required = true;
					//~ }
					//~ if (_.isEmpty(this.model.get('bhea_registrants_contacts_1_name')))
					//~ {
						//~ errors['bhea_registrants_contacts_1_name'] = errors['bhea_registrants_contacts_1_name'] || {};
						//~ errors['bhea_registrants_contacts_1_name'].required = true;
					//~ }	
		//~ }
			
	        callback(null, fields, errors);
	},
	    	   
})
