({
	    extendsFrom: 'RecordView',
	    initialize: function (options) {
	        app.view.invokeParent(this, {type: 'view', name: 'record', method: 'initialize', args:[options]});
				        
			this.model.on("change", this._doCustomization, this); 		
	    
		},		
			
		 
		  //Hide and Show Group relationships based on Active/Inactive Membership - By Anusha.K 31-Jan-2014
		  _doCustomization: function ()
		  {  
				//alert('hi');
				var status = this.model.get("membership_status");				
				
				if(status == 'Active') {
					$('div[data-name="bhea_councils_bhea_council_members_1_name"]').show();
					$('span[data-fieldname="bhea_councils_bhea_council_members_1_name"]').show();
					
					$('div[data-name="bhea_councils_bhea_council_members_2_name"]').hide();
					$('span[data-fieldname="bhea_councils_bhea_council_members_2_name"]').hide();
				}
				else if(status == 'InActive'){
					$('div[data-name="bhea_councils_bhea_council_members_1_name"]').hide();
					$('span[data-fieldname="bhea_councils_bhea_council_members_1_name"]').hide();
					
					$('div[data-name="bhea_councils_bhea_council_members_2_name"]').show();
					$('span[data-fieldname="bhea_councils_bhea_council_members_2_name"]').show();
				}
				
		  },		  
	     //END - By Anusha.K 31-Jan-2014
	    
	    
})
