<?php
/*
*@File:Acc_member_save.php.
*@Author:Meghana.A @ Bhea Technologies.
*@Purpose:If the existing record is edited
* in the company-financial performance then
* the file is called.
*/
class Acc_member_save
{
	function Acc_member_save($bean,$event,$arguments)
	{
		global $db;
		
		//~ $r = $_SERVER['REQUEST_URI']; 
		//~ $r = explode('/', $r);
		//~ $r = array_filter($r);
		//~ $r = array_merge($r, array()); 
		//~ $r = preg_replace('/\?.*/', '', $r);
		//~ $ids = $r[5];
				
		$query = 'SELECT  accounts_bhea_finance_performance_1bhea_finance_performance_idb as finance_id
					FROM  accounts_bhea_finance_performance_1_c 
					WHERE  accounts_bhea_finance_performance_1accounts_ida ="'.$bean->accounts_bhea_finance_performance_1accounts_ida.'"
					AND deleted =0 ORDER BY  `date_modified` DESC 
					LIMIT 1';
		$result = $db->query($query);
		$acc_obj = BeanFactory::getBean("Accounts",$bean->accounts_bhea_finance_performance_1accounts_ida);
		$id_latest = $db->fetchByAssoc($result);
		
		if(!empty($bean))
		{
			if($bean->id == $id_latest['finance_id'])
			 {
				$acc_obj->forbes_rating_c = $bean->forbes_rating_c;
				$acc_obj->annual_revenue = number_format($bean->revenue, 2, '.', '');
				$acc_obj->global_rating_c = $bean->fortune_global_rating_c;
				$acc_obj->employees = $bean->no_of_emp;
				$acc_obj->fortune_rank_c = $bean->fortune_rank_c;
				$acc_obj->fortune_global_rank_c = $bean->fortune_global_rank_c;
				$acc_obj->us_revenue_c = $bean->us_revenue_c;
				$acc_obj->ownership = $bean->ownership_c;
				$acc_obj->vat_number_c = $bean->vat_number_c;
				$acc_obj->sic_code = $bean->sic_code_c;
				$acc_obj->naics_1_c = $bean->naics_1_c;
				$acc_obj->naics_2_c = $bean->naics_2_c;
				$acc_obj->naics_3_c = $bean->naics_3_c;
				$acc_obj->save();
			 }
		}
	}
}
