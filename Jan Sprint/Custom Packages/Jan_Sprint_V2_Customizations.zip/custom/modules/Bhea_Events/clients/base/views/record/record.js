({
    extendsFrom: 'RecordView',

    initialize: function (options) {
        app.view.invokeParent(this, {type: 'view', name: 'record', method: 'initialize', args:[options]});

        this.model.on("change", this._doChange, this);	
        
         //add validation
		this.model.addValidationTask("check_empty_relationship", _.bind(this._doValidateCheckEmptyRelationship, this));
    },
/**
* Purpose: Show Group if Event_type is Council_Meeting ,else hide Group.
* Author: Prateek Kaushal 
* Date: 30/1/2014
*/
    _doChange:function(){
		
		var event_type=this.model.get('event_type');
				
				if(event_type=='Council_Meeting') {	
					$("div[data-name='bhea_councils_bhea_events_1_name']").show();																							
				}
				else {
					$("div[data-name='bhea_councils_bhea_events_1_name']").hide();	
				}						
	},
	
/** For making the
* fields mandatory in Participants.
* */
			_doValidateCheckEmptyRelationship: function(fields, errors, callback) {	       			
				if (this.model.get('event_type') == 'Council_Meeting' && _.isEmpty(this.model.get('bhea_councils_bhea_events_1_name')))
				{
					errors['bhea_councils_bhea_events_1_name'] = errors['bhea_councils_bhea_events_1_name'] || {};
					errors['bhea_councils_bhea_events_1_name'].required = true;	 
				}	
	        callback(null, fields, errors);
	    },
})

