<?php
/*
*@File:Speakers.php.
*@Author:Prateek Kaushal @ Bhea Technologies.
*@Purpose: To generate the Event Id. 
*/

if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
class eventid_class{
	
	function knowledge_area($str,$bean){
			if($bean->knowledge_area == "Human_Capital"){	
				$change = $str."-HC-";
			}
			
			if($bean->knowledge_area == "Corporate_Leadership"){
				$change = $str."-CL-";
			}
			
			if($bean->knowledge_area == "Economy"){
				$change = $str."-ECO-";
			}	
			return $change;
	}
	
	function eventid_method($bean,$event,$arguements){
		
		global $db;

		$query 		= 'SELECT code_c FROM bhea_events_cstm WHERE id_c="'.$bean->id.'"';
		$res   		= $db->query($query);
		$row   		= $bean->db->fetchByAssoc($res);                          
		$seq_no_c   = $row['code_c'];	
		
			if(strlen($seq_no_c)==1){
				$trun='0000';
			}
			else if(strlen($seq_no_c)==2){
				$trun='000';
			}
			else if(strlen($seq_no_c)==3){
				$trun='00';
			}
			else if(strlen($seq_no_c)==4){
				$trun='0';
			}

		$sno = $trun.$seq_no_c;
		
		switch($bean->event_type){
			
			case "Conference"	 			: 	$change = $this->knowledge_area("CONF",$bean);
												break;									
			case "Seminar" 					: 	$change = $this->knowledge_area("SEM",$bean);
												break;
			case "Web_Cast" 				: 	$change = $this->knowledge_area("WBC",$bean);
												break;
			case "Council_Meeting" 			: 	$change = $this->knowledge_area("CON",$bean);
												break;
			case "Inter_Council_Meeting" 	:	$change = $this->knowledge_area("ICM",$bean);
												break;
			case "Working_Group" 			: 	$change = $this->knowledge_area("WGP",$bean);
												break;
			case "Other" 					:	$change = $this->knowledge_area("OTH",$bean);
												break;
		}	
		
		$change = $change.$sno;
		
		$update_event_id_c = ' UPDATE bhea_events_cstm SET event_id_c="'.$change.'" WHERE id_c="'.$bean->id.'" ' ;	
		$db->query($update_event_id_c);	
		
		/**
		* Create a record in Meeting module and relating it to the Calender Module.
		*/
		$meetingBean = BeanFactory::newBean('Meetings');
		$meetingBean->name	 			= $bean->name;
		$meetingBean->date_start 		= $bean->begin_date;
		$meetingBean->description  		= $bean->description;
		$meetingBean->event_type_c  	= $bean->event_type;
		$meetingBean->location  		= $bean->bhea_hotels_bhea_events_1_name;
		$meetingBean->assigned_user_id	= $bean->assigned_user_id;
		
		$start_time = strtotime($bean->begin_date);
		$end_time = strtotime($bean->end_date);
		
		$diff = $end_time - $start_time;

		$hours = floor($diff / 3600);
		$minutes = floor(($diff / 60) % 60);
		$seconds = $diff % 60;
		
		$meetingBean->duration_hours	= $hours;
		$meetingBean->duration_minutes	= $minutes;		
	
		$meetingBean->save();
		
	}
	
}
