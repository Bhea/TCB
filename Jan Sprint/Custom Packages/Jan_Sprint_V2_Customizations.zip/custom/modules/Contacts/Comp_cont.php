<?php
/*
*@File:Comp_cont.php.
*@Author:Meghana.A @ Bhea Technologies.
*@Purpose:If the existing record is edited
* in the company-contact then the file is
* called.
*/

class Comp_cont
{
	function Comp_cont($bean,$event,$arguments)
	{
		
		global $db;
		$acc_obj = BeanFactory::getBean("Accounts",$bean->account_id);
		if(!empty($bean))
		{
			if($bean->type_c == "LE")
			{
				$fullname = $bean->salutation." ".$bean->first_name." ".$bean->last_name;
				$query = "UPDATE accounts_cstm SET le_phone_c='".$bean->phone_mobile."',le_name_c='".$fullname."',le_title_c='".$bean->title."',le_email_c='".$bean->emailAddress->getPrimaryAddress($bean)."' WHERE id_c='".$acc_obj->id."'";
				$db->query($query);
				//~ $acc_obj->le_phone_c = $bean->phone_mobile;
				//~ $acc_obj->le_name_c = $bean->first_name." ".$bean->last_name;
				//~ $acc_obj->le_title_c = $bean->title;
				//~ $acc_obj->le_email_c =$bean->emailAddress->getPrimaryAddress($bean);
				//$acc_obj->save();
			}
		}
	}
}

?>
