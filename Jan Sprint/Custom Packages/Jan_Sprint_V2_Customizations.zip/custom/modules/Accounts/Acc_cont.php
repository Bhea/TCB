<?php
/*
*@File:Acc_cont.php.
*@Author:Meghana.A @ Bhea Technologies.
*@Purpose:This logic will fetch the
* name,phone,email from the contact subpanel
* on the role as "LE" and the fetchd values 
* are inserted in the company record
*/
class Acc_cont
{
	function Acc_cont($bean,$event,$arguments)
	{
		global $db;
		$child_contact = $arguments["related_id"];
		$con_obj = BeanFactory::getBean("Contacts",$child_contact);
		if($bean->account_type == "member")
		{
			$query = "UPDATE contacts_cstm SET contact_type_c = 'Member' WHERE id_c = '".$con_obj->id."'";
			$db->query($query);
		}
		if($con_obj->type_c == "LE")
		{	
			$bean->le_name_c = $con_obj->salutation." ".$con_obj->first_name." ".$con_obj->last_name;
			$bean->le_title_c = $con_obj->title;
			$user=BeanFactory::getBean('Contacts',$child_contact);
			$bean->email1 =$user->emailAddress->getPrimaryAddress($user);
			$bean->le_phone_c = $con_obj->phone_mobile;
			//$bean->save();
		}
	}
}
?>
