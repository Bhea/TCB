<?php
/*
*@File:Acc_member.php.
*@Author:Meghana.A @ Bhea Technologies.
*@Purpose:If the recent record is removed then
* the last but the latest record's required fields
* values are populated
*/
class Acc_member_unlink
{
	function Acc_member_unlink($bean,$event,$arguments)
	{
		global $db;
		if($arguments['related_module'] == "Bhea_finance_performance")
		{
			$GLOBALS['log']->fatal("bheafin"); 
			$qry = 'SELECT accounts_bhea_finance_performance_1bhea_finance_performance_idb 
					FROM accounts_bhea_finance_performance_1_c 
					WHERE deleted =0
					ORDER BY date_modified DESC 
					LIMIT 1';
			$result = $db->query($qry);
			$row = $db->fetchByAssoc($result);
			$acc_fin_id = $row['accounts_bhea_finance_performance_1bhea_finance_performance_idb'];
			
	
			$query1 = 'SELECT a.revenue,a.no_of_emp,b.naics_1_c,b.naics_2_c,b.naics_3_c,b.vat_number_c,b.ownership_c,b.sic_code_c,b.fortune_global_rating_c,b.sic_code_c,b.vat_number_c,b.ownership_c,b.forbes_rating_c,b.fortune_rank_c,b.fortune_global_rank_c FROM bhea_finance_performance a,bhea_finance_performance_cstm b WHERE a.id="'.$acc_fin_id.'" AND b.id_c="'.$acc_fin_id.'"';
			$result1 = $db->query($query1);
			$row1 = $db->fetchByAssoc($result1);
			$bean->annual_revenue = number_format($row1['revenue'],2);
			
			(empty($row1['no_of_emp']))?($bean->employees = ""):($bean->employees = $row1['no_of_emp']);
			(empty($row1['fortune_global_rating_c']))?($bean->global_rating_c = ""):($bean->global_rating_c = $row1['fortune_global_rating_c']);
			(empty($row1['forbes_rating_c']))?($bean->forbes_rating_c = ""):($bean->forbes_rating_c = $row1['forbes_rating_c']);
			(empty($row1['fortune_global_rank_c']))?($bean->fortune_global_rank_c = ""):($bean->fortune_global_rank_c = $row1['fortune_global_rank_c']);
			(empty($row1['fortune_rank_c']))?($bean->fortune_rank_c = ""):($bean->fortune_rank_c = $row1['fortune_rank_c']);
			(empty($row1['us_revenue_c']))?($bean->us_revenue_c = ""):($bean->us_revenue_c = $row1['us_revenue_c']);
			(empty($row1['naics_1_c']))?($bean->naics_1_c = ""):($bean->naics_1_c = $row1['naics_1_c']);
			(empty($row1['naics_2_c']))?($bean->naics_2_c = ""):($bean->naics_2_c = $row1['naics_2_c']);
			(empty($row1['naics_3_c']))?($bean->naics_3_c = ""):($bean->naics_3_c = $row1['naics_3_c']);
			(empty($row1['sic_code_c']))?($bean->sic_code = ""):($bean->sic_code = $row1['sic_code_c']);
			(empty($row1['vat_number_c']))?($bean->vat_number_c = ""):($bean->vat_number_c = $row1['vat_number_c']);
			(empty($row1['ownership_c']))?($bean->ownership = ""):($bean->ownership = $row1['ownership_c']);
			$bean->save();
		}
	}
}
