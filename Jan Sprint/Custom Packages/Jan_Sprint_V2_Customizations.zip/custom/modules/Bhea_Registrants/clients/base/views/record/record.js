({
    extendsFrom: 'RecordView',

    initialize: function (options) {
        app.view.invokeParent(this, {type: 'view', name: 'record', method: 'initialize', args:[options]});

        this.model.on("change", this._doChange, this);	
        
        //add validation
		this.model.addValidationTask("check_empty_relationship", _.bind(this._doValidateCheckEmptyRelationship, this));
    },
/**
* Purpose: Autopopulating the field of Participant based on the Contact selected,
* when we create a record from the Event or Session subpanel.
* Author: Prateek Kaushal 
* Date: 26/1/2014
*/
    _doChange:function(){
		
		var participant_type=this.model.get('participant_type_c');
				
				if(participant_type=='Non_Member') {	
					$("div[data-name='bhea_registrants_contacts_1_name']").hide();
					//~ $("span[data-fieldname='bhea_sponsorship_types_opportunities_1_name']").hide();																							
				}
				else {
					$("div[data-name='bhea_registrants_contacts_1_name']").show();	
					//~ $("span[data-fieldname='bhea_sponsorship_types_opportunities_1_name']").show();	
				}

		var contact_id = this.model.get('bhea_registrants_contacts_1contacts_idb');
		var session_id = this.model.get('bhea_sessions_bhea_registrants_1bhea_sessions_ida');
		var details;
			$.ajax({
				url: 'contact.php',
				data: {
					event_id : event_id,
					contact_id : contact_id,
					session_id : session_id,
				},
				type: "GET",
				async: false,
				}).done(function(res){
					details = res.split('^');
					
					});
					
			this.model.set('salutation',details[0]);
			this.model.set('first_name',details[1]);
			this.model.set('last_name',details[2]);
			this.model.set('title',details[3]);
			this.model.set('department',details[4]);
			this.model.set('phone_work',details[5]);
			this.model.set('phone_mobile',details[6]);
			this.model.set('phone_fax',details[7]);
			
			this.model.set('company_name_c',details[8]);
			this.model.set('company_address_street_c',details[9]);
			this.model.set('company_address_city_c',details[10]);
			this.model.set('company_address_state_c',details[11]);
			this.model.set('company_address_country_c',details[12]);
			this.model.set('company_address_postalcode_c',details[13]);
			this.model.set('bhea_events_bhea_registrants_1_name',details[14]);
			
			if(details[15])
			this.model.set('participant_type_c',details[15]);
			
			if(details[16])
			this.model.set('bhea_events_bhea_registrants_1bhea_events_ida',details[16]);
							
	},
	
		/*
	     * For making the
	     * fields mandatory in Participants.
	     */
			_doValidateCheckEmptyRelationship: function(fields, errors, callback) {	       			
				if (_.isEmpty(this.model.get('bhea_sessions_bhea_registrants_1_name')))
				{
					errors['bhea_sessions_bhea_registrants_1_name'] = errors['bhea_sessions_bhea_registrants_1_name'] || {};
					errors['bhea_sessions_bhea_registrants_1_name'].required = true;
				}
				if (_.isEmpty(this.model.get('bhea_events_bhea_registrants_1_name')))
				{
					errors['bhea_events_bhea_registrants_1_name'] = errors['bhea_events_bhea_registrants_1_name'] || {};
					errors['bhea_events_bhea_registrants_1_name'].required = true;
				}
				if (_.isEmpty(this.model.get('bhea_registrants_contacts_1_name')))
				{
					errors['bhea_registrants_contacts_1_name'] = errors['bhea_registrants_contacts_1_name'] || {};
					errors['bhea_registrants_contacts_1_name'].required = true;
				}
				
				
	        callback(null, fields, errors);
	    },
})

