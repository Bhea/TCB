<?php
 // created: 2014-01-25 17:25:38
$dictionary['Lead']['fields']['territory_id_c']['labelValue']='Territory ID';
$dictionary['Lead']['fields']['territory_id_c']['full_text_search']=array (
  'boost' => '0',
);
$dictionary['Lead']['fields']['territory_id_c']['enforced']='';
$dictionary['Lead']['fields']['territory_id_c']['dependency']='';
$dictionary['Lead']['fields']['territory_id_c']['readonly']=true;

 ?>
