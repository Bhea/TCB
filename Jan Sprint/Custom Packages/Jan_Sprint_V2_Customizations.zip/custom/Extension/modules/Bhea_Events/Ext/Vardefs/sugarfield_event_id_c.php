<?php
 // created: 2014-01-25 17:27:10
$dictionary['Bhea_Events']['fields']['event_id_c']['labelValue']='Event ID';
$dictionary['Bhea_Events']['fields']['event_id_c']['full_text_search']=array (
  'boost' => '0',
);
$dictionary['Bhea_Events']['fields']['event_id_c']['enforced']='';
$dictionary['Bhea_Events']['fields']['event_id_c']['dependency']='';

 ?>