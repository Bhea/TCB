<?php
 // created: 2013-12-21 10:36:58
$dictionary['Bhea_finance_performance']['fields']['assets_c']['labelValue']='Assets(M)';
$dictionary['Bhea_finance_performance']['fields']['assets_c']['enforced']='';
$dictionary['Bhea_finance_performance']['fields']['assets_c']['dependency']='';

 ?>