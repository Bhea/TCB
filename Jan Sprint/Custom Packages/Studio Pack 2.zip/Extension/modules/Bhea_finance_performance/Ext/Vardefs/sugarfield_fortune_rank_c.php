<?php
 // created: 2014-01-16 15:44:36
$dictionary['Bhea_finance_performance']['fields']['fortune_rank_c']['labelValue']='Fortune Rank';
$dictionary['Bhea_finance_performance']['fields']['fortune_rank_c']['full_text_search']=array (
  'boost' => '0',
);
$dictionary['Bhea_finance_performance']['fields']['fortune_rank_c']['enforced']='';
$dictionary['Bhea_finance_performance']['fields']['fortune_rank_c']['dependency']='';

 ?>