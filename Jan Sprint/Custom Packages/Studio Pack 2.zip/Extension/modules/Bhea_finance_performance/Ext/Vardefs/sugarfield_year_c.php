<?php
 // created: 2013-12-13 18:17:31
$dictionary['Bhea_finance_performance']['fields']['year_c']['labelValue']='Year';
$dictionary['Bhea_finance_performance']['fields']['year_c']['dependency']='';
$dictionary['Bhea_finance_performance']['fields']['year_c']['visibility_grid']='';

 ?>