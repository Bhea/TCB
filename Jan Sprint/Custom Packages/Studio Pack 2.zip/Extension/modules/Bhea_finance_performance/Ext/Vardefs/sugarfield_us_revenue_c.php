<?php
 // created: 2014-01-16 18:59:37
$dictionary['Bhea_finance_performance']['fields']['us_revenue_c']['labelValue']='US Revenue(M)';
$dictionary['Bhea_finance_performance']['fields']['us_revenue_c']['enforced']='';
$dictionary['Bhea_finance_performance']['fields']['us_revenue_c']['dependency']='';

 ?>