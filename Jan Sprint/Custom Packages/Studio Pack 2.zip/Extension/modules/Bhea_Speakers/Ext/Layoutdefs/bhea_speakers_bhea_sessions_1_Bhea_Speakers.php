<?php
 // created: 2013-12-26 09:17:42
$layout_defs["Bhea_Speakers"]["subpanel_setup"]['bhea_speakers_bhea_sessions_1'] = array (
  'order' => 100,
  'module' => 'Bhea_Sessions',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_BHEA_SPEAKERS_BHEA_SESSIONS_1_FROM_BHEA_SESSIONS_TITLE',
  'get_subpanel_data' => 'bhea_speakers_bhea_sessions_1',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
