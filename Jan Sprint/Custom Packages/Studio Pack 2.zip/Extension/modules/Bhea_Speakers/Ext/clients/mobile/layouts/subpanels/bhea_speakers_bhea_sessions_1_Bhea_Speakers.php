<?php
// created: 2013-12-26 09:17:42
$viewdefs['Bhea_Speakers']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_BHEA_SPEAKERS_BHEA_SESSIONS_1_FROM_BHEA_SESSIONS_TITLE',
  'context' => 
  array (
    'link' => 'bhea_speakers_bhea_sessions_1',
  ),
);