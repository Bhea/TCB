<?php
 // created: 2013-12-18 19:54:10
$layout_defs["bhea_Sponsorship_Types"]["subpanel_setup"]['bhea_sessions_bhea_sponsorship_types_1'] = array (
  'order' => 100,
  'module' => 'Bhea_Sessions',
  'subpanel_name' => 'default',
  'title_key' => 'LBL_BHEA_SESSIONS_BHEA_SPONSORSHIP_TYPES_1_FROM_BHEA_SESSIONS_TITLE',
  'get_subpanel_data' => 'bhea_sessions_bhea_sponsorship_types_1',
);
