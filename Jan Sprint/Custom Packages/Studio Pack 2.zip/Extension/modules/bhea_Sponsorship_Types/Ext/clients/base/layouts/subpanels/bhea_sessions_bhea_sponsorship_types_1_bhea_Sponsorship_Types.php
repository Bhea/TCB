<?php
// created: 2013-12-18 19:54:10
$viewdefs['bhea_Sponsorship_Types']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_BHEA_SESSIONS_BHEA_SPONSORSHIP_TYPES_1_FROM_BHEA_SESSIONS_TITLE',
  'context' => 
  array (
    'link' => 'bhea_sessions_bhea_sponsorship_types_1',
  ),
);