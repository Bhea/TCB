<?php
 // created: 2013-12-18 19:54:10
$layout_defs["Bhea_Sessions"]["subpanel_setup"]['bhea_sessions_bhea_sponsorship_types_1'] = array (
  'order' => 100,
  'module' => 'bhea_Sponsorship_Types',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_BHEA_SESSIONS_BHEA_SPONSORSHIP_TYPES_1_FROM_BHEA_SPONSORSHIP_TYPES_TITLE',
  'get_subpanel_data' => 'bhea_sessions_bhea_sponsorship_types_1',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
