<?php
// created: 2013-12-03 09:42:33
$dictionary["Bhea_Sessions"]["fields"]["bhea_sessions_bhea_registrants_1"] = array (
  'name' => 'bhea_sessions_bhea_registrants_1',
  'type' => 'link',
  'relationship' => 'bhea_sessions_bhea_registrants_1',
  'source' => 'non-db',
  'module' => 'Bhea_Registrants',
  'bean_name' => 'Bhea_Registrants',
  'vname' => 'LBL_BHEA_SESSIONS_BHEA_REGISTRANTS_1_FROM_BHEA_SESSIONS_TITLE',
  'id_name' => 'bhea_sessions_bhea_registrants_1bhea_sessions_ida',
  'link-type' => 'many',
  'side' => 'left',
);
