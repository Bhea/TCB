<?php
// created: 2013-12-20 10:48:26
$dictionary["Bhea_Sponsorship"]["fields"]["bhea_sessions_bhea_sponsorship_1"] = array (
  'name' => 'bhea_sessions_bhea_sponsorship_1',
  'type' => 'link',
  'relationship' => 'bhea_sessions_bhea_sponsorship_1',
  'source' => 'non-db',
  'module' => 'Bhea_Sessions',
  'bean_name' => 'Bhea_Sessions',
  'vname' => 'LBL_BHEA_SESSIONS_BHEA_SPONSORSHIP_1_FROM_BHEA_SESSIONS_TITLE',
  'id_name' => 'bhea_sessions_bhea_sponsorship_1bhea_sessions_ida',
);
