<?php
 // created: 2014-01-07 18:33:00
$dictionary['Bhea_Registrants']['fields']['last_name']['required']=false;

 ?>