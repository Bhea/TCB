<?php
 // created: 2014-01-07 13:17:57
$dictionary['Bhea_Registrants']['fields']['participant_type_c']['labelValue']='Participant Type';
$dictionary['Bhea_Registrants']['fields']['participant_type_c']['dependency']='';
$dictionary['Bhea_Registrants']['fields']['participant_type_c']['visibility_grid']='';

 ?>