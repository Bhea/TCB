<?php
 // created: 2014-01-03 14:43:48
$dictionary['Bhea_Registrants']['fields']['source_c']['labelValue']='Source';
$dictionary['Bhea_Registrants']['fields']['source_c']['dependency']='';
$dictionary['Bhea_Registrants']['fields']['source_c']['visibility_grid']='';

 ?>