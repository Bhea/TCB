<?php
 // created: 2014-01-13 15:19:49
$dictionary['Bhea_member_levels']['fields']['member_type_c']['labelValue']='Membership Type';
$dictionary['Bhea_member_levels']['fields']['member_type_c']['dependency']='';
$dictionary['Bhea_member_levels']['fields']['member_type_c']['visibility_grid']='';

 ?>