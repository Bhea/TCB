<?php
 // created: 2014-01-03 11:39:49
$dictionary['Bhea_member_levels']['fields']['mem_period']['default']='1';

 ?>