<?php
//auto-generated file DO NOT EDIT
$viewdefs['Bhea_member_levels']['base']['layout']['subpanels']['components'][]['override_subpanel_list_view'] = array (
  'link' => 'bhea_member_levels_bhea_pricing_line_item_1',
  'view' => 'subpanel-for-bhea_member_levels',
);
?>