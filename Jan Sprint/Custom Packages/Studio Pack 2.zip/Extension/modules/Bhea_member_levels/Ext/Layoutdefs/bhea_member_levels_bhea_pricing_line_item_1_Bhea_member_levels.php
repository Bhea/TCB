<?php
 // created: 2013-12-16 10:10:55
$layout_defs["Bhea_member_levels"]["subpanel_setup"]['bhea_member_levels_bhea_pricing_line_item_1'] = array (
  'order' => 100,
  'module' => 'Bhea_Pricing_Line_Item',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_BHEA_MEMBER_LEVELS_BHEA_PRICING_LINE_ITEM_1_FROM_BHEA_PRICING_LINE_ITEM_TITLE',
  'get_subpanel_data' => 'bhea_member_levels_bhea_pricing_line_item_1',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
