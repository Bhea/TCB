<?php

$hook_version = 1;
$hook_array = Array();

$hook_array['before_save'] = Array();
$hook_array['before_save'][] = Array(1,'Populating the fee to be charged based on given discount','custom/modules/Bhea_Event_Fee/event_fee.php','event_fee_class','event_fee_method');
?>
