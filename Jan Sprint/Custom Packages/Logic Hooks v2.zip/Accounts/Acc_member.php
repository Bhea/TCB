<?php
/*
*@File:Acc_member.php.
*@Author:Meghana.A @ Bhea Technologies.
*@Purpose:The recent record of the Financial 
* Performance revenue is updated in the
* Company module revenue.
*/

class Acc_member
{
	public function validate($bean,$fp_id,$fpVal,$compVal)
	{
		$fp = BeanFactory::getBean('Bhea_finance_performance',$fp_id);
		if(empty($fp->$fpVal))
		{
			$bean->$compVal = " ";
		}
		else
		{
			$bean->$compVal = $fp->$fpVal;
		}
		$bean->save();
	}
	
	public function Acc_member($bean,$event,$arguments)
	{
		if($arguments['related_module'] == "Bhea_finance_performance")
		{
			$fp = BeanFactory::getBean('Bhea_finance_performance',$arguments['related_id']);
			$bean->annual_revenue = number_format($fp->revenue, 2, '.', '');
			$this->validate($bean,$arguments['related_id'],"forbes_rating_c","forbes_rating_c");
			$this->validate($bean,$arguments['related_id'],"fortune_global_rating_c","global_rating_c");
			$this->validate($bean,$arguments['related_id'],"no_of_emp","employees");
			$this->validate($bean,$arguments['related_id'],"fortune_rank_c","fortune_rank_c");
			$this->validate($bean,$arguments['related_id'],"fortune_global_rank_c","fortune_global_rank_c");
			$this->validate($bean,$arguments['related_id'],"us_revenue_c","us_revenue_c");
			$this->validate($bean,$arguments['related_id'],"naics_1_c","naics_1_c");
			$this->validate($bean,$arguments['related_id'],"naics_2_c","naics_2_c");
			$this->validate($bean,$arguments['related_id'],"naics_3_c","naics_3_c");
		}
	}
	
}
?>
