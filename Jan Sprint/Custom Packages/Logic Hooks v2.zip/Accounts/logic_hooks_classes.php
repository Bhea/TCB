<?php
/*
*@File:logic_hooks_classes.php.
*@Author:Meghana.A @ Bhea Technologies.
*@Purpose:If the type of the Company record
* is "member" then the subpanel contact records
* will change to type membership AND also the
* auto generation of code
*/
class logic_hooks_classes{
	function after_save_method($bean,$event,$arguments)
	{
		
		/*
		 * Fetch records from the 
		 * subpanel
		 */
		$parent_type = $bean->account_type;
		if($parent_type == "member")
		{
			$id = $bean->id;
			//$GLOBALS['log']->fatal($id);
			$bean = BeanFactory::getBean('Accounts', $id);
			if ($bean->load_relationship('contacts'))
			{
				//Fetch related beans 
				$relatedBeans = $bean->contacts->getBeans();
			}
			
			foreach($relatedBeans as $single)
			{
				$sid = $single->id;
				//$GLOBALS['log']->fatal($sid);
				$single->contact_type_c = "Member";
				$single->save();
			}
		}
		$team_obj = BeanFactory::getBean("Teams", $bean->team_id);
		$bean->territory_id_c = $team_obj->territory_id_c;
		//$bean->save();
	}
	
	function auto_code($bean,$event,$arguments)
	{
		global $db;
		if($_SERVER['REQUEST_URI'] != "/tcb/dev/index.php")
		{
		$query 		= "SELECT seq_no_auto_increment_c FROM accounts_cstm WHERE id_c='".$bean->id."'";
		$res   = $db->query($query);
		$row = $db->fetchByAssoc($res);                          
		$seq_no_c = $row['seq_no_auto_increment_c'];
		if(strlen($seq_no_c)==1)
			{
				$trun='00000';
			}
			else if(strlen($seq_no_c)==2)
			{
				$trun='0000';
			}
			else if(strlen($seq_no_c)==3)
			{
				$trun='000';
			}
			else if(strlen($seq_no_c)==4)
			{
				$trun='00';
			}
			else if(strlen($seq_no_c)==5)
			{
				$trun='0';
			}
			else if(strlen($seq_no_c)==6)
			{
				$trun='';
			}

		$sno = $trun.$seq_no_c;
		$update_code="UPDATE accounts_cstm SET company_code_c= '$sno' WHERE id_c='$bean->id'";
		$db->query($update_code);
		}
		
	}

}

?>
