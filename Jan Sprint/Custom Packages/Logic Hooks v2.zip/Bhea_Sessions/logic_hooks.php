<?php
$hook_version = 1;
$hook_array = Array();

$hook_array['after_save'] = Array();
$hook_array['after_save'][]= Array(1,'code generation','custom/modules/Bhea_Sessions/sessionid_generation.php','sessionid_class','sessionid_method');
?>
