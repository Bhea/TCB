<?php
/*
*@File:Speakers.php.
*@Author:Prateek Kaushal @ Bhea Technologies.
*@Purpose: To generate the Session Id. 
*/

if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
class sessionid_class{
	
	function sessionid_method($bean,$event,$arguements){
		
		global $db;
		
		$query 		= 'SELECT code_c FROM bhea_sessions_cstm WHERE id_c="'.$bean->id.'"';
		$res   		= $db->query($query);
		$row   		= $bean->db->fetchByAssoc($res);                          
		$seq_no_c   = $row['code_c'];
		
		if(strlen($seq_no_c)==1){
			$trun='0000';
		}
		else if(strlen($seq_no_c)==2){
			$trun='000';
		}
		else if(strlen($seq_no_c)==3){
			$trun='00';
		}
		else if(strlen($seq_no_c)==4){
			$trun='0';
		}

		$sno = $trun.$seq_no_c;
		
		$events_id 		= $bean->bhea_events_bhea_sessions_1bhea_events_ida;
		$eventsBean 	= BeanFactory::getBean('Bhea_Events',$events_id);
		$event_id_c 	= $eventsBean->event_id_c;
	
		$change = "SE-".$event_id_c."/".$sno;
		$update_session_id_c = ' UPDATE bhea_sessions_cstm SET session_id_c="'.$change.'" WHERE id_c="'.$bean->id.'" ' ;	
		$db->query($update_session_id_c);	
	}
}
