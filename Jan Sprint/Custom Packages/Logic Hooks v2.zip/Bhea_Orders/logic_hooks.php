<?php

$hook_version = 1;
$hook_array = Array();

$hook_array['after_save'] = Array();
$hook_array['after_save'][] = Array(1,'Auto code generation in Orders','custom/modules/Bhea_Orders/auto_code.php','auto_code','auto_code');

?>
