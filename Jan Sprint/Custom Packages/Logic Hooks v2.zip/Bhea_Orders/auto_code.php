<?php
class auto_code
{
function auto_code($bean,$event,$arguments)
	{
		global $db;
		$GLOBALS['log']->fatal("order file autocode called");
		$accBean = BeanFactory::getBean('Accounts',$bean->accounts_bhea_orders_1accounts_ida);
		$query 		= "SELECT seq_no_auto_increment_c FROM bhea_orders_cstm WHERE id_c='".$bean->id."'";
		$res   = $db->query($query);
		$row = $db->fetchByAssoc($res);                          
		$seq_no_c = $row['seq_no_auto_increment_c'];
		if(strlen($seq_no_c)==1)
			{
				$trun='00000';
			}
			else if(strlen($seq_no_c)==2)
			{
				$trun='0000';
			}
			else if(strlen($seq_no_c)==3)
			{
				$trun='000';
			}
			else if(strlen($seq_no_c)==4)
			{
				$trun='00';
			}
			else if(strlen($seq_no_c)==5)
			{
				$trun='0';
			}
			else if(strlen($seq_no_c)==6)
			{
				$trun='';
			}

		$sno = $accBean->company_alias_c."-O-".$trun.$seq_no_c;
		$update_code="UPDATE bhea_orders SET name= '$sno' WHERE id='$bean->id'";
		$db->query($update_code);
		
	}
}
?>
