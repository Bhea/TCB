<?php
/*
*@File:after_save_logic_hook.php.
*@Author:Prateek Kaushal @ Bhea Technologies.
*@Purpose:This file is used to fill the Participant name when the participant type is council member through the relationship of Council Member.
*/
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

class afterSaveParticipants_class{
	function afterSaveParticipants_method($bean,$event,$arguments){
		
		/*Fetching the Council Members id from the layout.
		* */
		$council_member_id	 		= $bean->bhea_council_members_bhea_registrants_1bhea_council_members_ida;
		$councilmemberBean 			= BeanFactory::getBean('Bhea_Council_Members',$council_member_id);	
		
		if($bean->participant_type_c == "Council_Member"){
			
		$bean->salutation 			= $councilmemberBean->salutation;
		$bean->first_name 			= $councilmemberBean->first_name;
		$bean->last_name 			= $councilmemberBean->last_name;
		
		$bean->save();
		}
	}
}
?>
