<?php
/*
*@File:Speakers.php.
*@Author:Prateek Kaushal @ Bhea Technologies.
*@Purpose:This file is used to creating the relationship.
*/
$hook_version = 1;
$hook_array = Array();

$hook_array['after_save'] = Array();
$hook_array['after_save'][] = Array(1,'Record creation in Bhea_Registrants Module','custom/modules/Bhea_Registrants/after_save_logic_hook.php','afterSaveParticipants_class','afterSaveParticipants_method');

$hook_array['after_relationship_add'] = Array();
$hook_array['after_relationship_add'][] = Array(1, 'Loading the relatioships', 'custom/modules/Bhea_Registrants/after_relationship.php', 'after_relationship_class', 'after_relationship_method');
?>
