<?php
/*
*@File:Speakers.php.
*@Author:Prateek Kaushal @ Bhea Technologies.
*@Purpose:This file is used to creating the relationship.
*/

if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
class after_relationship_class
{
	function after_relationship_method($bean,$event,$arguments)
	{
		$GLOBALS['log']->fatal("hi in participants");
		
		/*Fetching the event id from the layout.
		* */
		$event_id	 		= $bean->bhea_events_bhea_registrants_1bhea_events_ida;
		$eventBean 			= BeanFactory::getBean('Bhea_Events',$event_id);
		
		/*Fetching the Council Members id from the layout.
		* */
		$council_member_id	 		= $bean->bhea_council_members_bhea_registrants_1bhea_council_members_ida;
		$councilmemberBean 			= BeanFactory::getBean('Bhea_Council_Members',$council_member_id);
			
		/*Loading relationship between Events and Council Members through the subpanel.
		* */
		$councilmemberBean->load_relationship('bhea_council_members_bhea_events_1');
		$councilmemberBean->bhea_council_members_bhea_events_1->add($eventBean->id);
		
	}
}
