<?php

/*
 * @File: GroupsAutoCode.php
 * @Author: Venkata Krishna C V
 * @Date: 1/1/2014
 * @Purpose: This file is used to generate a Group ID automatically on save of Groups record.  
 **/
class groupsAutoCode{
	function groupsAutoCode_fun($bean,$events,$arguments){
			$type = $bean->type;
			switch($type)
			{
				case "Council" 		 : 		$code = "COUN";
											break;
				case "Academy"		 : 		$code = "ACA";
											break;
				case "Working_Group" : 		$code = "RWG";
											break;
			}
			
			$practice = $bean->knowledge_area;
			switch($practice)
			{
				case "human_capital" 		: 	$code .= "-HR-";
												break;
				case "corporate_leadership" :	$code .= "-CL-";
												break;
				case "economy_value" 		:	$code .= "-EVC-";
												break;
				default						:	$code .= "-";
			}
			$auto_id = $bean->auto_id_c;
			if($auto_id < 10)
			{
				$seq_no = "0000".$auto_id;
			}
			else if($auto_id < 100)
			{
				$seq_no = "000".$auto_id;
			}
			else if($auto_id < 1000)
			{
				$seq_no = "00".$auto_id;
			}
			else if($auto_id < 10000)
			{
				$seq_no = "0".$auto_id;
			}
			else
			{
				$seq_no = $auto_id;
			}
			$code .= $seq_no;
			$bean->group_id_c = $code;
	}
}

?>
