<?php

$hook_version = 1;
$hook_array = Array();

$hook_array['before_save'] = Array();
$hook_array['before_save'][] = Array(1,'Council Memberships Auto Generated name and code','custom/modules/Bhea_Council_Memberships/CouncilMembershipCodes.php','councilMembershipCodes','councilMembershipCodes_fun');

?>
