<?php
/*
 * @File: CouncilMembershipCodes.php
 * @Author: Venkata Krishna C V
 * @Date: 1/1/2014
 * @Purpose: This file is used to generate a Council Membership Code automatically on save of Council Membership record  
 **/
class councilMembershipCodes{
	function councilMembershipCodes_fun($bean,$events,$arguments){
			$accBean = BeanFactory::getBean('Accounts',$bean->accounts_bhea_council_memberships_1accounts_ida);
			$code = $accBean->company_code_c;
			$code .= "-CME-";
			$auto_id = $bean->auto_id_c;
			if($auto_id < 10)
			{
				$seq_no = "00000".$auto_id;
			}
			else if($auto_id < 100)
			{
				$seq_no = "0000".$auto_id;
			}
			else if($auto_id < 1000)
			{
				$seq_no = "000".$auto_id;
			}
			else if($auto_id < 10000)
			{
				$seq_no = "00".$auto_id;
			}
			else if($auto_id < 100000)
			{
				$seq_no = "0".$auto_id;
			}
			else
			{
				$seq_no = $auto_id;
			}
			$code .= $seq_no;
			$bean->council_mem_code_c = $code;
	}
}

?>
