<?php
class auto_code
{
	function auto_code($bean,$event,$arguments)
	{
		global $db;
		$accBean = BeanFactory::getBean('Accounts',$bean->accounts_bhea_memberships_1accounts_ida);
		$mem_subtype = $bean->mem_type;
		$bean->name = $accBean->company_alias_c."-".$accBean->company_category_c."-Membership";
		
		$query = 'SELECT auto_code_c FROM bhea_memberships_cstm ORDER BY auto_code_c DESC LIMIT 0,1';
		$res   = $db->query($query);
		$row = $db->fetchByAssoc($res);                          
		$seq_no_c = $row['auto_code_c'];
		//$bean->name = $bean->territory_id_c."-".
		if(strlen($seq_no_c)==1)
			{
				$trun='00000';
			}
			else if(strlen($seq_no_c)==2)
			{
				$trun='0000';
			}
			else if(strlen($seq_no_c)==3)
			{
				$trun='000';
			}
			else if(strlen($seq_no_c)==4)
			{
				$trun='00';
			}
			else if(strlen($seq_no_c)==5)
			{
				$trun='0';
			}
			else if(strlen($seq_no_c)==6)
			{
				$trun='';
			}
			
		$sno = $accBean->company_code_c."/ME-".$trun.$seq_no_c;
		$update_code="UPDATE bhea_memberships_cstm SET membership_code_c= '$sno' WHERE id_c='$bean->id'";
		$db->query($update_code);
	}
}
?>
