<?php
$hook_version = 1;
$hook_array = Array();

$hook_array['after_save'] = Array();
$hook_array['after_save'][]= Array(1,'code generation','custom/modules/Bhea_Events/eventid_generation.php','eventid_class','eventid_method');
?>
