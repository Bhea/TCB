<?php

$hook_version = 1;
$hook_array = Array();

$hook_array['before_save'] = Array();
$hook_array['before_save'][] = Array(1,'Groups Auto Generated code','custom/modules/Bhea_Councils/GroupsAutoCode.php','groupsAutoCode','groupsAutoCode_fun');

?>
