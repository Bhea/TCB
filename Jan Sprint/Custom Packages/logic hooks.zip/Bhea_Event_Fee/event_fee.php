<?php
/*
*@File:event_fee.php.
*@Author:Prateek Kaushal @ Bhea Technologies.
*@Purpose:This file is used to create a record Populating the fee to be charged based on given discount.
*/

if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
class event_fee_class{
		function event_fee_method($bean,$event,$arguments){
					
			if($bean->discount_c == 0){
				$bean->fee_to_be_charged_c = $bean->fees_c - $bean->early_bird_discount_c;
			}
			else{
				$bean->fee_to_be_charged_c = $bean->fees_c - (($bean->early_bird_discount_c/100)*$bean->fees_c);
			}
			
		}
}
