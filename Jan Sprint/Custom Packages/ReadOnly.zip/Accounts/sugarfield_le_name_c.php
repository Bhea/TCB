<?php
 // created: 2013-12-18 18:42:12
$dictionary['Account']['fields']['le_name_c']['labelValue']='LE Name';
$dictionary['Account']['fields']['le_name_c']['full_text_search']=array (
  'boost' => '0',
);
$dictionary['Account']['fields']['le_name_c']['enforced']='';
$dictionary['Account']['fields']['le_name_c']['dependency']='';
$dictionary['Account']['fields']['le_name_c']['readonly']=true;

 ?>
