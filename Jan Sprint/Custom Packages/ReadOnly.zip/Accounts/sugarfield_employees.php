<?php
$dictionary['Account']['fields']['employees']['readonly']=true;
?>
