<?php
 // created: 2014-01-16 19:02:12
$dictionary['Account']['fields']['us_revenue_c']['labelValue']='US Revenue(M)';
$dictionary['Account']['fields']['us_revenue_c']['enforced']='';
$dictionary['Account']['fields']['us_revenue_c']['dependency']='';
$dictionary['Account']['fields']['us_revenue_c']['readonly']=true;

 ?>
