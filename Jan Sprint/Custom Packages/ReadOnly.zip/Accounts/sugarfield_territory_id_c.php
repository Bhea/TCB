<?php
 // created: 2014-01-13 17:19:56
$dictionary['Account']['fields']['territory_id_c']['labelValue']='Territory ID';
$dictionary['Account']['fields']['territory_id_c']['full_text_search']=array (
  'boost' => '0',
);
$dictionary['Account']['fields']['territory_id_c']['enforced']='';
$dictionary['Account']['fields']['territory_id_c']['dependency']='';
$dictionary['Account']['fields']['territory_id_c']['readonly']=true;

 ?>
