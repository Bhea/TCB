<?php
 // created: 2014-01-07 10:16:56
$dictionary['Account']['fields']['le_title_c']['labelValue']='LE Title';
$dictionary['Account']['fields']['le_title_c']['full_text_search']=array (
  'boost' => '0',
);
$dictionary['Account']['fields']['le_title_c']['enforced']='';
$dictionary['Account']['fields']['le_title_c']['dependency']='';
$dictionary['Account']['fields']['le_title_c']['readonly']=true;
 ?>
