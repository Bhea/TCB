<?php
 // created: 2013-12-03 09:18:35
$dictionary['Account']['fields']['global_rating_c']['labelValue']='Fortune Global Rating';
$dictionary['Account']['fields']['global_rating_c']['full_text_search']=array (
  'boost' => '0',
);
$dictionary['Account']['fields']['global_rating_c']['enforced']='';
$dictionary['Account']['fields']['global_rating_c']['dependency']='';
$dictionary['Account']['fields']['global_rating_c']['readonly']=true;
 ?>
