<?php
 // created: 2014-01-16 15:53:11
$dictionary['Account']['fields']['fortune_global_rank_c']['labelValue']='Fortune Global Rank';
$dictionary['Account']['fields']['fortune_global_rank_c']['full_text_search']=array (
  'boost' => '0',
);
$dictionary['Account']['fields']['fortune_global_rank_c']['enforced']='';
$dictionary['Account']['fields']['fortune_global_rank_c']['dependency']='';
$dictionary['Account']['fields']['fortune_global_rank_c']['readonly']=true;

 ?>
