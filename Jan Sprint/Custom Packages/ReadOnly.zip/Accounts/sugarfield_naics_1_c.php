<?php
 // created: 2014-01-08 14:21:58
$dictionary['Account']['fields']['naics_1_c']['labelValue']='NAICS 1';
$dictionary['Account']['fields']['naics_1_c']['full_text_search']=array (
  'boost' => '0',
);
$dictionary['Account']['fields']['naics_1_c']['enforced']='';
$dictionary['Account']['fields']['naics_1_c']['dependency']='';
$dictionary['Account']['fields']['naics_1_c']['readonly']=true;
 ?>
