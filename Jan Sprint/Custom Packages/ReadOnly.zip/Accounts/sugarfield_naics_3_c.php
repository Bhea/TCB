<?php
 // created: 2014-01-08 14:26:31
$dictionary['Account']['fields']['naics_3_c']['labelValue']='NAICS 3';
$dictionary['Account']['fields']['naics_3_c']['full_text_search']=array (
  'boost' => '0',
);
$dictionary['Account']['fields']['naics_3_c']['enforced']='';
$dictionary['Account']['fields']['naics_3_c']['dependency']='';
$dictionary['Account']['fields']['naics_3_c']['readonly']=true;
 ?>
