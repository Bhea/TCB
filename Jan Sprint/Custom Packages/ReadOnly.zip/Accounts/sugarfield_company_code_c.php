<?php
 // created: 2014-01-01 11:29:48
$dictionary['Account']['fields']['company_code_c']['labelValue']='Company Code';
$dictionary['Account']['fields']['company_code_c']['full_text_search']=array (
  'boost' => '0',
);
$dictionary['Account']['fields']['company_code_c']['enforced']='';
$dictionary['Account']['fields']['company_code_c']['dependency']='';
$dictionary['Account']['fields']['company_code_c']['readonly']=true;

 ?>
