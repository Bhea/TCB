<?php
 // created: 2014-01-08 14:25:30
$dictionary['Account']['fields']['naics_2_c']['labelValue']='NAICS 2';
$dictionary['Account']['fields']['naics_2_c']['full_text_search']=array (
  'boost' => '0',
);
$dictionary['Account']['fields']['naics_2_c']['enforced']='';
$dictionary['Account']['fields']['naics_2_c']['dependency']='';
$dictionary['Account']['fields']['naics_2_c']['readonly']=true;
 ?>
