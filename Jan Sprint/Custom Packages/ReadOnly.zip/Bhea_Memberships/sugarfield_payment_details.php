<?php
$dictionary['Bhea_Memberships']['fields']['payment_details']['readonly']=true;
 ?>



