<?php
$module_name = 'Bhea_Memberships';
$viewdefs[$module_name] = 
array (
  'base' => 
  array (
    'view' => 
    array (
      'record' => 
      array (
        'panels' => 
        array (
          0 => 
          array (
            'name' => 'panel_header',
            'label' => 'LBL_RECORD_HEADER',
            'header' => true,
            'fields' => 
            array (
              0 => 
              array (
                'name' => 'picture',
                'type' => 'avatar',
                'width' => 42,
                'height' => 42,
                'dismiss_label' => true,
                'readonly' => true,
              ),
              1 => 'name',
              2 => 
              array (
                'name' => 'favorite',
                'label' => 'LBL_FAVORITE',
                'type' => 'favorite',
                'readonly' => true,
                'dismiss_label' => true,
              ),
              3 => 
              array (
                'name' => 'follow',
                'label' => 'LBL_FOLLOW',
                'type' => 'follow',
                'readonly' => true,
                'dismiss_label' => true,
              ),
            ),
          ),
          1 => 
          array (
            'name' => 'panel_body',
            'label' => 'LBL_RECORD_BODY',
            'columns' => 2,
            'labelsOnTop' => true,
            'placeholders' => true,
            'fields' => 
            array (
              0 => 
              array (
                'name' => 'bhea_member_levels_bhea_memberships_1_name',
                'label' => 'LBL_BHEA_MEMBER_LEVELS_BHEA_MEMBERSHIPS_1_FROM_BHEA_MEMBER_LEVELS_TITLE',
              ),
              1 => 
              array (
                'name' => 'start_date',
                'label' => 'LBL_START_DATE',
              ),
              2 => 
              array (
                'readonly' => true,
                'name' => 'membership_code_c',
                'label' => 'LBL_MEMBERSHIP_CODE',
              ),
              3 => 
              array (
                'name' => 'membership_period_c',
                'studio' => 'visible',
                'label' => 'LBL_MEMBERSHIP_PERIOD',
              ),
              4 => 
              array (
                'name' => 'expiry_date',
                'label' => 'LBL_EXPIRY_DATE',
              ),
              5 => 
              array (
                'name' => 'mem_type',
                'studio' => 'visible',
                'label' => 'LBL_MEM_TYPE',
              ),
              6 => 
              array (
                'name' => 'status',
                'studio' => 'visible',
                'label' => 'LBL_STATUS',
                'span' => 12,
              ),
              7 => 
              array (
                'name' => 'mem_fee',
                'label' => 'LBL_MEM_FEE',
              ),
              8 => 
              array (
                'name' => 'discount_c',
                'label' => 'LBL_DISCOUNT',
              ),
              9 => 
              array (
                'name' => 'final_mem_fee_c',
                'label' => 'LBL_FINAL_MEM_FEE',
              ),
              10 => 
              array (
                'name' => 'payment_id',
                'readonly' => true,
                'label' => 'LBL_PAYMENT_ID',
              ),
              11 => 
              array (
                'name' => 'payment_date',
                'readonly' => true,
                'label' => 'LBL_PAYMENT_DATE',
              ),
              12 => 
              array (
                'name' => 'payment_mode',
                'studio' => 'visible',
                'readonly' => true,
                'label' => 'LBL_PAYMENT_MODE',
              ),
              13 => 
              array (
                'name' => 'payment_details',
                'studio' => 'visible',
                'readonly' => true,
                'label' => 'LBL_PAYMENT_DETAILS',
              ),
              14 => 
              array (
                'name' => 'payment_status',
                'studio' => 'visible',
                'readonly' => true,
                'label' => 'LBL_PAYMENT_STATUS',
              ),
              15 => 
              array (
                'name' => 'accounts_bhea_memberships_1_name',
                'label' => 'LBL_ACCOUNTS_BHEA_MEMBERSHIPS_1_FROM_ACCOUNTS_TITLE',
              ),
              16 => 
              array (
                'name' => 'lost_reason',
                'studio' => 'visible',
                'label' => 'LBL_LOST_REASON',
              ),
              17 => 
              array (
                'name' => 'date_entered',
                'comment' => 'Date record created',
                'studio' => 
                array (
                  'portaleditview' => false,
                ),
                'readonly' => true,
                'label' => 'LBL_DATE_ENTERED',
              ),
              18 => 
              array (
                'name' => 'date_modified',
                'comment' => 'Date record last modified',
                'studio' => 
                array (
                  'portaleditview' => false,
                ),
                'readonly' => true,
                'label' => 'LBL_DATE_MODIFIED',
              ),
              19 => 'assigned_user_name',
              20 => 'team_name',
            ),
          ),
        ),
        'templateMeta' => 
        array (
          'useTabs' => false,
          'tabDefs' => 
          array (
            'LBL_RECORD_BODY' => 
            array (
              'newTab' => false,
              'panelDefault' => 'expanded',
            ),
          ),
        ),
      ),
    ),
  ),
);
