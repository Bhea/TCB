<?php
/**
 * File - MemberFeeAjax.php
 * Author - Meghana A
 * Purpose - This file is to get the 
 * value of sales stage from the DB
 */
 
if(!defined('sugarEntry')) define('sugarEntry', true);
require_once('include/entryPoint.php');
require_once('data/BeanFactory.php');
global $db;
$oppID = $_REQUEST['oppID'];
$query = "SELECT  `sales_stage` 
		  FROM  `opportunities` 
		  WHERE  `id` = '".$oppID."'";
$result = $db->query($query);
$row = $db->fetchByAssoc($result);
echo $sales_stage = $row['sales_stage'];
?>
