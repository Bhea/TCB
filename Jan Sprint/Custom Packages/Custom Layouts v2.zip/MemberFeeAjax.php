<?php
/**
 * File - MemberFeeAjax.php
 * Author - Meghana A
 * Purpose - Populates fee in Opportunity module
 * based on ML and PLI
 */
 
if(!defined('sugarEntry')) define('sugarEntry', true);
require_once('include/entryPoint.php');
require_once('data/BeanFactory.php');
global $db;
$oppID = $_REQUEST['oppID'];
$cmp_rev= $_REQUEST['cmp_rev'];
$pricing_type_c = $_REQUEST['pricing_type_c'];
$opportunity_type = $_REQUEST['opportunity_type'];

if($opportunity_type == "membership")
{
	/*
	 * Fetch the Member Levels
	 */
	$query = "SELECT  `bhea_member_levels_opportunities_1bhea_member_levels_ida` 
			  FROM  `bhea_member_levels_opportunities_1_c` 
			  WHERE deleted =0
			  AND  `bhea_member_levels_opportunities_1opportunities_idb` = '".$oppID."'";
	$result = $db->query($query);
	$row = $db->fetchByAssoc($result);
	$mem_lev_id = $row['bhea_member_levels_opportunities_1bhea_member_levels_ida'];

	/*
	 * Fetch all the Pricing Line Items
	 */
	$query1 =  "SELECT  `bhea_membe25b3ne_item_idb` as item_id
				FROM  `bhea_member_levels_bhea_pricing_line_item_1_c` 
				WHERE deleted =0
				AND`bhea_membe43fe_levels_ida` = '".$mem_lev_id."'";
	$result1 = $db->query($query1);

	while($row1 = $db->fetchByAssoc($result1))
	{
			$query2 = 	"SELECT a.membership_price_c,a.from_revenue_c,a.to_revenue_c,a.guideline_fee_c,a.nonguideline_fee_c
						FROM bhea_pricing_line_item_cstm a, bhea_member_levels_bhea_pricing_line_item_1_c b, bhea_pricing_line_item c
						WHERE a.id_c ='".$row1['item_id']."'
						AND a.id_c = c.id
						AND c.deleted =  '0'";
			$result2 = $db->query($query2);
			$row2 = $db->fetchByAssoc($result2);
			$from_revenue_c = number_format($row2['from_revenue_c'], 2, '.', '');
			$to_revenue_c = number_format($row2['to_revenue_c'], 2, '.', '');
			$guideline_fee_c = number_format($row2['guideline_fee_c'], 2, '.', '');
			$nonguideline_fee_c = number_format($row2['nonguideline_fee_c'], 2, '.', '');
			$cmp_rev = number_format($cmp_rev, 2, '.', '');
			
			if($cmp_rev >= $from_revenue_c && $cmp_rev <= $to_revenue_c)
			{
				if($pricing_type_c == "guideline")
				{
					$query3 = "UPDATE opportunities_cstm SET membership_fee_c='".$guideline_fee_c."' WHERE id_c = '".$oppID."'";
					$db->query($query3);
				}
				else
				{
					$query3 = "UPDATE opportunities_cstm SET membership_fee_c='".$nonguideline_fee_c."' WHERE id_c = '".$oppID."'";
					$db->query($query3);
				}
			}
	}
	//echo "success";
}

?>

