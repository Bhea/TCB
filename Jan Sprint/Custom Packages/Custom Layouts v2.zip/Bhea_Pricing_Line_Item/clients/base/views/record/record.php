<?php
$module_name = 'Bhea_Pricing_Line_Item';
$viewdefs[$module_name] = 
array (
  'base' => 
  array (
    'view' => 
    array (
      'record' => 
      array (
        'panels' => 
        array (
          0 => 
          array (
            'name' => 'panel_header',
            'label' => 'LBL_RECORD_HEADER',
            'header' => true,
            'fields' => 
            array (
              0 => 
              array (
                'name' => 'picture',
                'type' => 'avatar',
                'width' => 42,
                'height' => 42,
                'dismiss_label' => true,
                'readonly' => true,
              ),
              1 => 'name',
              2 => 
              array (
                'name' => 'favorite',
                'label' => 'LBL_FAVORITE',
                'type' => 'favorite',
                'readonly' => true,
                'dismiss_label' => true,
              ),
              3 => 
              array (
                'name' => 'follow',
                'label' => 'LBL_FOLLOW',
                'type' => 'follow',
                'readonly' => true,
                'dismiss_label' => true,
              ),
            ),
          ),
          1 => 
          array (
            'name' => 'panel_body',
            'label' => 'LBL_RECORD_BODY',
            'columns' => 2,
            'labelsOnTop' => true,
            'placeholders' => true,
            'fields' => 
            array (
              0 => 
              array (
                'name' => 'from_revenue_c',
                'label' => 'LBL_FROM_REVENUE',
              ),
              1 => 
              array (
                'name' => 'to_revenue_c',
                'label' => 'LBL_TO_REVENUE',
              ),
              2 => 
              array (
                'name' => 'guideline_fee_c',
                'label' => 'LBL_GUIDELINE_FEE',
              ),
              3 => 
              array (
                'name' => 'nonguideline_fee_c',
                'label' => 'LBL_NONGUIDELINE_FEE',
              ),
              4 => 
              array (
                'name' => 'bhea_member_levels_bhea_pricing_line_item_1_name',
                'label' => 'LBL_BHEA_MEMBER_LEVELS_BHEA_PRICING_LINE_ITEM_1_FROM_BHEA_MEMBER_LEVELS_TITLE',
                'span' => 12,
              ),
              5 => 
              array (
                'name' => 'date_entered',
                'comment' => 'Date record created',
                'studio' => 
                array (
                  'portaleditview' => false,
                ),
                'readonly' => true,
                'label' => 'LBL_DATE_ENTERED',
              ),
              6 => 
              array (
                'name' => 'date_modified',
                'comment' => 'Date record last modified',
                'studio' => 
                array (
                  'portaleditview' => false,
                ),
                'readonly' => true,
                'label' => 'LBL_DATE_MODIFIED',
              ),
              7 => 'assigned_user_name',
              8 => 'team_name',
            ),
          ),
        ),
        'templateMeta' => 
        array (
          'useTabs' => false,
          'tabDefs' => 
          array (
            'LBL_RECORD_BODY' => 
            array (
              'newTab' => false,
              'panelDefault' => 'expanded',
            ),
          ),
        ),
      ),
    ),
  ),
);
