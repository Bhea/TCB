<?php
 // created: 2013-12-18 15:13:52
$dictionary['Bhea_Sponsorship']['fields']['sponsorship_levels_c']['labelValue']='Sponsorship Levels';
$dictionary['Bhea_Sponsorship']['fields']['sponsorship_levels_c']['dependency']='';
$dictionary['Bhea_Sponsorship']['fields']['sponsorship_levels_c']['visibility_grid']='';

 ?>