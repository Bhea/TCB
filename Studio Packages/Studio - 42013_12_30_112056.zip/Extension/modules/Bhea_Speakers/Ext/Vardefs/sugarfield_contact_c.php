<?php
 // created: 2013-12-03 09:08:09
$dictionary['Bhea_Speakers']['fields']['contact_c']['labelValue']='Contact';
$dictionary['Bhea_Speakers']['fields']['contact_c']['dependency']='';

 ?>