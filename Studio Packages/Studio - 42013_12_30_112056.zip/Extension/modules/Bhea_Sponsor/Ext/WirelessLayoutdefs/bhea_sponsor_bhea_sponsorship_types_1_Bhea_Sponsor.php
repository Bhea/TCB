<?php
 // created: 2013-12-18 16:40:28
$layout_defs["Bhea_Sponsor"]["subpanel_setup"]['bhea_sponsor_bhea_sponsorship_types_1'] = array (
  'order' => 100,
  'module' => 'bhea_Sponsorship_Types',
  'subpanel_name' => 'default',
  'title_key' => 'LBL_BHEA_SPONSOR_BHEA_SPONSORSHIP_TYPES_1_FROM_BHEA_SPONSORSHIP_TYPES_TITLE',
  'get_subpanel_data' => 'bhea_sponsor_bhea_sponsorship_types_1',
);
