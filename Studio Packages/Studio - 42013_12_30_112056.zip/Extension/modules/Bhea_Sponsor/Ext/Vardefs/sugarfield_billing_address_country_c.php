<?php
 // created: 2013-12-25 12:25:36
$dictionary['Bhea_Sponsor']['fields']['billing_address_country_c']['group']='billing_address_c';

 ?>