<?php
 // created: 2013-12-25 10:37:37
$dictionary['Bhea_Sponsor']['fields']['website_c']['labelValue']='Website';
$dictionary['Bhea_Sponsor']['fields']['website_c']['full_text_search']=array (
  'boost' => '0',
);
$dictionary['Bhea_Sponsor']['fields']['website_c']['dependency']='';

 ?>