<?php
 // created: 2013-12-25 10:58:09
$dictionary['Bhea_Sponsor']['fields']['other_phone_c']['labelValue']='Other Phone';
$dictionary['Bhea_Sponsor']['fields']['other_phone_c']['full_text_search']=array (
  'boost' => '0',
);
$dictionary['Bhea_Sponsor']['fields']['other_phone_c']['enforced']='';
$dictionary['Bhea_Sponsor']['fields']['other_phone_c']['dependency']='';

 ?>