<?php
 // created: 2013-12-12 15:18:07
$dictionary['Bhea_Sponsor']['fields']['office_phone_c']['labelValue']='Office Phone';
$dictionary['Bhea_Sponsor']['fields']['office_phone_c']['full_text_search']=array (
  'boost' => '0',
);
$dictionary['Bhea_Sponsor']['fields']['office_phone_c']['enforced']='';
$dictionary['Bhea_Sponsor']['fields']['office_phone_c']['dependency']='';

 ?>