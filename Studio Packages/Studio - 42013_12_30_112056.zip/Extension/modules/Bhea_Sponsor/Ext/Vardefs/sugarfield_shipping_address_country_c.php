<?php
 // created: 2013-12-25 12:23:35
$dictionary['Bhea_Sponsor']['fields']['shipping_address_country_c']['group']='shipping_address_c';

 ?>