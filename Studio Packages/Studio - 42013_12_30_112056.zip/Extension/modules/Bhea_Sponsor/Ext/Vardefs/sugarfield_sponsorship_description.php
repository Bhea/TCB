<?php
 // created: 2013-12-03 12:48:01
$dictionary['Bhea_Sponsor']['fields']['sponsorship_description']['full_text_search']=array (
  'boost' => '0',
);
$dictionary['Bhea_Sponsor']['fields']['sponsorship_description']['rows']='6';
$dictionary['Bhea_Sponsor']['fields']['sponsorship_description']['cols']='50';

 ?>