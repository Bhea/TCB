<?php
 // created: 2013-12-25 10:33:04
$dictionary['Bhea_Sponsor']['fields']['fax_c']['labelValue']='Fax';
$dictionary['Bhea_Sponsor']['fields']['fax_c']['full_text_search']=array (
  'boost' => '0',
);
$dictionary['Bhea_Sponsor']['fields']['fax_c']['enforced']='';
$dictionary['Bhea_Sponsor']['fields']['fax_c']['dependency']='';

 ?>