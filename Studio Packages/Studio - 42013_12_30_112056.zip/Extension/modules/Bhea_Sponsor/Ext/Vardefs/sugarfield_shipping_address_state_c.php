<?php
 // created: 2013-12-25 12:23:34
$dictionary['Bhea_Sponsor']['fields']['shipping_address_state_c']['group']='shipping_address_c';

 ?>