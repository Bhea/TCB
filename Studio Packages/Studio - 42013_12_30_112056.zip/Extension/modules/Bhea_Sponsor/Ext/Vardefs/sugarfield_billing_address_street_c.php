<?php
 // created: 2013-12-25 12:25:35
$dictionary['Bhea_Sponsor']['fields']['billing_address_street_c']['group']='billing_address_c';

 ?>