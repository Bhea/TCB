<?php 
 // created: 2013-12-30 11:20:54
$mod_strings['LBL_CONTACT'] = 'Contacts';
$mod_strings['LBL_ACCOUNT '] = 'Account not';
$mod_strings['LBL_FAMILIAR_NAME'] = 'Familiar Name';

?>
