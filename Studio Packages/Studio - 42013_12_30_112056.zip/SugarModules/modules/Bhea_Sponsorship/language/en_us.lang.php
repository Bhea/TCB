<?php 
 // created: 2013-12-30 11:20:55
$mod_strings['LBL_SPONSORSHIP_TYPE '] = 'Sponsorship Type';
$mod_strings['LBL_BHEA_SPONSORSHIP_BHEA_SESSIONS_1_FROM_BHEA_SESSIONS_TITLE'] = 'Sessions';
$mod_strings['LBL_BHEA_SPONSORSHIP_BHEA_SPONSOR_1_FROM_BHEA_SPONSOR_TITLE'] = 'Sponsor';
$mod_strings['LBL_SPONSORSHIP_LEVELS'] = 'Sponsorship Levels';
$mod_strings['LBL_BHEA_SESSIONS_BHEA_SPONSORSHIP_1_FROM_BHEA_SESSIONS_TITLE'] = 'Sessions';

?>
