<?php

$hook_version = 1;
$hook_array = Array();

$hook_array['after_save'] = Array();
$hook_array['after_save'][] = Array(1,'For editing the existing records','custom/modules/Bhea_finance_performance/Acc_member_save.php','Acc_member_save','Acc_member_save');

?>
