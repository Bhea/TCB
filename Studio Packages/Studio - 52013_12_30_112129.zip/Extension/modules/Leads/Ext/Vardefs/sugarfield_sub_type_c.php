<?php
 // created: 2013-12-18 15:54:00
$dictionary['Lead']['fields']['sub_type_c']['labelValue']='Sub Type';
$dictionary['Lead']['fields']['sub_type_c']['dependency']='';
$dictionary['Lead']['fields']['sub_type_c']['visibility_grid']=array (
  'trigger' => 'prod_serv_interest_c',
  'values' => 
  array (
    'membership' => 
    array (
      0 => 'new_mem',
      1 => 'mem_upgrade',
      2 => 'renewal',
    ),
    'product_services' => 
    array (
      0 => 'conference',
      1 => 'seminar',
      2 => 'research_working',
      3 => 'experiential_learning',
    ),
    '' => 
    array (
    ),
    'Council' => 
    array (
      0 => 'new_mem',
      1 => 'renewal',
    ),
    'prod_service' => 
    array (
      0 => 'seminar',
      1 => 'conference',
      2 => 'research_working',
      3 => 'experiential_learning',
    ),
    'other' => 
    array (
    ),
  ),
);

 ?>