<?php
 // created: 2013-12-25 15:51:54
$dictionary['Lead']['fields']['region_c']['labelValue']='Region';
$dictionary['Lead']['fields']['region_c']['dependency']='';
$dictionary['Lead']['fields']['region_c']['visibility_grid']='';

 ?>