<?php
 // created: 2013-12-20 10:16:31
$dictionary['Lead']['fields']['territory_id_c']['labelValue']='Territory ID';
$dictionary['Lead']['fields']['territory_id_c']['full_text_search']=array (
  'boost' => '0',
);
$dictionary['Lead']['fields']['territory_id_c']['enforced']='';
$dictionary['Lead']['fields']['territory_id_c']['dependency']='';

 ?>