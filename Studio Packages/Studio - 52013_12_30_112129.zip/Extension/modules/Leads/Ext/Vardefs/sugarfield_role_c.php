<?php
 // created: 2013-12-20 10:14:49
$dictionary['Lead']['fields']['role_c']['labelValue']='Role';
$dictionary['Lead']['fields']['role_c']['dependency']='';
$dictionary['Lead']['fields']['role_c']['visibility_grid']='';

 ?>