<?php
//auto-generated file DO NOT EDIT
$viewdefs['Cases']['base']['layout']['subpanels']['components'][]['override_subpanel_list_view'] = array (
  'link' => 'documents',
  'view' => 'subpanel-for-cases',
);
?>