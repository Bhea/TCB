<?php
 // created: 2013-12-25 19:29:52
$dictionary['Opportunity']['fields']['budget_amt_c']['labelValue']='Customer Budget Amount';
$dictionary['Opportunity']['fields']['budget_amt_c']['enforced']='';
$dictionary['Opportunity']['fields']['budget_amt_c']['dependency']='not(equal($opportunity_type,"prod_service"))';

 ?>