<?php
 // created: 2013-12-25 09:24:21
$dictionary['Opportunity']['fields']['membership_fee_c']['labelValue']='Fee';
$dictionary['Opportunity']['fields']['membership_fee_c']['enforced']='';
$dictionary['Opportunity']['fields']['membership_fee_c']['dependency']='';

 ?>