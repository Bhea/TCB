<?php
 // created: 2013-12-25 09:25:41
$dictionary['Opportunity']['fields']['membership_category_c']['labelValue']='Membership Category';
$dictionary['Opportunity']['fields']['membership_category_c']['dependency']='';
$dictionary['Opportunity']['fields']['membership_category_c']['visibility_grid']=array (
  'trigger' => 'opportunity_type',
  'values' => 
  array (
    '' => 
    array (
    ),
    'membership' => 
    array (
      0 => 'Enterprise',
      1 => 'educational',
      2 => 'mid_market',
      3 => 'Government',
      4 => 'Non_Profit',
    ),
    'Council' => 
    array (
      0 => 'Enterprise',
      1 => 'educational',
      2 => 'Government',
      3 => 'mid_market',
      4 => 'Non_Profit',
    ),
    'prod_service' => 
    array (
    ),
    'other' => 
    array (
    ),
  ),
);

 ?>