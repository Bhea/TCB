<?php
 // created: 2013-12-25 09:24:41
$dictionary['Opportunity']['fields']['final_membership_fee_c']['duplicate_merge_dom_value']=0;
$dictionary['Opportunity']['fields']['final_membership_fee_c']['labelValue']='Final Fee';
$dictionary['Opportunity']['fields']['final_membership_fee_c']['calculated']='1';
$dictionary['Opportunity']['fields']['final_membership_fee_c']['formula']='subtract($membership_fee_c,$discount_c)';
$dictionary['Opportunity']['fields']['final_membership_fee_c']['enforced']='1';
$dictionary['Opportunity']['fields']['final_membership_fee_c']['dependency']='';

 ?>