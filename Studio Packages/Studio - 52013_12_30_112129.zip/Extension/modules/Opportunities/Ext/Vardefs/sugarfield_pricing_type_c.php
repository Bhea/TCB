<?php
 // created: 2013-12-25 19:28:06
$dictionary['Opportunity']['fields']['pricing_type_c']['labelValue']='Pricing Type';
$dictionary['Opportunity']['fields']['pricing_type_c']['dependency']='not(equal($opportunity_type,"prod_service"))';
$dictionary['Opportunity']['fields']['pricing_type_c']['visibility_grid']='';

 ?>