<?php
// created: 2013-12-19 18:30:01
$dictionary["bhea_Sponsorship_Types"]["fields"]["bhea_sponsorship_types_opportunities_1"] = array (
  'name' => 'bhea_sponsorship_types_opportunities_1',
  'type' => 'link',
  'relationship' => 'bhea_sponsorship_types_opportunities_1',
  'source' => 'non-db',
  'module' => 'Opportunities',
  'bean_name' => 'Opportunity',
  'vname' => 'LBL_BHEA_SPONSORSHIP_TYPES_OPPORTUNITIES_1_FROM_BHEA_SPONSORSHIP_TYPES_TITLE',
  'id_name' => 'bhea_sponsorship_types_opportunities_1bhea_sponsorship_types_ida',
  'link-type' => 'many',
  'side' => 'left',
);
