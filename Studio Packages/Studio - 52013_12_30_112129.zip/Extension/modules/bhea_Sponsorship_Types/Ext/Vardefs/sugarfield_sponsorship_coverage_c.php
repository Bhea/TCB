<?php
 // created: 2013-12-19 19:50:28
$dictionary['bhea_Sponsorship_Types']['fields']['sponsorship_coverage_c']['labelValue']='Sponsorship Coverage';
$dictionary['bhea_Sponsorship_Types']['fields']['sponsorship_coverage_c']['dependency']='';
$dictionary['bhea_Sponsorship_Types']['fields']['sponsorship_coverage_c']['visibility_grid']='';

 ?>