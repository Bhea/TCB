<?php
// created: 2013-12-19 18:30:01
$viewdefs['bhea_Sponsorship_Types']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_BHEA_SPONSORSHIP_TYPES_OPPORTUNITIES_1_FROM_OPPORTUNITIES_TITLE',
  'context' => 
  array (
    'link' => 'bhea_sponsorship_types_opportunities_1',
  ),
);