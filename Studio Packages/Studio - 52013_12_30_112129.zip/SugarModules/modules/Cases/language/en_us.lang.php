<?php 
 // created: 2013-12-30 11:21:25
$mod_strings['LNK_NEW_CASE'] = 'Create Cases';
$mod_strings['LNK_CREATE'] = 'Create Cases';
$mod_strings['LBL_MODULE_NAME'] = 'Cases';
$mod_strings['LBL_MODULE_NAME_SINGULAR'] = 'Cases';
$mod_strings['LBL_NEW_FORM_TITLE'] = 'New Cases';
$mod_strings['LNK_CASE_LIST'] = 'View Cases';
$mod_strings['LNK_CASE_REPORTS'] = 'View Cases Reports';
$mod_strings['LNK_IMPORT_CASES'] = 'Import Cases';
$mod_strings['LBL_LIST_FORM_TITLE'] = 'Cases List';
$mod_strings['LBL_SEARCH_FORM_TITLE'] = 'Cases Search';
$mod_strings['LBL_ACCOUNT_NAME'] = 'Company Name:';
$mod_strings['LBL_ACCOUNT_ID'] = 'Company ID';
$mod_strings['LBL_CONTACTS_SUBPANEL_TITLE'] = 'Contacts';
$mod_strings['LBL_DOCUMENTS_SUBPANEL_TITLE'] = 'Documents';
$mod_strings['LBL_BUGS_SUBPANEL_TITLE'] = 'Bug Trackers';
$mod_strings['LBL_LIST_MY_CASES'] = 'My Open Casess';
$mod_strings['LBL_LIST_ACCOUNT_NAME'] = 'Company Name';

?>
