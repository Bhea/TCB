<?php
$module_name = 'bhea_Sponsorship_Types';
$viewdefs[$module_name] = 
array (
  'base' => 
  array (
    'view' => 
    array (
      'record' => 
      array (
        'panels' => 
        array (
          0 => 
          array (
            'name' => 'panel_header',
            'label' => 'LBL_RECORD_HEADER',
            'header' => true,
            'fields' => 
            array (
              0 => 
              array (
                'name' => 'picture',
                'type' => 'avatar',
                'width' => 42,
                'height' => 42,
                'dismiss_label' => true,
                'readonly' => true,
              ),
              1 => 'name',
              2 => 
              array (
                'name' => 'favorite',
                'label' => 'LBL_FAVORITE',
                'type' => 'favorite',
                'readonly' => true,
                'dismiss_label' => true,
              ),
              3 => 
              array (
                'name' => 'follow',
                'label' => 'LBL_FOLLOW',
                'type' => 'follow',
                'readonly' => true,
                'dismiss_label' => true,
              ),
            ),
          ),
          1 => 
          array (
            'name' => 'panel_body',
            'label' => 'LBL_RECORD_BODY',
            'columns' => 2,
            'labelsOnTop' => true,
            'placeholders' => true,
            'fields' => 
            array (
              0 => 
              array (
                'name' => 'sponsorship_region_c',
                'studio' => 'visible',
                'label' => 'LBL_SPONSORSHIP_REGION',
              ),
              1 => 
              array (
                'name' => 'sponsorship_type_c',
                'studio' => 'visible',
                'label' => 'LBL_SPONSORSHIP_TYPE',
              ),
              2 => 
              array (
                'name' => 'sponsorship_coverage_c',
                'studio' => 'visible',
                'label' => 'LBL_SPONSORSHIP_COVERAGE',
              ),
              3 => 
              array (
                'name' => 'sponsor_type_c',
                'studio' => 'visible',
                'label' => 'LBL_SPONSOR_TYPE',
              ),
              4 => 
              array (
                'name' => 'sponsorship_fee',
                'label' => 'LBL_SPONSORSHIP_FEE',
              ),
              5 => 
              array (
                'name' => 'members_sponsorship_fee',
                'label' => 'LBL_MEMBERS_SPONSORSHIP_FEE ',
              ),
              6 => 
              array (
                'name' => 'mailers',
                'label' => 'LBL_MAILERS',
              ),
              7 => 
              array (
                'name' => 'main_backdrop',
                'label' => 'LBL_MAIN_BACKDROP',
              ),
              8 => 
              array (
                'name' => 'side_panels',
                'label' => 'LBL_SIDE_PANELS',
              ),
              9 => 
              array (
                'name' => 'website',
                'label' => 'LBL_WEBSITE ',
              ),
              10 => 
              array (
                'name' => 'speaker_facility',
                'label' => 'LBL_SPEAKER_FACILITY',
              ),
              11 => 
              array (
                'name' => 'complimentary_passes',
                'label' => 'LBL_COMPLIMENTARY_PASSES',
              ),
              12 => 
              array (
                'name' => 'description',
                'comment' => 'Full text of the note',
                'label' => 'LBL_DESCRIPTION',
              ),
              13 => 
              array (
                'name' => 'other_information',
                'studio' => 'visible',
                'label' => 'LBL_OTHER_INFORMATION',
              ),
              14 => 
              array (
                'name' => 'date_entered',
                'comment' => 'Date record created',
                'studio' => 
                array (
                  'portaleditview' => false,
                ),
                'readonly' => true,
                'label' => 'LBL_DATE_ENTERED',
              ),
              15 => 
              array (
                'name' => 'created_by_name',
                'readonly' => true,
                'label' => 'LBL_CREATED',
              ),
              16 => 
              array (
                'name' => 'date_modified',
                'comment' => 'Date record last modified',
                'studio' => 
                array (
                  'portaleditview' => false,
                ),
                'readonly' => true,
                'label' => 'LBL_DATE_MODIFIED',
              ),
              17 => 
              array (
                'name' => 'modified_by_name',
                'readonly' => true,
                'label' => 'LBL_MODIFIED_NAME',
              ),
              18 => 'assigned_user_name',
              19 => 'team_name',
            ),
          ),
        ),
        'templateMeta' => 
        array (
          'useTabs' => false,
          'tabDefs' => 
          array (
            'LBL_RECORD_BODY' => 
            array (
              'newTab' => false,
              'panelDefault' => 'expanded',
            ),
          ),
        ),
      ),
    ),
  ),
);
